//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-ovnWb-_Q.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DiCZ-6Ir.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DiCZ-6Ir.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-k_70FDqn.js"]
	}
} });
//#endregion
export { tsrStartManifest };
