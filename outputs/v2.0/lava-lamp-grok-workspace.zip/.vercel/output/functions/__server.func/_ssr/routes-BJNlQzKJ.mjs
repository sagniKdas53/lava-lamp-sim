import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { r as Slot, s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as create } from "../_libs/zustand.mjs";
import { a as RotateCcw, c as Flame, i as SlidersHorizontal, l as Droplet, o as Play, r as Sun, s as Pause, t as Wind, u as ChevronsDown } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Root } from "../_libs/radix-ui__react-separator.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { a as Trigger, i as Root3, n as Portal, r as Provider, t as Content2 } from "../_libs/@radix-ui/react-tooltip+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BJNlQzKJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
/** Inner collision profile: [height, radius]. Tall rocket column. */
var INNER_PROFILE = [
	[1.28, .17],
	[1.52, .26],
	[2, .36],
	[2.55, .4],
	[3.15, .35],
	[3.55, .23],
	[3.82, .13]
];
var LAMP_Y_MIN = INNER_PROFILE[0][0];
var LAMP_Y_MAX = INNER_PROFILE[INNER_PROFILE.length - 1][0];
function radiusAt(y) {
	const pts = INNER_PROFILE;
	if (y <= pts[0][0]) return pts[0][1];
	const last = pts[pts.length - 1];
	if (y >= last[0]) return last[1];
	for (let i = 0; i < pts.length - 1; i++) {
		const y0 = pts[i][0];
		const y1 = pts[i + 1][0];
		if (y <= y1) {
			const u = (y - y0) / (y1 - y0);
			return pts[i][1] + (pts[i + 1][1] - pts[i][1]) * u;
		}
	}
	return last[1];
}
/** Lathe points as [radius, y] for the outer glass wall. */
var GLASS_LATHE = [
	[.19, 1.2],
	[.26, 1.48],
	[.36, 1.95],
	[.44, 2.5],
	[.44, 2.85],
	[.38, 3.25],
	[.26, 3.58],
	[.16, 3.84],
	[.17, 3.9]
];
var LIQUID_LATHE = INNER_PROFILE.map(([y, r]) => [r * .96, y]);
/** Brushed-metal pedestal, wider at the foot. */
var BASE_LATHE = [
	[.17, 1.26],
	[.22, 1.1],
	[.3, .62],
	[.4, .16],
	[.5, .05],
	[.5, 0]
];
/** Bullet cap. */
var CAP_LATHE = [
	[.15, 3.78],
	[.16, 3.9],
	[.12, 4.02],
	[.04, 4.28],
	[.012, 4.4]
];
var FIXED_DT = 1 / 60;
var MAX_STEPS = 3;
var LIQUID_DENSITY = 1;
var THERMAL_EXPANSION = .28;
var BUOYANCY = 400;
var DRAG = .4;
var MAX_SPEED = 2.05;
var COHESION = .62;
var PI = Math.PI;
function clamp(v, a, b) {
	return Math.max(a, Math.min(b, v));
}
function rand(min, max) {
	return min + Math.random() * (max - min);
}
function effectiveEta(viscosity, heat) {
	return (.22 + viscosity * 1.65) * Math.exp(-1.15 * heat);
}
function heatCelsius(heat) {
	return 25 + heat * 70;
}
function etaCentiPoise(viscosity, heat) {
	return effectiveEta(viscosity, heat) * 320;
}
function blobVolume(r) {
	return 4 / 3 * PI * r * r * r;
}
var LavaSim = class {
	blobs = [];
	pool = {
		height: .35,
		surfaceY: LAMP_Y_MIN + .35,
		rBottom: .32,
		rTop: .36,
		ratio: 1
	};
	acc = 0;
	nextId = 1;
	ejectAcc = 0;
	grab = null;
	lastGrab = {
		x: 0,
		y: 0,
		z: 0
	};
	constructor(count, waxDensity) {
		this.reset(count, waxDensity);
	}
	reset(count, _waxDensity) {
		this.blobs = [];
		this.nextId = 1;
		this.acc = 0;
		this.ejectAcc = 0;
		this.grab = null;
		const n = clamp(Math.round(count), 4, 24);
		for (let i = 0; i < n; i++) this.blobs.push(this.makeBlob(true, i));
		this.refreshPool();
	}
	setCount(count, _waxDensity) {
		const n = clamp(Math.round(count), 4, 24);
		while (this.blobs.length > n) {
			const free = this.blobs.findIndex((b) => !b.pooled);
			this.blobs.splice(free >= 0 ? free : this.blobs.length - 1, 1);
		}
		while (this.blobs.length < n) this.blobs.push(this.makeBlob(true, this.blobs.length));
		this.refreshPool();
	}
	beginGrab(index, x, y, z) {
		if (index < 0 || index >= this.blobs.length) return;
		const b = this.blobs[index];
		if (!b || b.pooled) return;
		this.grab = {
			index,
			x,
			y,
			z
		};
		this.lastGrab = {
			x,
			y,
			z
		};
	}
	moveGrab(x, y, z) {
		if (!this.grab) return;
		this.grab.x = x;
		this.grab.y = y;
		this.grab.z = z;
	}
	endGrab() {
		if (!this.grab) return;
		const b = this.blobs[this.grab.index];
		if (b) {
			b.vx = clamp(b.vx, -2.05, MAX_SPEED);
			b.vy = clamp(b.vy, -2.05, MAX_SPEED);
			b.vz = clamp(b.vz, -2.05, MAX_SPEED);
		}
		this.grab = null;
	}
	stir() {
		let released = 0;
		const keep = Math.max(4, this.blobs.length - 8);
		let pooledLeft = this.blobs.reduce((n, b) => n + (b.pooled ? 1 : 0), 0);
		for (const b of this.blobs) if (b.pooled && released < 8 && pooledLeft > keep) {
			this.releaseBlob(b, rand(-PI, PI), .55);
			released += 1;
			pooledLeft -= 1;
		} else if (!b.pooled) {
			b.vx += rand(-1.4, 1.4);
			b.vy += rand(.15, 1.05);
			b.vz += rand(-1.4, 1.4);
			b.t = clamp(b.t + rand(.04, .18), 0, 1);
		}
		this.refreshPool();
	}
	pokePool(x, z) {
		const b = this.blobs.find((blob) => blob.pooled);
		if (!b) return;
		const ang = Math.atan2(z, x);
		this.releaseBlob(b, ang, .7);
		this.refreshPool();
	}
	step(dt, params) {
		if (params.paused) return 1;
		this.acc += Math.min(dt, .1);
		let steps = 0;
		while (this.acc >= .016666666666666666 && steps < MAX_STEPS) {
			this.fixedStep(FIXED_DT, params);
			this.acc -= FIXED_DT;
			steps += 1;
		}
		if (steps === MAX_STEPS) this.acc = 0;
		return this.acc / FIXED_DT;
	}
	stats(params) {
		let rising = 0;
		let falling = 0;
		let temp = 0;
		let n = 0;
		for (const b of this.blobs) {
			if (b.pooled) continue;
			n += 1;
			temp += b.t;
			if (b.vy > .04) rising += 1;
			else if (b.vy < -.04) falling += 1;
		}
		return {
			rising,
			falling,
			avgTemp: n ? temp / n : 0,
			etaCentiPoise: etaCentiPoise(params.viscosity, params.heat),
			heatC: heatCelsius(params.heat)
		};
	}
	makeBlob(pooled, i) {
		const r = .068 + i % 5 * .014 + i % 3 * .008;
		const seed = rand(.2, 9.7) + i * .37;
		const sx = rand(.78, 1.22);
		const sy = rand(.7, 1.72);
		const sz = rand(.78, 1.22);
		const vol = Math.cbrt(1 / (sx * sy * sz));
		return {
			id: this.nextId++,
			pooled,
			x: 0,
			y: LAMP_Y_MIN,
			z: 0,
			vx: 0,
			vy: 0,
			vz: 0,
			px: 0,
			py: LAMP_Y_MIN,
			pz: 0,
			r,
			t: pooled ? .12 : .7,
			rhoJitter: 1 + i * 17 % 7 * .006 - .018,
			seed,
			sx: sx * vol,
			sy: sy * vol,
			sz: sz * vol
		};
	}
	releaseBlob(b, ang, spread) {
		const surface = this.pool.surfaceY;
		const rad = this.pool.rTop * spread * rand(.15, .85);
		b.pooled = false;
		b.t = clamp(.62 + rand(0, .28), 0, 1);
		b.x = Math.cos(ang) * rad;
		b.z = Math.sin(ang) * rad;
		b.y = surface + b.r * .55;
		b.px = b.x;
		b.py = b.y;
		b.pz = b.z;
		b.vx = Math.cos(ang) * rand(-.12, .28);
		b.vz = Math.sin(ang) * rand(-.12, .28);
		b.vy = rand(.22, .55);
	}
	refreshPool() {
		let vol = 0;
		let total = 0;
		for (const b of this.blobs) {
			const v = blobVolume(b.r);
			total += v;
			if (b.pooled) vol += v;
		}
		let h = .28;
		for (let i = 0; i < 5; i++) {
			const midR = radiusAt(LAMP_Y_MIN + h * .5) * .94;
			h = total === 0 ? .04 : vol / Math.max(.08, PI * midR * midR) * 1.18;
			h = clamp(h, .04, 1.45);
		}
		if (vol <= 1e-6) h = .04;
		this.pool = {
			height: h,
			surfaceY: LAMP_Y_MIN + h,
			rBottom: radiusAt(LAMP_Y_MIN) * .94,
			rTop: radiusAt(LAMP_Y_MIN + h) * .94,
			ratio: total > 0 ? vol / total : 0
		};
	}
	fixedStep(dt, params) {
		const eta = effectiveEta(params.viscosity, params.heat);
		const heat = params.heat;
		const blobs = this.blobs;
		for (const b of blobs) {
			if (b.pooled) continue;
			b.px = b.x;
			b.py = b.y;
			b.pz = b.z;
		}
		this.ejectAcc += dt * (.06 + heat * 1.35);
		const freeCount = blobs.reduce((n, b) => n + (b.pooled ? 0 : 1), 0);
		const maxFree = Math.max(3, blobs.length - 5);
		if (heat > .16 && this.pool.ratio > .34 && freeCount < maxFree && this.ejectAcc > .62) {
			this.ejectAcc = 0;
			const ready = blobs.find((b) => b.pooled);
			if (ready) this.releaseBlob(ready, rand(0, PI * 2), .58);
		}
		const grab = this.grab;
		const surfaceY = this.pool.surfaceY;
		for (let i = 0; i < blobs.length; i++) {
			const b = blobs[i];
			if (b.pooled) continue;
			const span = LAMP_Y_MAX - LAMP_Y_MIN;
			const ny = clamp((b.y - LAMP_Y_MIN) / span, 0, 1);
			const heatRate = heat * 1.7 * Math.exp(-ny * 4.2);
			const coolRate = .16 + 1.05 * ny * ny + (heat < .12 ? 1.4 : 0);
			b.t = clamp(b.t + (heatRate * (1 - b.t) - coolRate * b.t) * dt, 0, 1);
			if (grab && grab.index === i) {
				const dx = grab.x - this.lastGrab.x;
				const dy = grab.y - this.lastGrab.y;
				const dz = grab.z - this.lastGrab.z;
				b.x += (grab.x - b.x) * .55;
				b.y += (grab.y - b.y) * .55;
				b.z += (grab.z - b.z) * .55;
				b.vx = dx / dt;
				b.vy = dy / dt;
				b.vz = dz / dt;
				this.constrainWall(b);
				continue;
			}
			const fy = (LIQUID_DENSITY - params.waxDensity * b.rhoJitter * (1 - THERMAL_EXPANSION * b.t)) * BUOYANCY * b.r * b.r;
			const jitter = (.28 + .7 * (1 - params.viscosity)) * .4;
			const denom = 1 + DRAG * eta * (.5 + b.r * 2.4) * dt;
			b.vx = (b.vx + (Math.random() - .5) * jitter * dt) / denom;
			b.vy = (b.vy + fy * dt) / denom;
			b.vz = (b.vz + (Math.random() - .5) * jitter * dt) / denom;
			const sp = Math.hypot(b.vx, b.vy, b.vz);
			if (sp > MAX_SPEED) {
				const s = MAX_SPEED / sp;
				b.vx *= s;
				b.vy *= s;
				b.vz *= s;
			}
			b.x += b.vx * dt;
			b.y += b.vy * dt;
			b.z += b.vz * dt;
			this.constrainWall(b);
			const nearPool = b.y < surfaceY + b.r * 1.05;
			const sinking = b.vy < .1;
			const coolEnough = b.t < (heat < .18 ? .72 : .38);
			if (nearPool && sinking && coolEnough) {
				b.pooled = true;
				b.vx = 0;
				b.vy = 0;
				b.vz = 0;
			}
		}
		if (grab) this.lastGrab = {
			x: grab.x,
			y: grab.y,
			z: grab.z
		};
		this.resolveFree();
		this.refreshPool();
	}
	constrainWall(b) {
		const yMin = LAMP_Y_MIN + b.r * .35;
		const yMax = LAMP_Y_MAX - b.r - .02;
		if (b.y < yMin) {
			b.y = yMin;
			if (b.vy < 0) b.vy *= -.1;
		} else if (b.y > yMax) {
			b.y = yMax;
			if (b.vy > 0) b.vy *= -.1;
		}
		const wall = Math.max(.05, radiusAt(b.y) - b.r - .012);
		const rho = Math.hypot(b.x, b.z);
		if (rho > wall && rho > 1e-6) {
			const s = wall / rho;
			b.x *= s;
			b.z *= s;
			const nx = b.x / (wall || 1);
			const nz = b.z / (wall || 1);
			const vn = b.vx * nx + b.vz * nz;
			if (vn > 0) {
				b.vx -= 1.1 * vn * nx;
				b.vz -= 1.1 * vn * nz;
			}
		}
	}
	resolveFree() {
		const blobs = this.blobs;
		const n = blobs.length;
		for (let i = 0; i < n; i++) {
			const a = blobs[i];
			if (a.pooled) continue;
			for (let j = i + 1; j < n; j++) {
				const b = blobs[j];
				if (b.pooled) continue;
				const dx = b.x - a.x;
				const dy = b.y - a.y;
				const dz = b.z - a.z;
				const distSq = dx * dx + dy * dy + dz * dz;
				const minDist = a.r + b.r;
				const cohesionR = minDist * 1.22;
				if (distSq > cohesionR * cohesionR || distSq < 1e-10) continue;
				const dist = Math.sqrt(distSq);
				const nx = dx / dist;
				const ny = dy / dist;
				const nz = dz / dist;
				if (dist < minDist) {
					const pen = (minDist - dist) * .5;
					a.x -= nx * pen;
					a.y -= ny * pen;
					a.z -= nz * pen;
					b.x += nx * pen;
					b.y += ny * pen;
					b.z += nz * pen;
					const rv = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny + (b.vz - a.vz) * nz;
					if (rv < 0) {
						const impulse = -1.1 * rv * .5;
						a.vx -= impulse * nx;
						a.vy -= impulse * ny;
						a.vz -= impulse * nz;
						b.vx += impulse * nx;
						b.vy += impulse * ny;
						b.vz += impulse * nz;
					}
				} else {
					const pull = (cohesionR - dist) / cohesionR * COHESION * .005;
					a.vx += nx * pull;
					a.vy += ny * pull;
					a.vz += nz * pull;
					b.vx -= nx * pull;
					b.vy -= ny * pull;
					b.vz -= nz * pull;
				}
			}
		}
	}
};
var PRESETS = [
	{
		id: "magma",
		name: "Magma",
		wax: "#ffd15c",
		fluid: "#ff6a12"
	},
	{
		id: "ember",
		name: "Ember",
		wax: "#ff5a38",
		fluid: "#c43218"
	},
	{
		id: "honey",
		name: "Honey",
		wax: "#f5c518",
		fluid: "#c46a12"
	},
	{
		id: "nocturne",
		name: "Nocturne",
		wax: "#f7e7c4",
		fluid: "#3a2c22"
	},
	{
		id: "rose",
		name: "Rose",
		wax: "#ff6b8a",
		fluid: "#c2185b"
	},
	{
		id: "orchid",
		name: "Orchid",
		wax: "#ff4fa8",
		fluid: "#7a2ee0"
	},
	{
		id: "aurora",
		name: "Aurora",
		wax: "#3ee0d0",
		fluid: "#0e8f8a"
	},
	{
		id: "cobalt",
		name: "Azure",
		wax: "#e4ff55",
		fluid: "#1a96ff"
	},
	{
		id: "ice",
		name: "Ice",
		wax: "#e8f4ff",
		fluid: "#2a4a5c"
	},
	{
		id: "kelp",
		name: "Kelp",
		wax: "#b6e14a",
		fluid: "#1f7a32"
	},
	{
		id: "citrus",
		name: "Citrus",
		wax: "#d6ff4a",
		fluid: "#7a8a12"
	},
	{
		id: "ink",
		name: "Ink",
		wax: "#f4efe6",
		fluid: "#1a1816"
	}
];
var PRESET_MAP = Object.fromEntries(PRESETS.map((p) => [p.id, p]));
var WAX_SWATCHES = [
	"#ffd15c",
	"#ff6a1a",
	"#ff5a38",
	"#f5c518",
	"#ff4fa8",
	"#ff6b8a",
	"#d87cff",
	"#e4ff55",
	"#3ee0d0",
	"#6aa8ff",
	"#e8f4ff",
	"#b6e14a",
	"#f4efe6"
];
var FLUID_SWATCHES = [
	"#ff6a12",
	"#c43218",
	"#7a2ee0",
	"#1a96ff",
	"#0e8f8a",
	"#c2185b",
	"#1f7a32",
	"#156a78",
	"#3a2c22",
	"#2a4a5c",
	"#1a1816"
];
function isPreset(v) {
	return typeof v === "string" && v in PRESET_MAP;
}
function parseHex(hex) {
	const h = hex.replace("#", "");
	const full = h.length === 3 ? h.replace(/./g, (c) => c + c) : h;
	const n = Number.parseInt(full, 16);
	if (!Number.isFinite(n)) return [
		255,
		120,
		40
	];
	return [
		n >> 16 & 255,
		n >> 8 & 255,
		n & 255
	];
}
function mixHex(a, b, t) {
	const [ar, ag, ab] = parseHex(a);
	const [br, bg, bb] = parseHex(b);
	return `#${[
		Math.round(ar + (br - ar) * t),
		Math.round(ag + (bg - ag) * t),
		Math.round(ab + (bb - ab) * t)
	].map((c) => c.toString(16).padStart(2, "0")).join("")}`;
}
function deriveGlow(wax) {
	return mixHex(wax, "#ffffff", .34);
}
function matchingPreset(wax, fluid) {
	const w = wax.toLowerCase();
	const f = fluid.toLowerCase();
	return PRESETS.find((p) => p.wax.toLowerCase() === w && p.fluid.toLowerCase() === f)?.id ?? null;
}
var STORAGE_KEY = "lavalab-v2";
var magma = PRESET_MAP.magma;
var defaults = {
	heat: .62,
	viscosity: .42,
	waxDensity: 1.04,
	blobCount: 12,
	brightness: .72,
	waxColor: magma.wax,
	fluidColor: magma.fluid,
	controlsOpen: true,
	paused: false,
	rising: 0,
	falling: 0,
	avgTemp: 0,
	etaCp: 0,
	heatC: 0
};
function loadPersisted() {
	if (typeof window === "undefined") return {};
	try {
		const raw = window.localStorage.getItem(STORAGE_KEY) ?? window.localStorage.getItem("lavalab-v1");
		if (!raw) return {};
		const parsed = JSON.parse(raw);
		const fromPreset = isPreset(parsed.presetId) ? PRESET_MAP[parsed.presetId] : null;
		const waxColor = typeof parsed.waxColor === "string" ? parsed.waxColor : fromPreset?.wax ?? defaults.waxColor;
		const fluidColor = typeof parsed.fluidColor === "string" ? parsed.fluidColor : fromPreset?.fluid ?? defaults.fluidColor;
		return {
			heat: clamp01(parsed.heat, defaults.heat),
			viscosity: clamp01(parsed.viscosity, defaults.viscosity),
			waxDensity: clampNum(parsed.waxDensity, .82, 1.18, defaults.waxDensity),
			blobCount: Math.round(clampNum(parsed.blobCount, 4, 24, defaults.blobCount)),
			brightness: clamp01(parsed.brightness, defaults.brightness),
			waxColor,
			fluidColor,
			controlsOpen: parsed.controlsOpen !== false
		};
	} catch {
		return {};
	}
}
function clamp01(v, fallback) {
	return typeof v === "number" && Number.isFinite(v) ? Math.min(1, Math.max(0, v)) : fallback;
}
function clampNum(v, min, max, fallback) {
	return typeof v === "number" && Number.isFinite(v) ? Math.min(max, Math.max(min, v)) : fallback;
}
function createLavaStore() {
	return create((set) => ({
		...defaults,
		setHeat: (heat) => set({ heat }),
		setViscosity: (viscosity) => set({ viscosity }),
		setWaxDensity: (waxDensity) => set({ waxDensity }),
		setBlobCount: (blobCount) => set({ blobCount }),
		setBrightness: (brightness) => set({ brightness }),
		setWaxColor: (waxColor) => set({ waxColor }),
		setFluidColor: (fluidColor) => set({ fluidColor }),
		setPreset: (presetId) => {
			const p = PRESET_MAP[presetId] ?? PRESETS[0];
			set({
				waxColor: p.wax,
				fluidColor: p.fluid
			});
		},
		setPaused: (paused) => set({ paused }),
		togglePaused: () => set((s) => ({ paused: !s.paused })),
		toggleControls: () => set((s) => ({ controlsOpen: !s.controlsOpen })),
		setControlsOpen: (controlsOpen) => set({ controlsOpen }),
		setStats: (stats) => set({
			rising: stats.rising,
			falling: stats.falling,
			avgTemp: stats.avgTemp,
			etaCp: stats.etaCp,
			heatC: stats.heatC
		})
	}));
}
var root$1 = globalThis;
var useLavaStore = root$1.__lavalabStoreV3 ?? (root$1.__lavalabStoreV3 = createLavaStore());
function activePresetId(waxColor, fluidColor) {
	return matchingPreset(waxColor, fluidColor);
}
var persistBound = false;
function hydrateLavaStore() {
	if (persistBound || typeof window === "undefined") return;
	persistBound = true;
	const loaded = loadPersisted();
	if (Object.keys(loaded).length > 0) useLavaStore.setState(loaded);
	else if (window.innerWidth < 720) useLavaStore.setState({ controlsOpen: false });
	useLavaStore.subscribe((s) => {
		try {
			window.localStorage.setItem(STORAGE_KEY, JSON.stringify({
				version: 2,
				heat: s.heat,
				viscosity: s.viscosity,
				waxDensity: s.waxDensity,
				blobCount: s.blobCount,
				brightness: s.brightness,
				waxColor: s.waxColor,
				fluidColor: s.fluidColor,
				controlsOpen: s.controlsOpen
			}));
		} catch {}
	});
}
var root = globalThis;
function getSim() {
	if (!root.__lavalabSimV5) {
		const s = useLavaStore.getState();
		root.__lavalabSimV5 = new LavaSim(s.blobCount, s.waxDensity);
	}
	return root.__lavalabSimV5;
}
function resetSim() {
	const s = useLavaStore.getState();
	getSim().reset(s.blobCount, s.waxDensity);
}
function stirSim() {
	getSim().stir();
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-colors transition-transform duration-(--motion-quick) ease-(--ease-out) focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 disabled:pointer-events-none disabled:opacity-40 active:scale-[0.98] [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:bg-fg",
			ghost: "bg-transparent text-fg hover:bg-surface-2",
			outline: "border border-border bg-transparent text-fg hover:bg-surface-2",
			subtle: "bg-surface-2 text-fg hover:bg-border"
		},
		size: {
			default: "h-11 rounded-md px-4 text-sm",
			sm: "h-9 rounded-sm px-3 text-sm",
			icon: "size-11 rounded-md",
			"icon-sm": "size-9 rounded-sm"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Separator = import_react.forwardRef(({ className, orientation = "horizontal", decorative = true, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	decorative,
	orientation,
	className: cn("shrink-0 bg-border", orientation === "horizontal" ? "h-px w-full" : "h-full w-px", className),
	...props
}));
Separator.displayName = Root.displayName;
var Slider = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
	ref,
	className: cn("relative flex h-11 w-full touch-none items-center select-none", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
		className: "relative h-1.5 w-full grow overflow-hidden rounded-full bg-surface-2",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-accent" })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-4 rounded-full border border-border bg-fg shadow-sm ring-ring/60 transition-transform duration-(--motion-micro) focus-visible:outline-none focus-visible:ring-2 disabled:pointer-events-none" })]
}));
Slider.displayName = Slider$1.displayName;
var TooltipProvider = Provider;
var Tooltip = Root3;
var TooltipTrigger = Trigger;
var TooltipContent = import_react.forwardRef(({ className, sideOffset = 6, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	sideOffset,
	className: cn("z-50 rounded-sm border border-border bg-surface px-2.5 py-1.5 text-xs text-fg shadow-sm", "origin-(--radix-tooltip-content-transform-origin)", "data-[state=delayed-open]:animate-in data-[state=closed]:animate-out", className),
	...props
}) }));
TooltipContent.displayName = Content2.displayName;
function Toolbar() {
	const heat = useLavaStore((s) => s.heat);
	const viscosity = useLavaStore((s) => s.viscosity);
	const waxDensity = useLavaStore((s) => s.waxDensity);
	const blobCount = useLavaStore((s) => s.blobCount);
	const brightness = useLavaStore((s) => s.brightness);
	const waxColor = useLavaStore((s) => s.waxColor);
	const fluidColor = useLavaStore((s) => s.fluidColor);
	const controlsOpen = useLavaStore((s) => s.controlsOpen);
	const paused = useLavaStore((s) => s.paused);
	const rising = useLavaStore((s) => s.rising);
	const falling = useLavaStore((s) => s.falling);
	const heatC = useLavaStore((s) => s.heatC);
	const etaCp = useLavaStore((s) => s.etaCp);
	const setHeat = useLavaStore((s) => s.setHeat);
	const setViscosity = useLavaStore((s) => s.setViscosity);
	const setWaxDensity = useLavaStore((s) => s.setWaxDensity);
	const setBlobCount = useLavaStore((s) => s.setBlobCount);
	const setBrightness = useLavaStore((s) => s.setBrightness);
	const setWaxColor = useLavaStore((s) => s.setWaxColor);
	const setFluidColor = useLavaStore((s) => s.setFluidColor);
	const setPreset = useLavaStore((s) => s.setPreset);
	const togglePaused = useLavaStore((s) => s.togglePaused);
	const toggleControls = useLavaStore((s) => s.toggleControls);
	const presetId = activePresetId(waxColor, fluidColor);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-0 z-10 flex flex-col justify-between p-2 sm:p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "pointer-events-none flex items-start justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-auto rounded-xl border border-border bg-surface/92 px-3 py-2 shadow-sm sm:px-4 sm:py-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg leading-tight font-medium tracking-tight text-fg italic sm:text-2xl",
					children: "Lavalab"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-0.5 hidden text-xs text-muted sm:block",
					children: "Density · heat · viscosity"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-auto flex items-center gap-1 rounded-xl border border-border bg-surface/92 p-1 shadow-sm sm:gap-1.5 sm:p-1.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							size: "icon",
							"aria-label": paused ? "Play" : "Pause",
							onClick: togglePaused,
							children: paused ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {})
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TooltipContent, { children: [paused ? "Play" : "Pause", " · Space"] })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							size: "icon",
							"aria-label": "Reset lamp",
							onClick: resetSim,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {})
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, { children: "Reset · R" })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							size: "icon",
							"aria-label": "Stir globs",
							onClick: stirSim,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wind, {})
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, { children: "Stir · S" })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							size: "icon",
							"aria-label": controlsOpen ? "Hide controls" : "Show controls",
							"aria-expanded": controlsOpen,
							onClick: toggleControls,
							children: controlsOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsDown, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, {})
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TooltipContent, { children: [controlsOpen ? "Hide" : "Show", " controls · H"] })] })
				]
			})]
		}), controlsOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-none flex flex-col items-stretch gap-2 sm:items-center sm:gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none mx-auto flex items-center gap-2 rounded-lg border border-border bg-surface/92 px-3 py-1.5 text-xs text-muted shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, {
						className: "size-3.5 text-ember",
						"aria-hidden": true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums text-fg",
						children: [Math.round(heatC || 25 + heat * 70), "°"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-subtle",
						children: "·"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums",
						children: [rising, " rising"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-subtle",
						children: "·"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums",
						children: [falling, " falling"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden text-subtle sm:inline",
						children: "·"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "hidden tabular-nums sm:inline",
						children: [Math.round(etaCp), " cP"]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "pointer-events-auto max-h-[46dvh] w-full max-w-5xl overflow-y-auto rounded-xl border border-border bg-surface/94 p-2.5 shadow-sm sm:max-h-none sm:p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap items-center gap-1.5",
						children: PRESETS.map((p) => {
							const active = p.id === presetId;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": p.name,
								"aria-pressed": active,
								title: p.name,
								onClick: () => setPreset(p.id),
								className: cn("size-8 rounded-full border-2 transition-transform duration-(--motion-quick) ease-(--ease-out) sm:size-9", active ? "border-fg scale-105" : "border-border hover:border-muted"),
								style: { background: `linear-gradient(135deg, ${p.wax} 50%, ${p.fluid} 50%)` }
							}, p.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 grid gap-2 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwatchRow, {
							label: "Wax",
							value: waxColor,
							swatches: WAX_SWATCHES,
							onChange: setWaxColor
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwatchRow, {
							label: "Liquid",
							icon: "fluid",
							value: fluidColor,
							swatches: FLUID_SWATCHES,
							onChange: setFluidColor
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, { className: "my-2" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 items-end gap-x-3 gap-y-1 lg:flex lg:flex-row lg:gap-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Control, {
								label: "Heat",
								valueLabel: `${Math.round(25 + heat * 70)}°C`,
								value: heat,
								min: 0,
								max: 1,
								step: .01,
								onChange: setHeat
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Control, {
								label: "Viscosity",
								valueLabel: viscosity < .33 ? "Thin" : viscosity > .66 ? "Thick" : "Medium",
								value: viscosity,
								min: 0,
								max: 1,
								step: .01,
								onChange: setViscosity
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Control, {
								label: "Wax density",
								valueLabel: `${waxDensity.toFixed(2)} ρ`,
								value: waxDensity,
								min: .82,
								max: 1.18,
								step: .01,
								onChange: setWaxDensity
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Control, {
								label: "Globs",
								valueLabel: String(blobCount),
								value: blobCount,
								min: 4,
								max: 24,
								step: 1,
								onChange: (v) => setBlobCount(Math.round(v))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Control, {
								label: "Brightness",
								valueLabel: `${Math.round(brightness * 100)}%`,
								value: brightness,
								min: .15,
								max: 1,
								step: .01,
								onChange: setBrightness
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 hidden text-xs text-subtle sm:block",
						children: "Wax pools into a flat-topped mass, then heat peels off lumpy globs. Mix wax and liquid tones, or hide this panel with H."
					})
				]
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pointer-events-none flex justify-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none flex items-center gap-2 rounded-lg border border-border bg-surface/92 px-3 py-1.5 text-xs text-muted shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, {
						className: "size-3.5",
						"aria-hidden": true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums text-fg",
						children: [Math.round(brightness * 100), "%"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-subtle",
						children: "·"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums",
						children: [rising, " up"]
					})
				]
			})
		})]
	});
}
function SwatchRow({ label, value, swatches, onChange, icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex w-14 shrink-0 items-center gap-1 text-xs font-medium tracking-wider text-muted uppercase",
			children: [icon === "fluid" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Droplet, {
				className: "size-3",
				"aria-hidden": true
			}) : null, label]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-0 flex-wrap items-center gap-1",
			children: [swatches.map((color) => {
				const active = color.toLowerCase() === value.toLowerCase();
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": `${label} ${color}`,
					"aria-pressed": active,
					onClick: () => onChange(color),
					className: cn("size-6 rounded-full border-2 transition-transform duration-(--motion-quick) ease-(--ease-out)", active ? "border-fg scale-110" : "border-border hover:border-muted"),
					style: { backgroundColor: color }
				}, color);
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "relative size-6 overflow-hidden rounded-full border-2 border-border",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "sr-only",
					children: [
						"Custom ",
						label,
						" color"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "color",
					value,
					onChange: (e) => onChange(e.target.value),
					className: "absolute top-1/2 left-1/2 size-10 -translate-x-1/2 -translate-y-1/2 cursor-pointer border-0 p-0"
				})]
			})]
		})]
	});
}
function Control({ label, valueLabel, value, min, max, step, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex min-w-0 flex-1 flex-col gap-0.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex items-baseline justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs font-medium tracking-wider text-muted uppercase",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-xs tabular-nums text-fg",
				children: valueLabel
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
			value: [value],
			min,
			max,
			step,
			onValueChange: (vals) => {
				const next = vals[0];
				if (typeof next === "number") onChange(next);
			},
			"aria-label": label
		})]
	});
}
var routes_exports = /* @__PURE__ */ __exportAll({ component: () => Home });
var LampCanvas = (0, import_react.lazy)(() => import("./canvas-DsybDBxx.mjs").then((m) => ({ default: m.LampCanvas })));
function Home() {
	(0, import_react.useEffect)(() => {
		hydrateLavaStore();
	}, []);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			const tag = e.target?.tagName;
			if (tag === "INPUT" || tag === "TEXTAREA") return;
			if (e.code === "Space") {
				e.preventDefault();
				useLavaStore.getState().togglePaused();
			} else if (e.code === "KeyR") resetSim();
			else if (e.code === "KeyS") stirSim();
			else if (e.code === "KeyH") useLavaStore.getState().toggleControls();
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipProvider, {
		delayDuration: 200,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative h-dvh w-full overflow-hidden bg-bg text-fg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
				fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0 bg-bg",
					"aria-hidden": true
				}),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LampCanvas, {})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toolbar, {})]
		})
	});
}
//#endregion
export { mixHex as a, GLASS_LATHE as c, radiusAt as d, deriveGlow as i, LAMP_Y_MIN as l, getSim as n, BASE_LATHE as o, useLavaStore as r, CAP_LATHE as s, routes_exports as t, LIQUID_LATHE as u };
