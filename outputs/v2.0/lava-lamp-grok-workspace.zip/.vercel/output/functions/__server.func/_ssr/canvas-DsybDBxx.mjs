import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as Canvas, i as OrbitControls, n as ContactShadows, o as useFrame, r as Environment, s as useThree, t as AdaptiveDpr } from "../_libs/@react-three/drei+[...].mjs";
import { a as mixHex, c as GLASS_LATHE, d as radiusAt, i as deriveGlow, l as LAMP_Y_MIN, n as getSim, o as BASE_LATHE, r as useLavaStore, s as CAP_LATHE, u as LIQUID_LATHE } from "./routes-BJNlQzKJ.mjs";
import { B as Vector2, D as Plane, V as Vector3, g as LatheGeometry, h as InstancedBufferAttribute, k as Quaternion, m as IcosahedronGeometry, w as MeshStandardMaterial, x as Matrix4 } from "../_libs/monogrid__gainmap-js+three.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/canvas-DsybDBxx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var MAX_BLOBS = 24;
var UP = new Vector3(0, 1, 0);
var TMP = new Vector3();
var POS = new Vector3();
var QUAT = new Quaternion();
var SCL = new Vector3();
var MAT = new Matrix4();
var GRAB_PLANE = new Plane();
var GRAB_HIT = new Vector3();
var CAM_DIR = new Vector3();
function attachBlobShader(material) {
	material.onBeforeCompile = (shader) => {
		shader.uniforms.uTime = { value: 0 };
		shader.uniforms.uAmp = { value: .16 };
		material.userData.shader = shader;
		shader.vertexShader = shader.vertexShader.replace("#include <common>", `#include <common>
attribute float aSeed;
uniform float uTime;
uniform float uAmp;`);
		shader.vertexShader = shader.vertexShader.replace("#include <begin_vertex>", `float seed = aSeed;
vec3 transformed = vec3(position);
float t = uTime * (0.45 + fract(seed * 0.17) * 0.85);
float n = sin(transformed.x * 3.4 + seed) * sin(transformed.y * 4.6 + seed * 1.31 + t)
  * sin(transformed.z * 3.0 + seed * 0.73);
n += 0.55 * sin(dot(transformed, vec3(5.7, 6.4, 4.1)) + seed * 2.1 + t * 0.7);
n += 0.35 * sin(transformed.x * 8.4 + transformed.z * 7.1 + seed * 1.8);
n += 0.22 * sin(transformed.y * 9.2 + transformed.x * 5.1 + t * 1.1 + seed);
float lobe = 0.55 + 0.45 * smoothstep(-0.2, 0.8, transformed.y);
transformed += objectNormal * n * uAmp * lobe;
transformed.x *= 0.86 + 0.22 * sin(seed * 1.7);
transformed.z *= 0.86 + 0.2 * cos(seed * 1.31);
transformed.y *= 0.75 + 0.5 * fract(seed * 0.93);`);
	};
	material.customProgramCacheKey = () => "lavablob-v4";
}
function buildPoolGeometry(height, segments) {
	const h = Math.max(height, .05);
	const steps = 8;
	const pts = [new Vector2(.001, 0)];
	for (let i = 0; i <= steps; i++) {
		const y = h * i / steps;
		const r = Math.max(.05, radiusAt(LAMP_Y_MIN + y) * .94);
		pts.push(new Vector2(r, y));
	}
	return new LatheGeometry(pts, Math.max(16, segments));
}
function BlobField({ simRef, lowQuality, onGrabChange }) {
	const blobCount = useLavaStore((s) => s.blobCount);
	const meshRef = (0, import_react.useRef)(null);
	const poolRef = (0, import_react.useRef)(null);
	const capRef = (0, import_react.useRef)(null);
	const grabIndex = (0, import_react.useRef)(-1);
	const statsAcc = (0, import_react.useRef)(.2);
	const shapeTime = (0, import_react.useRef)(0);
	const poolKey = (0, import_react.useRef)("");
	const freeMap = (0, import_react.useRef)(new Array(MAX_BLOBS).fill(0));
	const onGrabChangeRef = (0, import_react.useRef)(onGrabChange);
	onGrabChangeRef.current = onGrabChange;
	const geo = (0, import_react.useMemo)(() => {
		const g = new IcosahedronGeometry(1, lowQuality ? 1 : 2);
		const seeds = new Float32Array(MAX_BLOBS);
		for (let i = 0; i < MAX_BLOBS; i++) seeds[i] = i * 1.618;
		g.setAttribute("aSeed", new InstancedBufferAttribute(seeds, 1));
		return g;
	}, [lowQuality]);
	const mat = (0, import_react.useMemo)(() => {
		const m = new MeshStandardMaterial({
			color: "#ff6a1a",
			emissive: "#ff8a3a",
			emissiveIntensity: .7,
			roughness: .26,
			metalness: .03,
			envMapIntensity: .45
		});
		attachBlobShader(m);
		return m;
	}, []);
	const poolMat = (0, import_react.useMemo)(() => new MeshStandardMaterial({
		color: "#ff6a1a",
		emissive: "#ff8a3a",
		emissiveIntensity: .55,
		roughness: .34,
		metalness: .02,
		side: 2
	}), []);
	const capMat = (0, import_react.useMemo)(() => new MeshStandardMaterial({
		color: "#ffb07a",
		emissive: "#ffd2a8",
		emissiveIntensity: .55,
		roughness: .08,
		metalness: .06,
		polygonOffset: true,
		polygonOffsetFactor: -1
	}), []);
	const poolGeo = (0, import_react.useMemo)(() => buildPoolGeometry(.55, lowQuality ? 16 : 28), [lowQuality]);
	const sides = lowQuality ? 16 : 28;
	(0, import_react.useEffect)(() => {
		return () => {
			geo.dispose();
			mat.dispose();
			poolMat.dispose();
			capMat.dispose();
			poolGeo.dispose();
		};
	}, [
		geo,
		mat,
		poolMat,
		capMat,
		poolGeo
	]);
	(0, import_react.useLayoutEffect)(() => {
		simRef.current.setCount(blobCount, useLavaStore.getState().waxDensity);
	}, [blobCount, simRef]);
	(0, import_react.useEffect)(() => {
		const onUp = () => {
			if (grabIndex.current < 0) return;
			simRef.current.endGrab();
			grabIndex.current = -1;
			onGrabChangeRef.current(false);
		};
		window.addEventListener("pointerup", onUp);
		window.addEventListener("pointercancel", onUp);
		return () => {
			window.removeEventListener("pointerup", onUp);
			window.removeEventListener("pointercancel", onUp);
		};
	}, [simRef]);
	useFrame((state, delta) => {
		const sim = simRef.current;
		const store = useLavaStore.getState();
		const params = {
			heat: store.heat,
			viscosity: store.viscosity,
			waxDensity: store.waxDensity,
			paused: store.paused
		};
		if (grabIndex.current >= 0) {
			state.camera.getWorldDirection(CAM_DIR);
			const b = sim.blobs[grabIndex.current];
			if (b && !b.pooled) {
				GRAB_PLANE.setFromNormalAndCoplanarPoint(CAM_DIR, TMP.set(b.x, b.y, b.z));
				state.raycaster.setFromCamera(state.pointer, state.camera);
				if (state.raycaster.ray.intersectPlane(GRAB_PLANE, GRAB_HIT)) sim.moveGrab(GRAB_HIT.x, GRAB_HIT.y, GRAB_HIT.z);
			}
		}
		const d = Math.min(delta, .1);
		const alpha = sim.step(d, params);
		if (!store.paused) shapeTime.current += d;
		statsAcc.current += d;
		if (statsAcc.current >= .18) {
			statsAcc.current = 0;
			const stats = sim.stats(params);
			store.setStats({
				rising: stats.rising,
				falling: stats.falling,
				avgTemp: stats.avgTemp,
				etaCp: stats.etaCentiPoise,
				heatC: stats.heatC
			});
		}
		const glow = deriveGlow(store.waxColor);
		mat.color.set(store.waxColor);
		mat.emissive.set(glow);
		mat.emissiveIntensity = .28 + store.brightness * .95;
		poolMat.color.set(store.waxColor);
		poolMat.emissive.set(glow);
		poolMat.emissiveIntensity = .22 + store.brightness * .75;
		const cap = mixHex(store.waxColor, "#fff4e4", .42);
		capMat.color.set(cap);
		capMat.emissive.set(mixHex(glow, "#ffffff", .45));
		capMat.emissiveIntensity = .35 + store.brightness * .7;
		const shader = mat.userData.shader;
		if (shader) shader.uniforms.uTime.value = shapeTime.current;
		const mesh = meshRef.current;
		const seedAttr = geo.getAttribute("aSeed");
		let drawn = 0;
		if (mesh) {
			for (let i = 0; i < sim.blobs.length; i++) {
				const b = sim.blobs[i];
				if (b.pooled) continue;
				POS.set(b.px + (b.x - b.px) * alpha, b.py + (b.y - b.py) * alpha, b.pz + (b.z - b.pz) * alpha);
				const speed = Math.hypot(b.vx, b.vy, b.vz);
				const stretch = 1 + Math.min(speed * .34, .5);
				const squash = 1 / Math.sqrt(stretch);
				SCL.set(b.r * b.sx * squash, b.r * b.sy * stretch, b.r * b.sz * squash);
				if (speed > .04) {
					TMP.set(b.vx, b.vy, b.vz).normalize();
					QUAT.setFromUnitVectors(UP, TMP);
				} else QUAT.identity();
				MAT.compose(POS, QUAT, SCL);
				mesh.setMatrixAt(drawn, MAT);
				seedAttr?.setX(drawn, b.seed);
				freeMap.current[drawn] = i;
				drawn += 1;
			}
			mesh.count = drawn;
			mesh.instanceMatrix.needsUpdate = true;
			if (seedAttr) seedAttr.needsUpdate = true;
		}
		const pool = sim.pool;
		const showPool = pool.ratio > .045;
		const h = Math.max(pool.height, .05);
		if (poolRef.current) {
			poolRef.current.visible = showPool;
			poolRef.current.position.set(0, LAMP_Y_MIN, 0);
			const key = `${Math.round(h * 24)}|${Math.round(pool.rTop * 40)}|${Math.round(pool.rBottom * 40)}`;
			if (key !== poolKey.current) {
				poolKey.current = key;
				const next = buildPoolGeometry(h, sides);
				poolRef.current.geometry.dispose();
				poolRef.current.geometry = next;
			}
		}
		if (capRef.current) {
			capRef.current.visible = showPool;
			capRef.current.position.set(0, LAMP_Y_MIN + h + .0015, 0);
			capRef.current.scale.set(pool.rTop, pool.rTop, 1);
		}
		const heater = state.scene.getObjectByName("heater-light");
		if (heater) heater.intensity = (10 + store.heat * 28) * (.45 + store.brightness);
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("instancedMesh", {
			ref: meshRef,
			args: [
				geo,
				mat,
				MAX_BLOBS
			],
			frustumCulled: false,
			onPointerDown: (e) => {
				e.stopPropagation();
				const instanceId = e.instanceId ?? -1;
				if (instanceId < 0) return;
				const blobIndex = freeMap.current[instanceId] ?? -1;
				const sim = simRef.current;
				const b = sim.blobs[blobIndex];
				if (!b || b.pooled) return;
				grabIndex.current = blobIndex;
				onGrabChange(true);
				sim.beginGrab(blobIndex, b.x, b.y, b.z);
			}
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
			ref: poolRef,
			geometry: poolGeo,
			material: poolMat,
			onPointerDown: (e) => {
				e.stopPropagation();
				simRef.current.pokePool(e.point.x, e.point.z);
			}
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
			ref: capRef,
			material: capMat,
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			raycast: () => void 0,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circleGeometry", { args: [1, sides] })
		})
	] });
}
function lathe(points) {
	return points.map(([r, y]) => new Vector2(r, y));
}
function Metal({ roughness = .32 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
		color: "#c8ccd1",
		metalness: .94,
		roughness,
		envMapIntensity: 1.15
	});
}
function LampVessel({ fluidColor, waxColor, heat, brightness, segments, lowQuality }) {
	const glassPts = (0, import_react.useMemo)(() => lathe(GLASS_LATHE), []);
	const liquidPts = (0, import_react.useMemo)(() => lathe(LIQUID_LATHE), []);
	const basePts = (0, import_react.useMemo)(() => lathe(BASE_LATHE), []);
	const capPts = (0, import_react.useMemo)(() => lathe(CAP_LATHE), []);
	const glow = deriveGlow(waxColor);
	const heater = (.7 + heat * 2.4) * (.45 + brightness);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		!lowQuality ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				2.4,
				-.7
			],
			renderOrder: 0,
			raycast: () => void 0,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("planeGeometry", { args: [1.6, 4.2] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", {
				color: glow,
				transparent: true,
				opacity: (.05 + heat * .05) * brightness,
				depthWrite: false,
				blending: 2
			})]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("latheGeometry", { args: [basePts, lowQuality ? 20 : 28] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metal, { roughness: .3 })] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				1.2,
				0
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
				.15,
				.17,
				.06,
				20
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: glow,
				emissive: glow,
				emissiveIntensity: heater * 1.6,
				roughness: .4
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			renderOrder: 1,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("latheGeometry", { args: [liquidPts, segments] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: fluidColor,
				transparent: true,
				opacity: lowQuality ? .46 : .5,
				roughness: .18,
				metalness: 0,
				emissive: fluidColor,
				emissiveIntensity: .28 + heat * .2 * brightness,
				depthWrite: false,
				side: 2
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			renderOrder: 3,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("latheGeometry", { args: [glassPts, segments] }), lowQuality ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#e7eef3",
				transparent: true,
				opacity: .16,
				roughness: .08,
				metalness: .05,
				depthWrite: false,
				side: 2
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshPhysicalMaterial", {
				color: "#eef3f6",
				roughness: .05,
				metalness: .02,
				transmission: .72,
				thickness: .05,
				ior: 1.48,
				clearcoat: .6,
				clearcoatRoughness: .08,
				transparent: true,
				opacity: 1,
				depthWrite: false,
				side: 2,
				envMapIntensity: 1.1
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("latheGeometry", { args: [capPts, lowQuality ? 16 : 24] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metal, { roughness: .26 })] })
	] });
}
function Studio({ lowQuality, brightness }) {
	const b = .35 + brightness * .9;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("color", {
			attach: "background",
			args: ["#0c0b0a"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("fog", {
			attach: "fog",
			args: [
				"#0c0b0a",
				14,
				28
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hemisphereLight", { args: [
			"#8a93a0",
			"#1a1410",
			.7 * b
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ambientLight", { intensity: .28 * b }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("spotLight", {
			position: [
				2.4,
				6.8,
				4.2
			],
			angle: .42,
			penumbra: .85,
			intensity: 90 * b,
			color: "#f4f7fb"
		}),
		lowQuality ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointLight", {
			position: [
				1.8,
				2.8,
				3.2
			],
			intensity: 12 * b,
			color: "#fff4e6",
			distance: 12
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("directionalLight", {
			position: [
				-3.5,
				4,
				-2
			],
			intensity: .55 * b,
			color: "#d5deea"
		})] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			position: [
				0,
				0,
				0
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circleGeometry", { args: [6, lowQuality ? 20 : 36] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#141210",
				roughness: .9,
				metalness: .06
			})]
		})
	] });
}
function World() {
	const lowQuality = useThree((s) => s.size.width) < 640;
	const heat = useLavaStore((s) => s.heat);
	const brightness = useLavaStore((s) => s.brightness);
	const waxColor = useLavaStore((s) => s.waxColor);
	const fluidColor = useLavaStore((s) => s.fluidColor);
	const [grabbing, setGrabbing] = (0, import_react.useState)(false);
	const segments = lowQuality ? 18 : 36;
	const simRef = (0, import_react.useMemo)(() => ({ current: getSim() }), []);
	simRef.current = getSim();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdaptiveDpr, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LookRig, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Studio, {
			lowQuality,
			brightness
		}),
		lowQuality ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnvMap, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointLight", {
			name: "heater-light",
			position: [
				0,
				1.18,
				0
			],
			color: deriveGlow(waxColor),
			intensity: (14 + heat * 26) * (.5 + brightness),
			distance: 3.2,
			decay: 2
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LampVessel, {
			fluidColor,
			waxColor,
			heat,
			brightness,
			segments,
			lowQuality
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlobField, {
			simRef,
			lowQuality,
			onGrabChange: setGrabbing
		}),
		lowQuality ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactShadows, {
			position: [
				0,
				.01,
				0
			],
			opacity: .42,
			scale: 8,
			blur: 2.2,
			far: 3.5,
			frames: 1
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrbitControls, {
			makeDefault: true,
			enabled: !grabbing,
			enablePan: false,
			enableDamping: true,
			dampingFactor: .08,
			minDistance: 3.6,
			maxDistance: 11,
			minPolarAngle: .25,
			maxPolarAngle: Math.PI / 2 - .04,
			target: [
				0,
				2.2,
				0
			],
			rotateSpeed: .72
		})
	] });
}
function LookRig() {
	const gl = useThree((s) => s.gl);
	const scene = useThree((s) => s.scene);
	useFrame(() => {
		const b = useLavaStore.getState().brightness;
		gl.toneMappingExposure = .62 + b * 1.05;
		scene.environmentIntensity = .28 + b * .5;
	});
	return null;
}
function EnvMap() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Environment, {
		resolution: 128,
		frames: 1,
		environmentIntensity: .7,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
			12,
			16,
			12
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", {
			color: "#5c5248",
			side: 1
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				4.6,
				7.2,
				-3
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				2.1,
				12,
				12
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", { color: "#fff0cc" })]
		})]
	});
}
function LampCanvas() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Canvas, {
		className: "touch-none",
		dpr: [1, 1.5],
		gl: {
			antialias: true,
			alpha: false,
			powerPreference: "high-performance",
			toneMapping: 4,
			toneMappingExposure: 1.2
		},
		camera: {
			position: [
				.85,
				2.2,
				5.35
			],
			fov: 34,
			near: .1,
			far: 40
		},
		onCreated: ({ gl, scene, camera, size }) => {
			gl.setClearColor("#0c0b0a");
			scene.environmentIntensity = .55;
			if (size.width < 640) {
				camera.position.set(.2, 2.25, 6.35);
				gl.setPixelRatio(1);
			}
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(World, {})
	});
}
//#endregion
export { LampCanvas };
