/** Inner collision profile: [height, radius]. Tall rocket column. */
export const INNER_PROFILE: readonly (readonly [number, number])[] = [
  [1.28, 0.17],
  [1.52, 0.26],
  [2.0, 0.36],
  [2.55, 0.4],
  [3.15, 0.35],
  [3.55, 0.23],
  [3.82, 0.13],
];

export const LAMP_Y_MIN = INNER_PROFILE[0][0];
export const LAMP_Y_MAX = INNER_PROFILE[INNER_PROFILE.length - 1][0];

export function radiusAt(y: number): number {
  const pts = INNER_PROFILE;
  if (y <= pts[0][0]) return pts[0][1];
  const last = pts[pts.length - 1];
  if (y >= last[0]) return last[1];
  for (let i = 0; i < pts.length - 1; i++) {
    const y0 = pts[i][0];
    const y1 = pts[i + 1][0];
    if (y <= y1) {
      const u = (y - y0) / (y1 - y0);
      return pts[i][1] + (pts[i + 1][1] - pts[i][1]) * u;
    }
  }
  return last[1];
}

/** Lathe points as [radius, y] for the outer glass wall. */
export const GLASS_LATHE: readonly (readonly [number, number])[] = [
  [0.19, 1.2],
  [0.26, 1.48],
  [0.36, 1.95],
  [0.44, 2.5],
  [0.44, 2.85],
  [0.38, 3.25],
  [0.26, 3.58],
  [0.16, 3.84],
  [0.17, 3.9],
];

export const LIQUID_LATHE: readonly (readonly [number, number])[] = INNER_PROFILE.map(
  ([y, r]) => [r * 0.96, y] as const,
);

/** Brushed-metal pedestal, wider at the foot. */
export const BASE_LATHE: readonly (readonly [number, number])[] = [
  [0.17, 1.26],
  [0.22, 1.1],
  [0.3, 0.62],
  [0.4, 0.16],
  [0.5, 0.05],
  [0.5, 0],
];

/** Bullet cap. */
export const CAP_LATHE: readonly (readonly [number, number])[] = [
  [0.15, 3.78],
  [0.16, 3.9],
  [0.12, 4.02],
  [0.04, 4.28],
  [0.012, 4.4],
];
