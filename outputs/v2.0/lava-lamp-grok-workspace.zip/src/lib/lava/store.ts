import { create } from "zustand";
import {
  PRESET_MAP,
  PRESETS,
  isPreset,
  matchingPreset,
  type PresetId,
} from "./presets";

const STORAGE_KEY = "lavalab-v2";

export interface LavaStore {
  heat: number;
  viscosity: number;
  waxDensity: number;
  blobCount: number;
  brightness: number;
  waxColor: string;
  fluidColor: string;
  controlsOpen: boolean;
  paused: boolean;
  rising: number;
  falling: number;
  avgTemp: number;
  etaCp: number;
  heatC: number;
  setHeat: (heat: number) => void;
  setViscosity: (viscosity: number) => void;
  setWaxDensity: (waxDensity: number) => void;
  setBlobCount: (blobCount: number) => void;
  setBrightness: (brightness: number) => void;
  setWaxColor: (waxColor: string) => void;
  setFluidColor: (fluidColor: string) => void;
  setPreset: (presetId: PresetId) => void;
  setPaused: (paused: boolean) => void;
  togglePaused: () => void;
  toggleControls: () => void;
  setControlsOpen: (open: boolean) => void;
  setStats: (stats: {
    rising: number;
    falling: number;
    avgTemp: number;
    etaCp: number;
    heatC: number;
  }) => void;
}

const magma = PRESET_MAP.magma;

const defaults = {
  heat: 0.62,
  viscosity: 0.42,
  waxDensity: 1.04,
  blobCount: 12,
  brightness: 0.72,
  waxColor: magma.wax,
  fluidColor: magma.fluid,
  controlsOpen: true,

  paused: false,
  rising: 0,
  falling: 0,
  avgTemp: 0,
  etaCp: 0,
  heatC: 0,
};

function loadPersisted(): Partial<LavaStore> {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY) ?? window.localStorage.getItem("lavalab-v1");
    if (!raw) return {};
    const parsed = JSON.parse(raw) as { version?: number } & Partial<LavaStore> & {
      presetId?: unknown;
    };
    const fromPreset = isPreset(parsed.presetId) ? PRESET_MAP[parsed.presetId] : null;
    const waxColor =
      typeof parsed.waxColor === "string" ? parsed.waxColor : (fromPreset?.wax ?? defaults.waxColor);
    const fluidColor =
      typeof parsed.fluidColor === "string"
        ? parsed.fluidColor
        : (fromPreset?.fluid ?? defaults.fluidColor);
    return {
      heat: clamp01(parsed.heat, defaults.heat),
      viscosity: clamp01(parsed.viscosity, defaults.viscosity),
      waxDensity: clampNum(parsed.waxDensity, 0.82, 1.18, defaults.waxDensity),
      blobCount: Math.round(clampNum(parsed.blobCount, 4, 24, defaults.blobCount)),
      brightness: clamp01(parsed.brightness, defaults.brightness),
      waxColor,
      fluidColor,
      controlsOpen: parsed.controlsOpen !== false,
    };
  } catch {
    return {};
  }
}

function clamp01(v: unknown, fallback: number) {
  return typeof v === "number" && Number.isFinite(v) ? Math.min(1, Math.max(0, v)) : fallback;
}

function clampNum(v: unknown, min: number, max: number, fallback: number) {
  return typeof v === "number" && Number.isFinite(v) ? Math.min(max, Math.max(min, v)) : fallback;
}

function createLavaStore() {
  return create<LavaStore>((set) => ({
    ...defaults,
    setHeat: (heat) => set({ heat }),
    setViscosity: (viscosity) => set({ viscosity }),
    setWaxDensity: (waxDensity) => set({ waxDensity }),
    setBlobCount: (blobCount) => set({ blobCount }),
    setBrightness: (brightness) => set({ brightness }),
    setWaxColor: (waxColor) => set({ waxColor }),
    setFluidColor: (fluidColor) => set({ fluidColor }),
    setPreset: (presetId) => {
      const p = PRESET_MAP[presetId] ?? PRESETS[0];
      set({ waxColor: p.wax, fluidColor: p.fluid });
    },
    setPaused: (paused) => set({ paused }),
    togglePaused: () => set((s) => ({ paused: !s.paused })),
    toggleControls: () => set((s) => ({ controlsOpen: !s.controlsOpen })),
    setControlsOpen: (controlsOpen) => set({ controlsOpen }),
    setStats: (stats) =>
      set({
        rising: stats.rising,
        falling: stats.falling,
        avgTemp: stats.avgTemp,
        etaCp: stats.etaCp,
        heatC: stats.heatC,
      }),
  }));
}

type LavaStoreApi = ReturnType<typeof createLavaStore>;

const root = globalThis as typeof globalThis & { __lavalabStoreV3?: LavaStoreApi };
export const useLavaStore = root.__lavalabStoreV3 ?? (root.__lavalabStoreV3 = createLavaStore());

export function activePresetId(waxColor: string, fluidColor: string): PresetId | null {
  return matchingPreset(waxColor, fluidColor);
}

let persistBound = false;

export function hydrateLavaStore() {
  if (persistBound || typeof window === "undefined") return;
  persistBound = true;
  const loaded = loadPersisted();
  if (Object.keys(loaded).length > 0) useLavaStore.setState(loaded);
  else if (window.innerWidth < 720) useLavaStore.setState({ controlsOpen: false });
  useLavaStore.subscribe((s) => {
    try {
      window.localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({
          version: 2,
          heat: s.heat,
          viscosity: s.viscosity,
          waxDensity: s.waxDensity,
          blobCount: s.blobCount,
          brightness: s.brightness,
          waxColor: s.waxColor,
          fluidColor: s.fluidColor,
          controlsOpen: s.controlsOpen,
        }),
      );
    } catch {
      /* ignore quota */
    }
  });
}
