import { LavaSim } from "./physics";
import { useLavaStore } from "./store";

const root = globalThis as typeof globalThis & { __lavalabSimV5?: LavaSim };

export function getSim(): LavaSim {
  if (!root.__lavalabSimV5) {
    const s = useLavaStore.getState();
    root.__lavalabSimV5 = new LavaSim(s.blobCount, s.waxDensity);
  }
  return root.__lavalabSimV5;
}


export function resetSim() {
  const s = useLavaStore.getState();
  getSim().reset(s.blobCount, s.waxDensity);
}

export function stirSim() {
  getSim().stir();
}
