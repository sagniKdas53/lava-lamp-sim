export type PresetId =
  | "magma"
  | "aurora"
  | "nocturne"
  | "ember"
  | "kelp"
  | "ice"
  | "rose"
  | "citrus"
  | "ink"
  | "cobalt"
  | "honey"
  | "orchid";

export interface LampPreset {
  id: PresetId;
  name: string;
  wax: string;
  fluid: string;
}

export const PRESETS: LampPreset[] = [
  { id: "magma", name: "Magma", wax: "#ffd15c", fluid: "#ff6a12" },
  { id: "ember", name: "Ember", wax: "#ff5a38", fluid: "#c43218" },
  { id: "honey", name: "Honey", wax: "#f5c518", fluid: "#c46a12" },
  { id: "nocturne", name: "Nocturne", wax: "#f7e7c4", fluid: "#3a2c22" },
  { id: "rose", name: "Rose", wax: "#ff6b8a", fluid: "#c2185b" },
  { id: "orchid", name: "Orchid", wax: "#ff4fa8", fluid: "#7a2ee0" },
  { id: "aurora", name: "Aurora", wax: "#3ee0d0", fluid: "#0e8f8a" },
  { id: "cobalt", name: "Azure", wax: "#e4ff55", fluid: "#1a96ff" },
  { id: "ice", name: "Ice", wax: "#e8f4ff", fluid: "#2a4a5c" },
  { id: "kelp", name: "Kelp", wax: "#b6e14a", fluid: "#1f7a32" },
  { id: "citrus", name: "Citrus", wax: "#d6ff4a", fluid: "#7a8a12" },
  { id: "ink", name: "Ink", wax: "#f4efe6", fluid: "#1a1816" },
];

export const PRESET_MAP: Record<PresetId, LampPreset> = Object.fromEntries(
  PRESETS.map((p) => [p.id, p]),
) as Record<PresetId, LampPreset>;

export const WAX_SWATCHES = [
  "#ffd15c",
  "#ff6a1a",
  "#ff5a38",
  "#f5c518",
  "#ff4fa8",
  "#ff6b8a",
  "#d87cff",
  "#e4ff55",
  "#3ee0d0",
  "#6aa8ff",
  "#e8f4ff",
  "#b6e14a",
  "#f4efe6",
] as const;

export const FLUID_SWATCHES = [
  "#ff6a12",
  "#c43218",
  "#7a2ee0",
  "#1a96ff",
  "#0e8f8a",
  "#c2185b",
  "#1f7a32",
  "#156a78",
  "#3a2c22",
  "#2a4a5c",
  "#1a1816",
] as const;

export function isPreset(v: unknown): v is PresetId {
  return typeof v === "string" && v in PRESET_MAP;
}

export function parseHex(hex: string): [number, number, number] {
  const h = hex.replace("#", "");
  const full = h.length === 3 ? h.replace(/./g, (c) => c + c) : h;
  const n = Number.parseInt(full, 16);
  if (!Number.isFinite(n)) return [255, 120, 40];
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export function mixHex(a: string, b: string, t: number): string {
  const [ar, ag, ab] = parseHex(a);
  const [br, bg, bb] = parseHex(b);
  const r = Math.round(ar + (br - ar) * t);
  const g = Math.round(ag + (bg - ag) * t);
  const bl = Math.round(ab + (bb - ab) * t);
  return `#${[r, g, bl].map((c) => c.toString(16).padStart(2, "0")).join("")}`;
}

export function deriveGlow(wax: string) {
  return mixHex(wax, "#ffffff", 0.34);
}

export function deriveGlass(fluid: string) {
  return mixHex(fluid, "#f3e6c8", 0.52);
}

export function matchingPreset(wax: string, fluid: string): PresetId | null {
  const w = wax.toLowerCase();
  const f = fluid.toLowerCase();
  const found = PRESETS.find((p) => p.wax.toLowerCase() === w && p.fluid.toLowerCase() === f);
  return found?.id ?? null;
}

