import { LAMP_Y_MAX, LAMP_Y_MIN, radiusAt } from "./lamp-profile";

export const FIXED_DT = 1 / 60;
const MAX_STEPS = 3;
const LIQUID_DENSITY = 1;
const THERMAL_EXPANSION = 0.28;
const BUOYANCY = 400;
const DRAG = 0.4;
const RESTITUTION = 0.1;
const MAX_SPEED = 2.05;
const COHESION = 0.62;
const PI = Math.PI;

export interface SimParams {
  heat: number;
  viscosity: number;
  waxDensity: number;
  paused: boolean;
}

export interface BlobState {
  id: number;
  pooled: boolean;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  px: number;
  py: number;
  pz: number;
  r: number;
  t: number;
  rhoJitter: number;
  seed: number;
  sx: number;
  sy: number;
  sz: number;
}

export interface PoolMetrics {
  height: number;
  surfaceY: number;
  rBottom: number;
  rTop: number;
  ratio: number;
}

export interface SimStats {
  rising: number;
  falling: number;
  avgTemp: number;
  etaCentiPoise: number;
  heatC: number;
}

function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}

function rand(min: number, max: number) {
  return min + Math.random() * (max - min);
}

export function effectiveEta(viscosity: number, heat: number) {
  const base = 0.22 + viscosity * 1.65;
  return base * Math.exp(-1.15 * heat);
}

export function heatCelsius(heat: number) {
  return 25 + heat * 70;
}

export function etaCentiPoise(viscosity: number, heat: number) {
  return effectiveEta(viscosity, heat) * 320;
}

function blobVolume(r: number) {
  return (4 / 3) * PI * r * r * r;
}

export class LavaSim {
  blobs: BlobState[] = [];
  pool: PoolMetrics = { height: 0.35, surfaceY: LAMP_Y_MIN + 0.35, rBottom: 0.32, rTop: 0.36, ratio: 1 };
  private acc = 0;
  private nextId = 1;
  private ejectAcc = 0;
  private grab: { index: number; x: number; y: number; z: number } | null = null;
  private lastGrab = { x: 0, y: 0, z: 0 };

  constructor(count: number, waxDensity: number) {
    this.reset(count, waxDensity);
  }

  reset(count: number, _waxDensity: number) {
    this.blobs = [];
    this.nextId = 1;
    this.acc = 0;
    this.ejectAcc = 0;
    this.grab = null;
    const n = clamp(Math.round(count), 4, 24);
    for (let i = 0; i < n; i++) this.blobs.push(this.makeBlob(true, i));
    this.refreshPool();
  }

  setCount(count: number, _waxDensity: number) {
    const n = clamp(Math.round(count), 4, 24);
    while (this.blobs.length > n) {
      const free = this.blobs.findIndex((b) => !b.pooled);
      this.blobs.splice(free >= 0 ? free : this.blobs.length - 1, 1);
    }
    while (this.blobs.length < n) this.blobs.push(this.makeBlob(true, this.blobs.length));
    this.refreshPool();
  }

  beginGrab(index: number, x: number, y: number, z: number) {
    if (index < 0 || index >= this.blobs.length) return;
    const b = this.blobs[index];
    if (!b || b.pooled) return;
    this.grab = { index, x, y, z };
    this.lastGrab = { x, y, z };
  }

  moveGrab(x: number, y: number, z: number) {
    if (!this.grab) return;
    this.grab.x = x;
    this.grab.y = y;
    this.grab.z = z;
  }

  endGrab() {
    if (!this.grab) return;
    const b = this.blobs[this.grab.index];
    if (b) {
      b.vx = clamp(b.vx, -MAX_SPEED, MAX_SPEED);
      b.vy = clamp(b.vy, -MAX_SPEED, MAX_SPEED);
      b.vz = clamp(b.vz, -MAX_SPEED, MAX_SPEED);
    }
    this.grab = null;
  }

  stir() {
    let released = 0;
    const keep = Math.max(4, this.blobs.length - 8);
    let pooledLeft = this.blobs.reduce((n, b) => n + (b.pooled ? 1 : 0), 0);
    for (const b of this.blobs) {
      if (b.pooled && released < 8 && pooledLeft > keep) {
        this.releaseBlob(b, rand(-PI, PI), 0.55);
        released += 1;
        pooledLeft -= 1;
      } else if (!b.pooled) {
        b.vx += rand(-1.4, 1.4);
        b.vy += rand(0.15, 1.05);
        b.vz += rand(-1.4, 1.4);
        b.t = clamp(b.t + rand(0.04, 0.18), 0, 1);
      }
    }

    this.refreshPool();
  }

  pokePool(x: number, z: number) {
    const b = this.blobs.find((blob) => blob.pooled);
    if (!b) return;
    const ang = Math.atan2(z, x);
    this.releaseBlob(b, ang, 0.7);
    this.refreshPool();
  }

  step(dt: number, params: SimParams): number {
    if (params.paused) return 1;
    this.acc += Math.min(dt, 0.1);
    let steps = 0;
    while (this.acc >= FIXED_DT && steps < MAX_STEPS) {
      this.fixedStep(FIXED_DT, params);
      this.acc -= FIXED_DT;
      steps += 1;
    }
    if (steps === MAX_STEPS) this.acc = 0;
    return this.acc / FIXED_DT;
  }

  stats(params: SimParams): SimStats {
    let rising = 0;
    let falling = 0;
    let temp = 0;
    let n = 0;
    for (const b of this.blobs) {
      if (b.pooled) continue;
      n += 1;
      temp += b.t;
      if (b.vy > 0.04) rising += 1;
      else if (b.vy < -0.04) falling += 1;
    }
    return {
      rising,
      falling,
      avgTemp: n ? temp / n : 0,
      etaCentiPoise: etaCentiPoise(params.viscosity, params.heat),
      heatC: heatCelsius(params.heat),
    };
  }

  private makeBlob(pooled: boolean, i: number): BlobState {
    const r = 0.068 + (i % 5) * 0.014 + (i % 3) * 0.008;
    const seed = rand(0.2, 9.7) + i * 0.37;
    const sx = rand(0.78, 1.22);
    const sy = rand(0.7, 1.72);
    const sz = rand(0.78, 1.22);
    const vol = Math.cbrt(1 / (sx * sy * sz));

    return {
      id: this.nextId++,
      pooled,
      x: 0,
      y: LAMP_Y_MIN,
      z: 0,
      vx: 0,
      vy: 0,
      vz: 0,
      px: 0,
      py: LAMP_Y_MIN,
      pz: 0,
      r,
      t: pooled ? 0.12 : 0.7,
      rhoJitter: 1 + ((i * 17) % 7) * 0.006 - 0.018,
      seed,
      sx: sx * vol,
      sy: sy * vol,
      sz: sz * vol,
    };
  }

  private releaseBlob(b: BlobState, ang: number, spread: number) {
    const surface = this.pool.surfaceY;
    const rad = this.pool.rTop * spread * rand(0.15, 0.85);
    b.pooled = false;
    b.t = clamp(0.62 + rand(0, 0.28), 0, 1);
    b.x = Math.cos(ang) * rad;
    b.z = Math.sin(ang) * rad;
    b.y = surface + b.r * 0.55;
    b.px = b.x;
    b.py = b.y;
    b.pz = b.z;
    b.vx = Math.cos(ang) * rand(-0.12, 0.28);
    b.vz = Math.sin(ang) * rand(-0.12, 0.28);
    b.vy = rand(0.22, 0.55);
  }

  private refreshPool() {
    let vol = 0;
    let total = 0;
    for (const b of this.blobs) {
      const v = blobVolume(b.r);
      total += v;
      if (b.pooled) vol += v;
    }
    let h = 0.28;
    for (let i = 0; i < 5; i++) {
      const midR = radiusAt(LAMP_Y_MIN + h * 0.5) * 0.94;
      h = total === 0 ? 0.04 : (vol / Math.max(0.08, PI * midR * midR)) * 1.18;
      h = clamp(h, 0.04, 1.45);
    }
    if (vol <= 1e-6) h = 0.04;
    this.pool = {
      height: h,
      surfaceY: LAMP_Y_MIN + h,
      rBottom: radiusAt(LAMP_Y_MIN) * 0.94,
      rTop: radiusAt(LAMP_Y_MIN + h) * 0.94,
      ratio: total > 0 ? vol / total : 0,
    };
  }

  private fixedStep(dt: number, params: SimParams) {
    const eta = effectiveEta(params.viscosity, params.heat);
    const heat = params.heat;
    const blobs = this.blobs;

    for (const b of blobs) {
      if (b.pooled) continue;
      b.px = b.x;
      b.py = b.y;
      b.pz = b.z;
    }

    this.ejectAcc += dt * (0.06 + heat * 1.35);
    const freeCount = blobs.reduce((n, b) => n + (b.pooled ? 0 : 1), 0);
    const maxFree = Math.max(3, blobs.length - 5);
    const canEject = heat > 0.16 && this.pool.ratio > 0.34 && freeCount < maxFree;
    if (canEject && this.ejectAcc > 0.62) {
      this.ejectAcc = 0;
      const ready = blobs.find((b) => b.pooled);
      if (ready) this.releaseBlob(ready, rand(0, PI * 2), 0.58);
    }


    const grab = this.grab;
    const surfaceY = this.pool.surfaceY;

    for (let i = 0; i < blobs.length; i++) {
      const b = blobs[i];
      if (b.pooled) continue;

      const span = LAMP_Y_MAX - LAMP_Y_MIN;
      const ny = clamp((b.y - LAMP_Y_MIN) / span, 0, 1);
      const heatRate = heat * 1.7 * Math.exp(-ny * 4.2);
      const coolRate = 0.16 + 1.05 * ny * ny + (heat < 0.12 ? 1.4 : 0);
      b.t = clamp(b.t + (heatRate * (1 - b.t) - coolRate * b.t) * dt, 0, 1);

      if (grab && grab.index === i) {
        const dx = grab.x - this.lastGrab.x;
        const dy = grab.y - this.lastGrab.y;
        const dz = grab.z - this.lastGrab.z;
        b.x += (grab.x - b.x) * 0.55;
        b.y += (grab.y - b.y) * 0.55;
        b.z += (grab.z - b.z) * 0.55;
        b.vx = dx / dt;
        b.vy = dy / dt;
        b.vz = dz / dt;
        this.constrainWall(b);
        continue;
      }

      const rho = params.waxDensity * b.rhoJitter * (1 - THERMAL_EXPANSION * b.t);
      const fy = (LIQUID_DENSITY - rho) * BUOYANCY * b.r * b.r;
      const jitter = (0.28 + 0.7 * (1 - params.viscosity)) * 0.4;
      const drag = DRAG * eta * (0.5 + b.r * 2.4);
      const denom = 1 + drag * dt;
      b.vx = (b.vx + (Math.random() - 0.5) * jitter * dt) / denom;
      b.vy = (b.vy + fy * dt) / denom;
      b.vz = (b.vz + (Math.random() - 0.5) * jitter * dt) / denom;

      const sp = Math.hypot(b.vx, b.vy, b.vz);
      if (sp > MAX_SPEED) {
        const s = MAX_SPEED / sp;
        b.vx *= s;
        b.vy *= s;
        b.vz *= s;
      }

      b.x += b.vx * dt;
      b.y += b.vy * dt;
      b.z += b.vz * dt;
      this.constrainWall(b);

      const nearPool = b.y < surfaceY + b.r * 1.05;
      const sinking = b.vy < 0.1;
      const coolEnough = b.t < (heat < 0.18 ? 0.72 : 0.38);
      if (nearPool && sinking && coolEnough) {
        b.pooled = true;
        b.vx = 0;
        b.vy = 0;
        b.vz = 0;
      }
    }

    if (grab) this.lastGrab = { x: grab.x, y: grab.y, z: grab.z };
    this.resolveFree();
    this.refreshPool();
  }

  private constrainWall(b: BlobState) {
    const yMin = LAMP_Y_MIN + b.r * 0.35;
    const yMax = LAMP_Y_MAX - b.r - 0.02;
    if (b.y < yMin) {
      b.y = yMin;
      if (b.vy < 0) b.vy *= -RESTITUTION;
    } else if (b.y > yMax) {
      b.y = yMax;
      if (b.vy > 0) b.vy *= -RESTITUTION;
    }

    const wall = Math.max(0.05, radiusAt(b.y) - b.r - 0.012);
    const rho = Math.hypot(b.x, b.z);
    if (rho > wall && rho > 1e-6) {
      const s = wall / rho;
      b.x *= s;
      b.z *= s;
      const nx = b.x / (wall || 1);
      const nz = b.z / (wall || 1);
      const vn = b.vx * nx + b.vz * nz;
      if (vn > 0) {
        b.vx -= (1 + RESTITUTION) * vn * nx;
        b.vz -= (1 + RESTITUTION) * vn * nz;
      }
    }
  }

  private resolveFree() {
    const blobs = this.blobs;
    const n = blobs.length;
    for (let i = 0; i < n; i++) {
      const a = blobs[i];
      if (a.pooled) continue;
      for (let j = i + 1; j < n; j++) {
        const b = blobs[j];
        if (b.pooled) continue;
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const dz = b.z - a.z;
        const distSq = dx * dx + dy * dy + dz * dz;
        const minDist = a.r + b.r;
        const cohesionR = minDist * 1.22;
        if (distSq > cohesionR * cohesionR || distSq < 1e-10) continue;
        const dist = Math.sqrt(distSq);
        const nx = dx / dist;
        const ny = dy / dist;
        const nz = dz / dist;
        if (dist < minDist) {
          const pen = (minDist - dist) * 0.5;
          a.x -= nx * pen;
          a.y -= ny * pen;
          a.z -= nz * pen;
          b.x += nx * pen;
          b.y += ny * pen;
          b.z += nz * pen;
          const rv = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny + (b.vz - a.vz) * nz;
          if (rv < 0) {
            const impulse = -(1 + RESTITUTION) * rv * 0.5;
            a.vx -= impulse * nx;
            a.vy -= impulse * ny;
            a.vz -= impulse * nz;
            b.vx += impulse * nx;
            b.vy += impulse * ny;
            b.vz += impulse * nz;
          }
        } else {
          const pull = ((cohesionR - dist) / cohesionR) * COHESION * 0.005;
          a.vx += nx * pull;
          a.vy += ny * pull;
          a.vz += nz * pull;
          b.vx -= nx * pull;
          b.vy -= ny * pull;
          b.vz -= nz * pull;
        }
      }
    }
  }
}
