import { AdaptiveDpr, ContactShadows, Environment, OrbitControls } from "@react-three/drei";
import { useFrame, useThree } from "@react-three/fiber";
import { useMemo, useState } from "react";
import * as THREE from "three";
import { getSim } from "@/lib/lava/instance";
import { deriveGlow } from "@/lib/lava/presets";
import { useLavaStore } from "@/lib/lava/store";
import { BlobField } from "./blobs";
import { LampVessel, Studio } from "./lamp";

export function World() {
  const width = useThree((s) => s.size.width);
  const lowQuality = width < 640;
  const heat = useLavaStore((s) => s.heat);
  const brightness = useLavaStore((s) => s.brightness);
  const waxColor = useLavaStore((s) => s.waxColor);
  const fluidColor = useLavaStore((s) => s.fluidColor);
  const [grabbing, setGrabbing] = useState(false);
  const segments = lowQuality ? 18 : 36;
  const simRef = useMemo(() => ({ current: getSim() }), []);
  simRef.current = getSim();

  return (
    <>
      <AdaptiveDpr />
      <LookRig />
      <Studio lowQuality={lowQuality} brightness={brightness} />
      {lowQuality ? null : <EnvMap />}
      <pointLight
        name="heater-light"
        position={[0, 1.18, 0]}
        color={deriveGlow(waxColor)}
        intensity={(14 + heat * 26) * (0.5 + brightness)}
        distance={3.2}
        decay={2}
      />
      <LampVessel
        fluidColor={fluidColor}
        waxColor={waxColor}
        heat={heat}
        brightness={brightness}
        segments={segments}
        lowQuality={lowQuality}
      />
      <BlobField simRef={simRef} lowQuality={lowQuality} onGrabChange={setGrabbing} />
      {lowQuality ? null : (
        <ContactShadows position={[0, 0.01, 0]} opacity={0.42} scale={8} blur={2.2} far={3.5} frames={1} />
      )}
      <OrbitControls
        makeDefault
        enabled={!grabbing}
        enablePan={false}
        enableDamping
        dampingFactor={0.08}
        minDistance={3.6}
        maxDistance={11}
        minPolarAngle={0.25}
        maxPolarAngle={Math.PI / 2 - 0.04}
        target={[0, 2.2, 0]}
        rotateSpeed={0.72}
      />
    </>
  );
}

function LookRig() {
  const gl = useThree((s) => s.gl);
  const scene = useThree((s) => s.scene);
  useFrame(() => {
    const b = useLavaStore.getState().brightness;
    gl.toneMappingExposure = 0.62 + b * 1.05;
    scene.environmentIntensity = 0.28 + b * 0.5;
  });
  return null;
}

function EnvMap() {
  return (
    <Environment resolution={128} frames={1} environmentIntensity={0.7}>
      <mesh>
        <sphereGeometry args={[12, 16, 12]} />
        <meshBasicMaterial color="#5c5248" side={THREE.BackSide} />
      </mesh>
      <mesh position={[4.6, 7.2, -3]}>
        <sphereGeometry args={[2.1, 12, 12]} />
        <meshBasicMaterial color="#fff0cc" />
      </mesh>
    </Environment>
  );
}
