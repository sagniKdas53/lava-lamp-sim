import { ChevronsDown, Droplet, Flame, Pause, Play, RotateCcw, SlidersHorizontal, Sun, Wind } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { resetSim, stirSim } from "@/lib/lava/instance";
import { FLUID_SWATCHES, PRESETS, WAX_SWATCHES } from "@/lib/lava/presets";
import { activePresetId, useLavaStore } from "@/lib/lava/store";
import { cn } from "@/lib/utils";

export function Toolbar() {
  const heat = useLavaStore((s) => s.heat);
  const viscosity = useLavaStore((s) => s.viscosity);
  const waxDensity = useLavaStore((s) => s.waxDensity);
  const blobCount = useLavaStore((s) => s.blobCount);
  const brightness = useLavaStore((s) => s.brightness);
  const waxColor = useLavaStore((s) => s.waxColor);
  const fluidColor = useLavaStore((s) => s.fluidColor);
  const controlsOpen = useLavaStore((s) => s.controlsOpen);
  const paused = useLavaStore((s) => s.paused);
  const rising = useLavaStore((s) => s.rising);
  const falling = useLavaStore((s) => s.falling);
  const heatC = useLavaStore((s) => s.heatC);
  const etaCp = useLavaStore((s) => s.etaCp);
  const setHeat = useLavaStore((s) => s.setHeat);
  const setViscosity = useLavaStore((s) => s.setViscosity);
  const setWaxDensity = useLavaStore((s) => s.setWaxDensity);
  const setBlobCount = useLavaStore((s) => s.setBlobCount);
  const setBrightness = useLavaStore((s) => s.setBrightness);
  const setWaxColor = useLavaStore((s) => s.setWaxColor);
  const setFluidColor = useLavaStore((s) => s.setFluidColor);
  const setPreset = useLavaStore((s) => s.setPreset);
  const togglePaused = useLavaStore((s) => s.togglePaused);
  const toggleControls = useLavaStore((s) => s.toggleControls);
  const presetId = activePresetId(waxColor, fluidColor);

  return (
    <div className="pointer-events-none absolute inset-0 z-10 flex flex-col justify-between p-2 sm:p-5">
      <header className="pointer-events-none flex items-start justify-between gap-2">
        <div className="pointer-events-auto rounded-xl border border-border bg-surface/92 px-3 py-2 shadow-sm sm:px-4 sm:py-2.5">
          <p className="font-display text-lg leading-tight font-medium tracking-tight text-fg italic sm:text-2xl">
            Lavalab
          </p>
          <p className="mt-0.5 hidden text-xs text-muted sm:block">Density · heat · viscosity</p>
        </div>

        <div className="pointer-events-auto flex items-center gap-1 rounded-xl border border-border bg-surface/92 p-1 shadow-sm sm:gap-1.5 sm:p-1.5">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                type="button"
                variant="ghost"
                size="icon"
                aria-label={paused ? "Play" : "Pause"}
                onClick={togglePaused}
              >
                {paused ? <Play /> : <Pause />}
              </Button>
            </TooltipTrigger>
            <TooltipContent>{paused ? "Play" : "Pause"} · Space</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button type="button" variant="ghost" size="icon" aria-label="Reset lamp" onClick={resetSim}>
                <RotateCcw />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Reset · R</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button type="button" variant="ghost" size="icon" aria-label="Stir globs" onClick={stirSim}>
                <Wind />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Stir · S</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                type="button"
                variant="ghost"
                size="icon"
                aria-label={controlsOpen ? "Hide controls" : "Show controls"}
                aria-expanded={controlsOpen}
                onClick={toggleControls}
              >
                {controlsOpen ? <ChevronsDown /> : <SlidersHorizontal />}
              </Button>
            </TooltipTrigger>
            <TooltipContent>{controlsOpen ? "Hide" : "Show"} controls · H</TooltipContent>
          </Tooltip>
        </div>
      </header>

      {controlsOpen ? (
        <div className="pointer-events-none flex flex-col items-stretch gap-2 sm:items-center sm:gap-3">
          <div className="pointer-events-none mx-auto flex items-center gap-2 rounded-lg border border-border bg-surface/92 px-3 py-1.5 text-xs text-muted shadow-sm">
            <Flame className="size-3.5 text-ember" aria-hidden />
            <span className="tabular-nums text-fg">{Math.round(heatC || 25 + heat * 70)}°</span>
            <span className="text-subtle">·</span>
            <span className="tabular-nums">{rising} rising</span>
            <span className="text-subtle">·</span>
            <span className="tabular-nums">{falling} falling</span>
            <span className="hidden text-subtle sm:inline">·</span>
            <span className="hidden tabular-nums sm:inline">{Math.round(etaCp)} cP</span>
          </div>

          <section className="pointer-events-auto max-h-[46dvh] w-full max-w-5xl overflow-y-auto rounded-xl border border-border bg-surface/94 p-2.5 shadow-sm sm:max-h-none sm:p-4">

            <div className="flex flex-wrap items-center gap-1.5">
              {PRESETS.map((p) => {
                const active = p.id === presetId;
                return (
                  <button
                    key={p.id}
                    type="button"
                    aria-label={p.name}
                    aria-pressed={active}
                    title={p.name}
                    onClick={() => setPreset(p.id)}
                    className={cn(
                      "size-8 rounded-full border-2 transition-transform duration-(--motion-quick) ease-(--ease-out) sm:size-9",
                      active ? "border-fg scale-105" : "border-border hover:border-muted",
                    )}
                    style={{ background: `linear-gradient(135deg, ${p.wax} 50%, ${p.fluid} 50%)` }}
                  />
                );
              })}
            </div>

            <div className="mt-2 grid gap-2 sm:grid-cols-2">
              <SwatchRow
                label="Wax"
                value={waxColor}
                swatches={WAX_SWATCHES}
                onChange={setWaxColor}
              />
              <SwatchRow
                label="Liquid"
                icon="fluid"
                value={fluidColor}
                swatches={FLUID_SWATCHES}
                onChange={setFluidColor}
              />
            </div>

            <Separator className="my-2" />

            <div className="grid grid-cols-2 items-end gap-x-3 gap-y-1 lg:flex lg:flex-row lg:gap-5">
              <Control
                label="Heat"
                valueLabel={`${Math.round(25 + heat * 70)}°C`}
                value={heat}
                min={0}
                max={1}
                step={0.01}
                onChange={setHeat}
              />
              <Control
                label="Viscosity"
                valueLabel={viscosity < 0.33 ? "Thin" : viscosity > 0.66 ? "Thick" : "Medium"}
                value={viscosity}
                min={0}
                max={1}
                step={0.01}
                onChange={setViscosity}
              />
              <Control
                label="Wax density"
                valueLabel={`${waxDensity.toFixed(2)} ρ`}
                value={waxDensity}
                min={0.82}
                max={1.18}
                step={0.01}
                onChange={setWaxDensity}
              />
              <Control
                label="Globs"
                valueLabel={String(blobCount)}
                value={blobCount}
                min={4}
                max={24}
                step={1}
                onChange={(v) => setBlobCount(Math.round(v))}
              />
              <Control
                label="Brightness"
                valueLabel={`${Math.round(brightness * 100)}%`}
                value={brightness}
                min={0.15}
                max={1}
                step={0.01}
                onChange={setBrightness}
              />
            </div>
            <p className="mt-2 hidden text-xs text-subtle sm:block">
              Wax pools into a flat-topped mass, then heat peels off lumpy globs. Mix wax and liquid
              tones, or hide this panel with H.
            </p>
          </section>
        </div>
      ) : (
        <div className="pointer-events-none flex justify-center">
          <div className="pointer-events-none flex items-center gap-2 rounded-lg border border-border bg-surface/92 px-3 py-1.5 text-xs text-muted shadow-sm">
            <Sun className="size-3.5" aria-hidden />
            <span className="tabular-nums text-fg">{Math.round(brightness * 100)}%</span>
            <span className="text-subtle">·</span>
            <span className="tabular-nums">{rising} up</span>
          </div>
        </div>
      )}
    </div>
  );
}

function SwatchRow({
  label,
  value,
  swatches,
  onChange,
  icon,
}: {
  label: string;
  value: string;
  swatches: readonly string[];
  onChange: (color: string) => void;
  icon?: "fluid";
}) {
  return (
    <div className="flex min-w-0 items-center gap-2">
      <span className="flex w-14 shrink-0 items-center gap-1 text-xs font-medium tracking-wider text-muted uppercase">
        {icon === "fluid" ? <Droplet className="size-3" aria-hidden /> : null}
        {label}
      </span>
      <div className="flex min-w-0 flex-wrap items-center gap-1">
        {swatches.map((color) => {
          const active = color.toLowerCase() === value.toLowerCase();
          return (
            <button
              key={color}
              type="button"
              aria-label={`${label} ${color}`}
              aria-pressed={active}
              onClick={() => onChange(color)}
              className={cn(
                "size-6 rounded-full border-2 transition-transform duration-(--motion-quick) ease-(--ease-out)",
                active ? "border-fg scale-110" : "border-border hover:border-muted",
              )}
              style={{ backgroundColor: color }}
            />
          );
        })}
        <label className="relative size-6 overflow-hidden rounded-full border-2 border-border">
          <span className="sr-only">Custom {label} color</span>
          <input
            type="color"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="absolute top-1/2 left-1/2 size-10 -translate-x-1/2 -translate-y-1/2 cursor-pointer border-0 p-0"
          />
        </label>
      </div>
    </div>
  );
}

function Control({
  label,
  valueLabel,
  value,
  min,
  max,
  step,
  onChange,
}: {
  label: string;
  valueLabel: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (value: number) => void;
}) {
  return (
    <label className="flex min-w-0 flex-1 flex-col gap-0.5">
      <span className="flex items-baseline justify-between gap-2">
        <span className="text-xs font-medium tracking-wider text-muted uppercase">{label}</span>
        <span className="font-mono text-xs tabular-nums text-fg">{valueLabel}</span>
      </span>
      <Slider
        value={[value]}
        min={min}
        max={max}
        step={step}
        onValueChange={(vals) => {
          const next = vals[0];
          if (typeof next === "number") onChange(next);
        }}
        aria-label={label}
      />
    </label>
  );
}
