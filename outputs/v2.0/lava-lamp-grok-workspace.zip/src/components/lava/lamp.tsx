import { useMemo } from "react";
import * as THREE from "three";
import { BASE_LATHE, CAP_LATHE, GLASS_LATHE, LIQUID_LATHE } from "@/lib/lava/lamp-profile";
import { deriveGlow } from "@/lib/lava/presets";

function lathe(points: readonly (readonly [number, number])[]) {
  return points.map(([r, y]) => new THREE.Vector2(r, y));
}

function Metal({ roughness = 0.32 }: { roughness?: number }) {
  return (
    <meshStandardMaterial
      color="#c8ccd1"
      metalness={0.94}
      roughness={roughness}
      envMapIntensity={1.15}
    />
  );
}

export function LampVessel({
  fluidColor,
  waxColor,
  heat,
  brightness,
  segments,
  lowQuality,
}: {
  fluidColor: string;
  waxColor: string;
  heat: number;
  brightness: number;
  segments: number;
  lowQuality: boolean;
}) {
  const glassPts = useMemo(() => lathe(GLASS_LATHE), []);
  const liquidPts = useMemo(() => lathe(LIQUID_LATHE), []);
  const basePts = useMemo(() => lathe(BASE_LATHE), []);
  const capPts = useMemo(() => lathe(CAP_LATHE), []);
  const glow = deriveGlow(waxColor);
  const heater = (0.7 + heat * 2.4) * (0.45 + brightness);

  return (
    <group>
      {!lowQuality ? (
        <mesh position={[0, 2.4, -0.7]} renderOrder={0} raycast={() => undefined}>
          <planeGeometry args={[1.6, 4.2]} />
          <meshBasicMaterial
            color={glow}
            transparent
            opacity={(0.05 + heat * 0.05) * brightness}
            depthWrite={false}
            blending={THREE.AdditiveBlending}
          />
        </mesh>
      ) : null}

      <mesh>
        <latheGeometry args={[basePts, lowQuality ? 20 : 28]} />
        <Metal roughness={0.3} />
      </mesh>
      <mesh position={[0, 1.2, 0]}>
        <cylinderGeometry args={[0.15, 0.17, 0.06, 20]} />
        <meshStandardMaterial
          color={glow}
          emissive={glow}
          emissiveIntensity={heater * 1.6}
          roughness={0.4}
        />
      </mesh>

      <mesh renderOrder={1}>
        <latheGeometry args={[liquidPts, segments]} />
        <meshStandardMaterial
          color={fluidColor}
          transparent
          opacity={lowQuality ? 0.46 : 0.5}
          roughness={0.18}
          metalness={0}
          emissive={fluidColor}
          emissiveIntensity={0.28 + heat * 0.2 * brightness}
          depthWrite={false}
          side={THREE.DoubleSide}
        />
      </mesh>

      <mesh renderOrder={3}>
        <latheGeometry args={[glassPts, segments]} />
        {lowQuality ? (
          <meshStandardMaterial
            color="#e7eef3"
            transparent
            opacity={0.16}
            roughness={0.08}
            metalness={0.05}
            depthWrite={false}
            side={THREE.DoubleSide}
          />
        ) : (
          <meshPhysicalMaterial
            color="#eef3f6"
            roughness={0.05}
            metalness={0.02}
            transmission={0.72}
            thickness={0.05}
            ior={1.48}
            clearcoat={0.6}
            clearcoatRoughness={0.08}
            transparent
            opacity={1}
            depthWrite={false}
            side={THREE.DoubleSide}
            envMapIntensity={1.1}
          />
        )}
      </mesh>

      <mesh>
        <latheGeometry args={[capPts, lowQuality ? 16 : 24]} />
        <Metal roughness={0.26} />
      </mesh>
    </group>
  );
}

export function Studio({
  lowQuality,
  brightness,
}: {
  lowQuality: boolean;
  brightness: number;
}) {
  const b = 0.35 + brightness * 0.9;
  return (
    <>
      <color attach="background" args={["#0c0b0a"]} />
      <fog attach="fog" args={["#0c0b0a", 14, 28]} />
      <hemisphereLight args={["#8a93a0", "#1a1410", 0.7 * b]} />
      <ambientLight intensity={0.28 * b} />
      <spotLight
        position={[2.4, 6.8, 4.2]}
        angle={0.42}
        penumbra={0.85}
        intensity={90 * b}
        color="#f4f7fb"
      />
      {lowQuality ? null : (
        <>
          <pointLight position={[1.8, 2.8, 3.2]} intensity={12 * b} color="#fff4e6" distance={12} />
          <directionalLight position={[-3.5, 4, -2]} intensity={0.55 * b} color="#d5deea" />
        </>
      )}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]}>
        <circleGeometry args={[6, lowQuality ? 20 : 36]} />
        <meshStandardMaterial color="#141210" roughness={0.9} metalness={0.06} />
      </mesh>
    </>
  );
}