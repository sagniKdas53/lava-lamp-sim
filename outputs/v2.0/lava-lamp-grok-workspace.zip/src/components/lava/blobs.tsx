import { useFrame } from "@react-three/fiber";
import { useEffect, useLayoutEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { LAMP_Y_MIN, radiusAt } from "@/lib/lava/lamp-profile";
import type { LavaSim } from "@/lib/lava/physics";
import { deriveGlow, mixHex } from "@/lib/lava/presets";
import { useLavaStore } from "@/lib/lava/store";

const MAX_BLOBS = 24;
const UP = new THREE.Vector3(0, 1, 0);
const TMP = new THREE.Vector3();
const POS = new THREE.Vector3();
const QUAT = new THREE.Quaternion();
const SCL = new THREE.Vector3();
const MAT = new THREE.Matrix4();
const GRAB_PLANE = new THREE.Plane();
const GRAB_HIT = new THREE.Vector3();
const CAM_DIR = new THREE.Vector3();

function attachBlobShader(material: THREE.MeshStandardMaterial) {
  material.onBeforeCompile = (shader) => {
    shader.uniforms.uTime = { value: 0 };
    shader.uniforms.uAmp = { value: 0.16 };
    material.userData.shader = shader;
    shader.vertexShader = shader.vertexShader.replace(
      "#include <common>",
      `#include <common>
attribute float aSeed;
uniform float uTime;
uniform float uAmp;`,
    );
    shader.vertexShader = shader.vertexShader.replace(
      "#include <begin_vertex>",
      `float seed = aSeed;
vec3 transformed = vec3(position);
float t = uTime * (0.45 + fract(seed * 0.17) * 0.85);
float n = sin(transformed.x * 3.4 + seed) * sin(transformed.y * 4.6 + seed * 1.31 + t)
  * sin(transformed.z * 3.0 + seed * 0.73);
n += 0.55 * sin(dot(transformed, vec3(5.7, 6.4, 4.1)) + seed * 2.1 + t * 0.7);
n += 0.35 * sin(transformed.x * 8.4 + transformed.z * 7.1 + seed * 1.8);
n += 0.22 * sin(transformed.y * 9.2 + transformed.x * 5.1 + t * 1.1 + seed);
float lobe = 0.55 + 0.45 * smoothstep(-0.2, 0.8, transformed.y);
transformed += objectNormal * n * uAmp * lobe;
transformed.x *= 0.86 + 0.22 * sin(seed * 1.7);
transformed.z *= 0.86 + 0.2 * cos(seed * 1.31);
transformed.y *= 0.75 + 0.5 * fract(seed * 0.93);`,
    );
  };
  material.customProgramCacheKey = () => "lavablob-v4";
}

function buildPoolGeometry(height: number, segments: number) {
  const h = Math.max(height, 0.05);
  const steps = 8;
  const pts: THREE.Vector2[] = [new THREE.Vector2(0.001, 0)];
  for (let i = 0; i <= steps; i++) {
    const y = (h * i) / steps;
    const r = Math.max(0.05, radiusAt(LAMP_Y_MIN + y) * 0.94);
    pts.push(new THREE.Vector2(r, y));
  }
  return new THREE.LatheGeometry(pts, Math.max(16, segments));
}



export function BlobField({
  simRef,
  lowQuality,
  onGrabChange,
}: {
  simRef: { current: LavaSim };
  lowQuality: boolean;
  onGrabChange: (grabbing: boolean) => void;
}) {
  const blobCount = useLavaStore((s) => s.blobCount);
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const poolRef = useRef<THREE.Mesh>(null);
  const capRef = useRef<THREE.Mesh>(null);
  const grabIndex = useRef(-1);

  const statsAcc = useRef(0.2);
  const shapeTime = useRef(0);
  const poolKey = useRef("");
  const freeMap = useRef<number[]>(new Array(MAX_BLOBS).fill(0));
  const onGrabChangeRef = useRef(onGrabChange);
  onGrabChangeRef.current = onGrabChange;


  const geo = useMemo(() => {
    const g = new THREE.IcosahedronGeometry(1, lowQuality ? 1 : 2);
    const seeds = new Float32Array(MAX_BLOBS);
    for (let i = 0; i < MAX_BLOBS; i++) seeds[i] = i * 1.618;
    g.setAttribute("aSeed", new THREE.InstancedBufferAttribute(seeds, 1));
    return g;
  }, [lowQuality]);

  const mat = useMemo(() => {
    const m = new THREE.MeshStandardMaterial({
      color: "#ff6a1a",
      emissive: "#ff8a3a",
      emissiveIntensity: 0.7,
      roughness: 0.26,
      metalness: 0.03,
      envMapIntensity: 0.45,
    });
    attachBlobShader(m);
    return m;
  }, []);

  const poolMat = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: "#ff6a1a",
        emissive: "#ff8a3a",
        emissiveIntensity: 0.55,
        roughness: 0.34,
        metalness: 0.02,
        side: THREE.DoubleSide,
      }),
    [],
  );
  const capMat = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: "#ffb07a",
        emissive: "#ffd2a8",
        emissiveIntensity: 0.55,
        roughness: 0.08,
        metalness: 0.06,
        polygonOffset: true,
        polygonOffsetFactor: -1,
      }),
    [],
  );

  const poolGeo = useMemo(() => buildPoolGeometry(0.55, lowQuality ? 16 : 28), [lowQuality]);
  const sides = lowQuality ? 16 : 28;


  useEffect(() => {
    return () => {
      geo.dispose();
      mat.dispose();
      poolMat.dispose();
      capMat.dispose();
      poolGeo.dispose();
    };
  }, [geo, mat, poolMat, capMat, poolGeo]);


  useLayoutEffect(() => {
    simRef.current.setCount(blobCount, useLavaStore.getState().waxDensity);
  }, [blobCount, simRef]);

  useEffect(() => {
    const onUp = () => {
      if (grabIndex.current < 0) return;
      simRef.current.endGrab();
      grabIndex.current = -1;
      onGrabChangeRef.current(false);
    };
    window.addEventListener("pointerup", onUp);
    window.addEventListener("pointercancel", onUp);
    return () => {
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("pointercancel", onUp);
    };
  }, [simRef]);

  useFrame((state, delta) => {
    const sim = simRef.current;
    const store = useLavaStore.getState();
    const params = {
      heat: store.heat,
      viscosity: store.viscosity,
      waxDensity: store.waxDensity,
      paused: store.paused,
    };

    if (grabIndex.current >= 0) {
      state.camera.getWorldDirection(CAM_DIR);
      const b = sim.blobs[grabIndex.current];
      if (b && !b.pooled) {
        GRAB_PLANE.setFromNormalAndCoplanarPoint(CAM_DIR, TMP.set(b.x, b.y, b.z));
        state.raycaster.setFromCamera(state.pointer, state.camera);
        if (state.raycaster.ray.intersectPlane(GRAB_PLANE, GRAB_HIT)) {
          sim.moveGrab(GRAB_HIT.x, GRAB_HIT.y, GRAB_HIT.z);
        }
      }
    }

    const d = Math.min(delta, 0.1);
    const alpha = sim.step(d, params);
    if (!store.paused) shapeTime.current += d;

    statsAcc.current += d;
    if (statsAcc.current >= 0.18) {
      statsAcc.current = 0;
      const stats = sim.stats(params);
      store.setStats({
        rising: stats.rising,
        falling: stats.falling,
        avgTemp: stats.avgTemp,
        etaCp: stats.etaCentiPoise,
        heatC: stats.heatC,
      });
    }

    const glow = deriveGlow(store.waxColor);
    mat.color.set(store.waxColor);
    mat.emissive.set(glow);
    mat.emissiveIntensity = 0.28 + store.brightness * 0.95;
    poolMat.color.set(store.waxColor);
    poolMat.emissive.set(glow);
    poolMat.emissiveIntensity = 0.22 + store.brightness * 0.75;
    const cap = mixHex(store.waxColor, "#fff4e4", 0.42);
    capMat.color.set(cap);
    capMat.emissive.set(mixHex(glow, "#ffffff", 0.45));
    capMat.emissiveIntensity = 0.35 + store.brightness * 0.7;

    const shader = mat.userData.shader as { uniforms: { uTime: { value: number } } } | undefined;
    if (shader) shader.uniforms.uTime.value = shapeTime.current;

    const mesh = meshRef.current;
    const seedAttr = geo.getAttribute("aSeed") as THREE.InstancedBufferAttribute | undefined;
    let drawn = 0;
    if (mesh) {
      for (let i = 0; i < sim.blobs.length; i++) {
        const b = sim.blobs[i];
        if (b.pooled) continue;
        POS.set(
          b.px + (b.x - b.px) * alpha,
          b.py + (b.y - b.py) * alpha,
          b.pz + (b.z - b.pz) * alpha,
        );
        const speed = Math.hypot(b.vx, b.vy, b.vz);
        const stretch = 1 + Math.min(speed * 0.34, 0.5);
        const squash = 1 / Math.sqrt(stretch);
        SCL.set(b.r * b.sx * squash, b.r * b.sy * stretch, b.r * b.sz * squash);
        if (speed > 0.04) {
          TMP.set(b.vx, b.vy, b.vz).normalize();
          QUAT.setFromUnitVectors(UP, TMP);
        } else {
          QUAT.identity();
        }
        MAT.compose(POS, QUAT, SCL);
        mesh.setMatrixAt(drawn, MAT);
        seedAttr?.setX(drawn, b.seed);
        freeMap.current[drawn] = i;
        drawn += 1;
      }
      mesh.count = drawn;
      mesh.instanceMatrix.needsUpdate = true;
      if (seedAttr) seedAttr.needsUpdate = true;
    }

    const pool = sim.pool;
    const showPool = pool.ratio > 0.045;
    const h = Math.max(pool.height, 0.05);
    if (poolRef.current) {
      poolRef.current.visible = showPool;
      poolRef.current.position.set(0, LAMP_Y_MIN, 0);
      const key = `${Math.round(h * 24)}|${Math.round(pool.rTop * 40)}|${Math.round(pool.rBottom * 40)}`;
      if (key !== poolKey.current) {
        poolKey.current = key;
        const next = buildPoolGeometry(h, sides);
        poolRef.current.geometry.dispose();
        poolRef.current.geometry = next;
      }
    }
    if (capRef.current) {
      capRef.current.visible = showPool;
      capRef.current.position.set(0, LAMP_Y_MIN + h + 0.0015, 0);
      capRef.current.scale.set(pool.rTop, pool.rTop, 1);
    }



    const heater = state.scene.getObjectByName("heater-light") as THREE.PointLight | undefined;
    if (heater) heater.intensity = (10 + store.heat * 28) * (0.45 + store.brightness);
  });

  return (
    <group>
      <instancedMesh
        ref={meshRef}
        args={[geo, mat, MAX_BLOBS]}
        frustumCulled={false}
        onPointerDown={(e) => {

          e.stopPropagation();
          const instanceId = e.instanceId ?? -1;
          if (instanceId < 0) return;
          const blobIndex = freeMap.current[instanceId] ?? -1;
          const sim = simRef.current;
          const b = sim.blobs[blobIndex];
          if (!b || b.pooled) return;
          grabIndex.current = blobIndex;
          onGrabChange(true);
          sim.beginGrab(blobIndex, b.x, b.y, b.z);
        }}
      />
      <mesh
        ref={poolRef}
        geometry={poolGeo}
        material={poolMat}
        onPointerDown={(e) => {
          e.stopPropagation();
          simRef.current.pokePool(e.point.x, e.point.z);
        }}
      />
      <mesh ref={capRef} material={capMat} rotation={[-Math.PI / 2, 0, 0]} raycast={() => undefined}>
        <circleGeometry args={[1, sides]} />
      </mesh>
    </group>
  );
}
