import { Canvas } from "@react-three/fiber";
import * as THREE from "three";
import { World } from "./scene";

export function LampCanvas() {
  return (
    <Canvas
      className="touch-none"
      dpr={[1, 1.5]}
      gl={{
        antialias: true,
        alpha: false,
        powerPreference: "high-performance",
        toneMapping: THREE.ACESFilmicToneMapping,
        toneMappingExposure: 1.2,
      }}
      camera={{ position: [0.85, 2.2, 5.35], fov: 34, near: 0.1, far: 40 }}
      onCreated={({ gl, scene, camera, size }) => {
        gl.setClearColor("#0c0b0a");
        scene.environmentIntensity = 0.55;
        if (size.width < 640) {
          camera.position.set(0.2, 2.25, 6.35);
          gl.setPixelRatio(1);
        }
      }}
    >
      <World />
    </Canvas>
  );
}
