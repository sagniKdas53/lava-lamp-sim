import { createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense, useEffect } from "react";
import { Toolbar } from "@/components/lava/toolbar";
import { TooltipProvider } from "@/components/ui/tooltip";
import { resetSim, stirSim } from "@/lib/lava/instance";
import { hydrateLavaStore, useLavaStore } from "@/lib/lava/store";

const LampCanvas = lazy(() =>
  import("@/components/lava/canvas").then((m) => ({ default: m.LampCanvas })),
);

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  useEffect(() => {
    hydrateLavaStore();
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if (e.code === "Space") {
        e.preventDefault();
        useLavaStore.getState().togglePaused();
      } else if (e.code === "KeyR") {
        resetSim();
      } else if (e.code === "KeyS") {
        stirSim();
      } else if (e.code === "KeyH") {
        useLavaStore.getState().toggleControls();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <TooltipProvider delayDuration={200}>
      <div className="relative h-dvh w-full overflow-hidden bg-bg text-fg">
        <Suspense fallback={<div className="absolute inset-0 bg-bg" aria-hidden />}>
          <LampCanvas />
        </Suspense>
        <Toolbar />
      </div>
    </TooltipProvider>
  );
}
