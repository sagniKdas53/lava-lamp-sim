import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { LampSim, LampParams, MAX_BLOBS, profileFor, vesselR, LampShape } from './sim';
import { lavaFragment, lavaVertex } from './shaders';

export type Quality = 'low' | 'high';

interface LampEntry {
  group: THREE.Group;
  sim: LampSim;
  mat: THREE.ShaderMaterial;
  box: THREE.Mesh;
  parts: THREE.Object3D[];
  light: THREE.PointLight;
  params: LampParams;
  shape: LampShape;
  ring: THREE.Mesh;
}

const LAMP_SPACING = 0.78;

function latheFrom(points: [number, number][], segs = 64) {
  return new THREE.LatheGeometry(
    points.map(([r, y]) => new THREE.Vector2(r, y)),
    segs,
  );
}

export class LampScene {
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera: THREE.PerspectiveCamera;
  controls: OrbitControls;
  lamps: LampEntry[] = [];
  paused = false;
  quality: Quality = 'high';
  private raf = 0;
  private last = performance.now();
  private acc = 0;
  private readonly SUB = 1 / 120;
  private silver: THREE.MeshStandardMaterial;
  private black: THREE.MeshStandardMaterial;
  private glass: THREE.MeshPhysicalMaterial;
  private ringMat: THREE.MeshBasicMaterial;
  private tmpV = new THREE.Vector3();
  private raycaster = new THREE.Raycaster();
  private ptrDown: { x: number; y: number } | null = null;
  private resizeObs: ResizeObserver;
  private userMoved = false;
  selected = 0;
  onSelect?: (i: number) => void;
  onFps?: (fps: number) => void;
  private fpsAcc = 0;
  private fpsN = 0;

  constructor(private canvas: HTMLCanvasElement) {
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance',
    });
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.applyQuality();

    this.camera = new THREE.PerspectiveCamera(32, 1, 0.05, 50);
    this.camera.position.set(0.35, 0.75, 2.9);

    this.controls = new OrbitControls(this.camera, canvas);
    this.controls.target.set(0, 0.42, 0);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.08;
    this.controls.minDistance = 1.2;
    this.controls.maxDistance = 7;
    this.controls.maxPolarAngle = Math.PI * 0.56;
    this.controls.enablePan = false;
    this.controls.maxDistance = 8;
    this.controls.addEventListener('start', () => {
      this.userMoved = true;
    });

    // Environment for metal/glass reflections
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    this.scene.environmentIntensity = 0.3;
    pmrem.dispose();

    const hemi = new THREE.HemisphereLight(0x6f7fa8, 0x0d0a12, 0.35);
    this.scene.add(hemi);
    const key = new THREE.DirectionalLight(0xfff4e6, 0.85);
    key.position.set(-1.8, 3, 2.2);
    this.scene.add(key);

    const floor = new THREE.Mesh(
      new THREE.CircleGeometry(9, 64),
      new THREE.MeshStandardMaterial({
        color: 0x08070d,
        roughness: 0.95,
        metalness: 0.0,
        envMapIntensity: 0.08,
      }),
    );
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -0.5;
    this.scene.add(floor);

    this.silver = new THREE.MeshStandardMaterial({ color: 0xd2d6dc, metalness: 0.95, roughness: 0.28 });
    this.black = new THREE.MeshStandardMaterial({ color: 0x17171a, metalness: 0.7, roughness: 0.32 });
    this.glass = new THREE.MeshPhysicalMaterial({
      color: 0xffffff,
      metalness: 0,
      roughness: 0.04,
      transparent: true,
      opacity: 0.45,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      envMapIntensity: 1.0,
    });
    this.ringMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.0 });

    this.resizeObs = new ResizeObserver(() => this.resize());
    this.resizeObs.observe(canvas.parentElement ?? canvas);
    this.resize();

    canvas.addEventListener('pointerdown', this.onPointerDown);
    canvas.addEventListener('pointerup', this.onPointerUp);
    document.addEventListener('visibilitychange', this.onVisibility);

    this.loop();
  }

  setQuality(q: Quality) {
    this.quality = q;
    this.applyQuality();
    for (const l of this.lamps) l.mat.uniforms.uSteps.value = q === 'high' ? 110 : 64;
    this.resize();
  }

  private applyQuality() {
    const dpr = window.devicePixelRatio || 1;
    this.renderer.setPixelRatio(this.quality === 'high' ? Math.min(dpr, 1.75) : Math.min(dpr, 1));
  }

  private resize() {
    const el = this.canvas.parentElement ?? this.canvas;
    const w = el.clientWidth || 1;
    const h = el.clientHeight || 1;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    if (!this.userMoved) this.fitCamera();
  }

  /** Frame the whole lamp (base to cap tip) with a little head-room. */
  private fitCamera() {
    const el = this.canvas.parentElement ?? this.canvas;
    const w = el.clientWidth || 1;
    const h = el.clientHeight || 1;
    const aspect = Math.max(0.3, w / h);
    const vFov = THREE.MathUtils.degToRad(this.camera.fov);
    const hFov = 2 * Math.atan(Math.tan(vFov / 2) * aspect);
    const spanY = 1.95; // world height to fit (lamp is 1.81 tall)
    const spanX = this.lamps.length * LAMP_SPACING + 0.85;
    const d = Math.max(
      spanY / 2 / Math.tan(vFov / 2),
      spanX / 2 / Math.tan(hFov / 2),
    );
    const dir = new THREE.Vector3(0.1, 0.055, 1).normalize();
    this.controls.target.set(0, 0.4, 0);
    this.camera.position.copy(this.controls.target).addScaledVector(dir, Math.min(9, Math.max(1.7, d)));
    this.controls.update();
  }

  // ---- lamps ----------------------------------------------------------------

  addLamp(params: LampParams): number {
    const group = new THREE.Group();
    const sim = new LampSim(params);
    const prof = profileFor(params.shape);
    const rMax = Math.max(prof.rB, prof.rT) + 0.012;

    const uniforms: Record<string, THREE.IUniform> = {
      uBlobs: { value: Array.from({ length: MAX_BLOBS }, () => new THREE.Vector4()) },
      uBlobP: { value: Array.from({ length: MAX_BLOBS }, () => new THREE.Vector4(1, 0, 0, 0)) },
      uCount: { value: 0 },
      uPoolH: { value: sim.poolH },
      uTime: { value: 0 },
      uCam: { value: new THREE.Vector3() },
      uLiquid: { value: new THREE.Color(params.liquidColor) },
      uWax: { value: new THREE.Color(params.waxColor) },
      uBright: { value: params.brightness },
      uSmooth: { value: 0.02 + params.softness * 0.07 },
      uProfile: { value: new THREE.Vector3(prof.rB, prof.rT, prof.waist) },
      uBoxHalf: { value: new THREE.Vector3(rMax, 0.51, rMax) },
      uSteps: { value: this.quality === 'high' ? 110 : 64 },
    };
    const mat = new THREE.ShaderMaterial({
      vertexShader: lavaVertex,
      fragmentShader: lavaFragment,
      uniforms,
      transparent: true,
      depthWrite: false,
    });
    const boxGeo = new THREE.BoxGeometry(rMax * 2, 1.02, rMax * 2);
    // shift the geometry so local space y runs 0..1.02 — the SDF works in that space
    boxGeo.translate(0, 0.51, 0);
    const box = new THREE.Mesh(boxGeo, mat);
    box.renderOrder = 1;
    group.add(box);

    const light = new THREE.PointLight(0xffffff, 1, 3.5, 2);
    light.position.set(0, 0.35, 0);
    group.add(light);

    const ring = new THREE.Mesh(new THREE.RingGeometry(0.3, 0.32, 64), this.ringMat.clone());
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = -0.495;
    group.add(ring);

    const entry: LampEntry = { group, sim, mat, box, parts: [], light, params: { ...params }, shape: params.shape, ring };
    this.buildBody(entry);
    this.scene.add(group);
    this.lamps.push(entry);
    this.layout();
    return this.lamps.length - 1;
  }

  removeLamp(i: number) {
    const l = this.lamps[i];
    if (!l) return;
    this.scene.remove(l.group);
    for (const p of l.parts) (p as THREE.Mesh).geometry?.dispose();
    l.box.geometry.dispose();
    l.mat.dispose();
    this.lamps.splice(i, 1);
    this.layout();
  }

  private buildBody(l: LampEntry) {
    for (const p of l.parts) {
      l.group.remove(p);
      (p as THREE.Mesh).geometry?.dispose();
    }
    l.parts = [];
    const shape = l.params.shape;
    const prof = profileFor(shape);
    const metal = shape === 'rocket' ? this.silver : this.black;
    const rB = prof.rB;
    const rT = prof.rT;

    const basePts: [number, number][] =
      shape === 'rocket'
        ? [
            [0, -0.5], [0.2, -0.5], [0.2, -0.485], [0.11, -0.455], [0.085, -0.41], [0.09, -0.3],
            [0.135, -0.1], [rB + 0.012, -0.015], [rB + 0.012, 0.03], [rB - 0.004, 0.03], [0, 0.03],
          ]
        : [
            [0, -0.5], [0.215, -0.5], [0.215, -0.49], [0.205, -0.47], [0.158, -0.04],
            [rB + 0.012, -0.015], [rB + 0.012, 0.03], [rB - 0.004, 0.03], [0, 0.03],
          ];
    const capPts: [number, number][] =
      shape === 'rocket'
        ? [
            [rT - 0.004, 0.965], [rT + 0.012, 0.965], [rT + 0.012, 1.0], [rT + 0.006, 1.05],
            [0.072, 1.17], [0.04, 1.25], [0.016, 1.295], [0, 1.305],
          ]
        : [
            [rT - 0.004, 0.965], [rT + 0.012, 0.965], [rT + 0.012, 1.09], [rT + 0.004, 1.1], [0, 1.1],
          ];
    const base = new THREE.Mesh(latheFrom(basePts), metal);
    const cap = new THREE.Mesh(latheFrom(capPts), metal);

    // glass shell (reflections only)
    const gp: [number, number][] = [];
    for (let i = 0; i <= 24; i++) {
      const y = 0.03 + (0.955 * i) / 24;
      gp.push([vesselR(y, prof) + 0.004, y]);
    }
    const glass = new THREE.Mesh(latheFrom(gp, 64), this.glass);
    glass.renderOrder = 2;

    l.parts.push(base, cap, glass);
    l.group.add(base, cap, glass);
    l.shape = shape;

    const rMax = Math.max(prof.rB, prof.rT) + 0.012;
    l.box.geometry.dispose();
    l.box.geometry = new THREE.BoxGeometry(rMax * 2, 1.02, rMax * 2);
    (l.mat.uniforms.uBoxHalf.value as THREE.Vector3).set(rMax, 0.51, rMax);
    (l.mat.uniforms.uProfile.value as THREE.Vector3).set(prof.rB, prof.rT, prof.waist);
  }

  private layout() {
    const n = this.lamps.length;
    this.lamps.forEach((l, i) => {
      l.group.position.x = (i - (n - 1) / 2) * LAMP_SPACING;
    });
    const dist = 2.9 + (n - 1) * 0.55;
    const dir = this.camera.position.clone().sub(this.controls.target).normalize();
    this.camera.position.copy(this.controls.target).addScaledVector(dir, dist);
  }

  updateParams(i: number, p: LampParams) {
    const l = this.lamps[i];
    if (!l) return;
    const shapeChanged = p.shape !== l.params.shape;
    l.params = { ...p };
    l.sim.setParams(p);
    if (shapeChanged) this.buildBody(l);
    (l.mat.uniforms.uLiquid.value as THREE.Color).set(p.liquidColor);
    (l.mat.uniforms.uWax.value as THREE.Color).set(p.waxColor);
    l.mat.uniforms.uBright.value = p.brightness;
    l.mat.uniforms.uSmooth.value = 0.02 + p.softness * 0.07;
  }

  setSelected(i: number) {
    this.selected = i;
  }

  /** Reframe the camera around the lamp(s). */
  fitView() {
    this.userMoved = false;
    this.fitCamera();
  }

  stir(i: number) { this.lamps[i]?.sim.stir(); }
  release(i: number) { this.lamps[i]?.sim.release(true); }
  reset(i: number) { this.lamps[i]?.sim.reset(); }

  // ---- interaction ----------------------------------------------------------

  private onPointerDown = (e: PointerEvent) => {
    this.ptrDown = { x: e.clientX, y: e.clientY };
  };

  private onPointerUp = (e: PointerEvent) => {
    if (!this.ptrDown) return;
    const moved = Math.hypot(e.clientX - this.ptrDown.x, e.clientY - this.ptrDown.y);
    this.ptrDown = null;
    if (moved > 5) return;
    const rect = this.canvas.getBoundingClientRect();
    const nx = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const ny = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    this.raycaster.setFromCamera(new THREE.Vector2(nx, ny), this.camera);
    const hits = this.raycaster.intersectObjects(this.lamps.map((l) => l.box), false);
    if (hits.length === 0) return;
    const hit = hits[0];
    const idx = this.lamps.findIndex((l) => l.box === hit.object);
    if (idx < 0) return;
    const l = this.lamps[idx];
    // push the point a little into the vessel along the ray
    const pt = hit.point.clone().addScaledVector(this.raycaster.ray.direction, 0.12);
    l.group.worldToLocal(pt);
    l.sim.poke(pt.x, pt.y, pt.z);
    if (idx !== this.selected) {
      this.selected = idx;
      this.onSelect?.(idx);
    }
  };

  private onVisibility = () => {
    this.last = performance.now();
  };

  // ---- loop -----------------------------------------------------------------

  private loop = () => {
    this.raf = requestAnimationFrame(this.loop);
    const now = performance.now();
    let dt = (now - this.last) / 1000;
    this.last = now;
    if (dt > 0.1) dt = 0.1;

    this.fpsAcc += dt;
    this.fpsN++;
    if (this.fpsAcc > 0.5) {
      this.onFps?.(this.fpsN / this.fpsAcc);
      this.fpsAcc = 0;
      this.fpsN = 0;
    }

    if (!this.paused) {
      this.acc += dt;
      let steps = 0;
      while (this.acc >= this.SUB && steps < 12) {
        for (const l of this.lamps) l.sim.step(this.SUB * l.params.speed);
        this.acc -= this.SUB;
        steps++;
      }
      if (steps >= 12) this.acc = 0;
    }

    this.controls.update();

    for (let i = 0; i < this.lamps.length; i++) {
      const l = this.lamps[i];
      const u = l.mat.uniforms;
      const sim = l.sim;
      const blobs = u.uBlobs.value as THREE.Vector4[];
      const bp = u.uBlobP.value as THREE.Vector4[];
      const n = Math.min(sim.blobs.length, MAX_BLOBS);
      for (let k = 0; k < n; k++) {
        const b = sim.blobs[k];
        blobs[k].set(b.x, b.y, b.z, b.r);
        bp[k].set(b.stretch, b.tail, b.amp, b.phase);
      }
      u.uCount.value = n;
      u.uPoolH.value = sim.poolH;
      u.uTime.value = sim.time;
      this.tmpV.copy(this.camera.position);
      l.box.worldToLocal(this.tmpV);
      (u.uCam.value as THREE.Vector3).copy(this.tmpV);

      // floor glow
      const lc = u.uLiquid.value as THREE.Color;
      const wc = u.uWax.value as THREE.Color;
      l.light.color.copy(lc).lerp(wc, 0.35);
      l.light.intensity = 2.8 * l.params.brightness * (0.6 + 0.4 * sim.warm);

      const rm = l.ring.material as THREE.MeshBasicMaterial;
      const target = this.lamps.length > 1 && i === this.selected ? 0.35 : 0;
      rm.opacity += (target - rm.opacity) * 0.15;
      l.ring.visible = rm.opacity > 0.01;
      rm.color.copy(wc);
    }

    this.renderer.render(this.scene, this.camera);
  };

  dispose() {
    cancelAnimationFrame(this.raf);
    this.resizeObs.disconnect();
    this.canvas.removeEventListener('pointerdown', this.onPointerDown);
    this.canvas.removeEventListener('pointerup', this.onPointerUp);
    document.removeEventListener('visibilitychange', this.onVisibility);
    this.controls.dispose();
    for (let i = this.lamps.length - 1; i >= 0; i--) this.removeLamp(i);
    this.renderer.dispose();
  }
}
