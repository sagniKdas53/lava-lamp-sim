import { useCallback, useEffect, useRef, useState } from 'react';
import Controls from './components/Controls';
import { LampScene, Quality } from './lib/lampScene';
import { DEFAULT_PARAMS, LampParams } from './lib/sim';
import { cn } from './utils/cn';

const initialLamps: LampParams[] = [{ ...DEFAULT_PARAMS }];

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sceneRef = useRef<LampScene | null>(null);
  const [lamps, setLamps] = useState<LampParams[]>(initialLamps);
  const lampsRef = useRef(lamps);
  lampsRef.current = lamps;
  const [selected, setSelected] = useState(0);
  const selectedRef = useRef(0);
  selectedRef.current = selected;
  const [showControls, setShowControls] = useState(true);
  const [paused, setPaused] = useState(false);
  const [quality, setQuality] = useState<Quality>('high');
  const [fps, setFps] = useState(0);
  const [info, setInfo] = useState({ blobs: 0, poolT: 0, neutralT: 0 });
  const [hint, setHint] = useState(true);

  // mount scene
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const scene = new LampScene(canvas);
    sceneRef.current = scene;
    for (const l of lampsRef.current) scene.addLamp(l);
    scene.onSelect = (i) => setSelected(i);
    scene.onFps = (f) => {
      setFps(f);
      const s = scene.lamps[selectedRef.current]?.sim;
      if (s) setInfo({ blobs: s.blobs.length, poolT: s.poolT, neutralT: s.neutralT });
    };
    const t = setTimeout(() => setHint(false), 6000);
    return () => {
      clearTimeout(t);
      scene.dispose();
      sceneRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (sceneRef.current) sceneRef.current.paused = paused;
  }, [paused]);

  useEffect(() => {
    sceneRef.current?.setQuality(quality);
  }, [quality]);

  useEffect(() => {
    sceneRef.current?.setSelected(selected);
  }, [selected]);

  // keyboard shortcuts
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.tagName === 'INPUT') return;
      if (e.key === 'h' || e.key === 'H') setShowControls((v) => !v);
      if (e.key === ' ') { e.preventDefault(); setPaused((v) => !v); }
      if (e.key === 'r' || e.key === 'R') sceneRef.current?.release(selectedRef.current);
      if (e.key === 's' || e.key === 'S') sceneRef.current?.stir(selectedRef.current);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const onChange = useCallback((patch: Partial<LampParams>) => {
    setLamps((prev) => {
      const i = selectedRef.current;
      const next = prev.map((l, k) => (k === i ? { ...l, ...patch } : l));
      sceneRef.current?.updateParams(i, next[i]);
      return next;
    });
  }, []);

  const onAdd = useCallback(() => {
    setLamps((prev) => {
      if (prev.length >= 3) return prev;
      const base = prev[selectedRef.current] ?? DEFAULT_PARAMS;
      const palette = [
        { liquidColor: '#7a2bd6', waxColor: '#ff2d9b', shape: 'tower' as const },
        { liquidColor: '#1f6fff', waxColor: '#d7ff3c', shape: 'rocket' as const },
      ];
      const pick = palette[prev.length - 1] ?? palette[0];
      const np: LampParams = { ...base, ...pick };
      sceneRef.current?.addLamp(np);
      setSelected(prev.length);
      return [...prev, np];
    });
  }, []);

  const onRemove = useCallback(() => {
    setLamps((prev) => {
      if (prev.length <= 1) return prev;
      const i = selectedRef.current;
      sceneRef.current?.removeLamp(i);
      const next = prev.filter((_, k) => k !== i);
      setSelected(Math.max(0, Math.min(i, next.length - 1)));
      return next;
    });
  }, []);

  return (
    <div className="fixed inset-0 overflow-hidden bg-[#06050b] text-white select-none">
      {/* background */}
      <div className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(ellipse at 50% 85%, #1d1428 0%, #0a0810 45%, #050409 100%)',
        }}
      />
      <div className="absolute inset-0">
        <canvas ref={canvasRef} className="block w-full h-full touch-none" />
      </div>

      {/* top bar */}
      <div className="absolute top-0 left-0 right-0 p-3 sm:p-4 flex items-start justify-between pointer-events-none">
        <div className="pointer-events-auto">
          <h1 className="text-lg sm:text-xl font-semibold tracking-tight flex items-center gap-2">
            <span className="inline-block w-3 h-3 rounded-full bg-gradient-to-br from-amber-300 to-orange-600 shadow-[0_0_14px_#f97316]" />
            Lava Lab
          </h1>
          <p className="text-[11px] text-white/45 mt-0.5">3D emulsion playground · drag to orbit · click the glass to poke</p>
        </div>
        <div className="pointer-events-auto flex items-center gap-1.5">
          <span className="text-[11px] text-white/40 tabular-nums mr-1 hidden sm:inline">{fps.toFixed(0)} fps</span>
          <button
            onClick={() => sceneRef.current?.fitView()}
            className="px-2.5 py-1.5 rounded-md text-xs bg-white/5 hover:bg-white/10 border border-white/10"
            title="Reframe the camera on the lamp(s)"
          >
            ⤢ Fit
          </button>
          <button
            onClick={() => setQuality((q) => (q === 'high' ? 'low' : 'high'))}
            className="px-2.5 py-1.5 rounded-md text-xs bg-white/5 hover:bg-white/10 border border-white/10"
            title="Toggle render quality"
          >
            {quality === 'high' ? '✦ High' : '○ Low'}
          </button>
          <button
            onClick={() => setPaused((v) => !v)}
            className={cn(
              'px-2.5 py-1.5 rounded-md text-xs border',
              paused ? 'bg-amber-400/20 border-amber-300/50' : 'bg-white/5 hover:bg-white/10 border-white/10',
            )}
            title="Pause (space)"
          >
            {paused ? '▶ Play' : '❚❚ Pause'}
          </button>
          <button
            onClick={() => setShowControls((v) => !v)}
            className="px-2.5 py-1.5 rounded-md text-xs bg-white/5 hover:bg-white/10 border border-white/10"
            title="Toggle controls (H)"
          >
            {showControls ? 'Hide controls' : 'Controls'}
          </button>
        </div>
      </div>

      {hint && (
        <div className="absolute left-1/2 -translate-x-1/2 top-16 sm:top-20 text-[11px] px-3 py-1.5 rounded-full bg-black/40 border border-white/10 text-white/60 pointer-events-none animate-pulse">
          warming up… the wax will start budding from the pool in a few seconds
        </div>
      )}

      {/* bottom controls */}
      <div
        className={cn(
          'absolute left-0 right-0 bottom-0 p-3 sm:p-4 pointer-events-none transition-transform duration-300 ease-out',
          showControls ? 'translate-y-0' : 'translate-y-[110%]',
        )}
      >
        <Controls
          lamps={lamps}
          selected={selected}
          onSelect={setSelected}
          onAdd={onAdd}
          onRemove={onRemove}
          onChange={onChange}
          onStir={() => sceneRef.current?.stir(selected)}
          onRelease={() => sceneRef.current?.release(selected)}
          onReset={() => sceneRef.current?.reset(selected)}
          onHide={() => setShowControls(false)}
          info={info}
        />
      </div>

      {!showControls && (
        <button
          onClick={() => setShowControls(true)}
          className="absolute bottom-4 left-1/2 -translate-x-1/2 px-3 py-1.5 rounded-full text-xs bg-black/50 hover:bg-black/70 border border-white/15 backdrop-blur"
        >
          ▴ Controls
        </button>
      )}
    </div>
  );
}
