import React from 'react';
import { ToggleLeft, ToggleRight, Zap } from 'lucide-react';

interface DimensionOverlayProps {
  visible: boolean;
  powerOn: boolean;
  onTogglePower: () => void;
}

export const DimensionOverlay: React.FC<DimensionOverlayProps> = ({
  visible,
  powerOn,
  onTogglePower,
}) => {
  if (!visible) return null;

  return (
    <div className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center select-none text-white/90">
      {/* 1. Left Vertical Height Dimension Line (40 cm) matching reference photos */}
      <div className="absolute left-[8%] sm:left-[16%] md:left-[22%] top-[12%] bottom-[12%] flex flex-col items-center">
        {/* Top crossbar */}
        <div className="w-12 sm:w-16 h-px bg-white/60 relative">
          <div className="absolute left-0 -top-1 w-px h-2 bg-white/60" />
          <div className="absolute right-0 -top-1 w-px h-2 bg-white/60" />
        </div>

        {/* Vertical line with height label in middle */}
        <div className="flex-1 w-px bg-white/40 flex items-center justify-center relative my-1">
          <div className="bg-zinc-950/90 border border-white/20 px-2.5 py-1 rounded-md text-xs sm:text-sm font-serif tracking-widest text-zinc-100 shadow-lg backdrop-blur-md rotate-[-90deg] sm:rotate-0">
            40 cm
          </div>
        </div>

        {/* Bottom crossbar */}
        <div className="w-12 sm:w-16 h-px bg-white/60 relative">
          <div className="absolute left-0 -bottom-1 w-px h-2 bg-white/60" />
          <div className="absolute right-0 -bottom-1 w-px h-2 bg-white/60" />
        </div>
      </div>

      {/* 2. Bottom Base Width Dimension Line (10.5 cm) matching reference photos */}
      <div className="absolute bottom-[8%] sm:bottom-[7%] w-36 sm:w-44 flex flex-col items-center">
        <div className="w-full flex items-center justify-between">
          <div className="h-3 w-px bg-white/60" />
          <div className="flex-1 h-px bg-white/40 mx-1 flex items-center justify-center">
            <span className="bg-zinc-950/90 border border-white/20 px-2 py-0.5 rounded text-[11px] sm:text-xs font-serif tracking-wider text-zinc-200">
              10.5 cm
            </span>
          </div>
          <div className="h-3 w-px bg-white/60" />
        </div>
        <div className="text-[10px] text-zinc-400 font-serif mt-1">solid base</div>
      </div>

      {/* 3. Interactive Switch Callout (matching right column in reference photos) */}
      <div className="pointer-events-auto absolute right-4 sm:right-10 top-20 hidden lg:flex flex-col gap-3">
        {/* Switch Card */}
        <div
          onClick={onTogglePower}
          className="bg-zinc-900/85 backdrop-blur-md border border-zinc-700/80 rounded-xl p-3 w-52 shadow-2xl cursor-pointer hover:border-zinc-500 transition-all group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-zinc-200 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              switch button
            </span>
            {powerOn ? (
              <ToggleRight className="w-5 h-5 text-emerald-400" />
            ) : (
              <ToggleLeft className="w-5 h-5 text-zinc-500" />
            )}
          </div>
          <div className="flex items-center gap-2">
            <div className={`w-3 h-3 rounded-full ${powerOn ? 'bg-emerald-500 animate-pulse' : 'bg-zinc-600'}`} />
            <span className="text-[11px] text-zinc-300">
              {powerOn ? 'Power Active (Heating)' : 'Powered OFF (Cooling)'}
            </span>
          </div>
        </div>

        {/* Cable Specs Card */}
        <div className="bg-zinc-900/85 backdrop-blur-md border border-zinc-700/80 rounded-xl p-3 w-52 shadow-2xl">
          <div className="text-xs font-medium text-zinc-200 mb-0.5 font-serif">
            wire length 60 inch
          </div>
          <div className="text-[11px] text-zinc-400">220-240 V AC / 30W Base</div>
        </div>

        {/* Planar Top Reservoir Callout */}
        <div className="bg-zinc-900/85 backdrop-blur-md border border-indigo-700/60 rounded-xl p-3 w-52 shadow-2xl">
          <div className="text-xs font-medium text-indigo-300 mb-0.5 font-serif">
            Planar Top Wax Pool
          </div>
          <div className="text-[10px] text-zinc-300 leading-tight">
            Wax coalesces into container base reservoir with flat meniscus top.
          </div>
        </div>
      </div>
    </div>
  );
};
