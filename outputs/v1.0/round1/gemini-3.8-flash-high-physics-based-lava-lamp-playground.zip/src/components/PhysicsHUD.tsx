import React, { useState, useEffect } from 'react';
import { LavaSimulation, SimulationParams } from '../simulation/LavaSimulation';
import { Activity, Droplet, Flame, Compass } from 'lucide-react';

interface PhysicsHUDProps {
  simulation: LavaSimulation;
  simParams: SimulationParams;
  visible: boolean;
  powerOn: boolean;
}

export const PhysicsHUD: React.FC<PhysicsHUDProps> = ({
  simulation,
  simParams,
  visible,
  powerOn,
}) => {
  const [, setTick] = useState(0);

  // Update telemetry metrics 5 times a second
  useEffect(() => {
    const id = setInterval(() => {
      setTick((t) => (t + 1) % 1000);
    }, 200);
    return () => clearInterval(id);
  }, []);

  if (!visible) return null;

  const activeCount = simulation.blobs.filter((b) => b.active).length;
  const currentTemp = powerOn ? simParams.temperature : 22;
  const deltaT = currentTemp - 42.0;
  const waxDensityCurrent = simParams.waxDensity * (1.0 - simParams.thermalExpansion * deltaT);
  const densityDelta = simParams.liquidDensity - waxDensityCurrent;

  return (
    <div className="absolute top-4 left-4 z-20 pointer-events-none select-none">
      <div className="bg-zinc-950/75 backdrop-blur-md border border-zinc-800/80 rounded-2xl p-3.5 shadow-xl text-white w-64">
        {/* Title / Status */}
        <div className="flex items-center justify-between pb-2 mb-2 border-b border-zinc-800/80">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              {powerOn ? (
                <>
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </>
              ) : (
                <span className="inline-flex rounded-full h-2 w-2 bg-zinc-600"></span>
              )}
            </span>
            <span className="text-xs font-semibold tracking-wide uppercase text-zinc-300">
              Lava Telemetry
            </span>
          </div>
          <span className="text-[10px] font-mono text-zinc-500">60 FPS</span>
        </div>

        {/* Metrics Grid */}
        <div className="space-y-1.5 text-xs">
          <div className="flex items-center justify-between text-zinc-300">
            <span className="flex items-center gap-1.5 text-zinc-400">
              <Flame className="w-3.5 h-3.5 text-rose-400" /> Heater Base
            </span>
            <span className="font-mono text-rose-300 font-medium">
              {Math.round(currentTemp)}°C
            </span>
          </div>

          <div className="flex items-center justify-between text-zinc-300">
            <span className="flex items-center gap-1.5 text-zinc-400">
              <Compass className="w-3.5 h-3.5 text-amber-400" /> Net Buoyancy (Δρ)
            </span>
            <span
              className={`font-mono font-medium ${
                densityDelta > 0 ? 'text-emerald-400' : 'text-blue-400'
              }`}
            >
              {densityDelta > 0 ? '+' : ''}
              {densityDelta.toFixed(4)}
            </span>
          </div>

          <div className="flex items-center justify-between text-zinc-300">
            <span className="flex items-center gap-1.5 text-zinc-400">
              <Activity className="w-3.5 h-3.5 text-cyan-400" /> Viscosity (μ)
            </span>
            <span className="font-mono text-cyan-300">
              {simParams.viscosity.toFixed(2)} Pa·s
            </span>
          </div>

          <div className="flex items-center justify-between text-zinc-300">
            <span className="flex items-center gap-1.5 text-zinc-400">
              <Droplet className="w-3.5 h-3.5 text-purple-400" /> Active Wax Plumes
            </span>
            <span className="font-mono text-purple-300">
              {activeCount} blobs ({((simulation.basePoolHeight / 0.95) * 100).toFixed(0)}% base)
            </span>
          </div>
        </div>

        {/* Tip */}
        <div className="mt-2.5 pt-2 border-t border-zinc-800/80 text-[10px] text-zinc-500 flex items-center justify-between">
          <span>Click & drag lamp to stir</span>
          <kbd className="px-1 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-zinc-400">
            H = Hide UI
          </kbd>
        </div>
      </div>
    </div>
  );
};
