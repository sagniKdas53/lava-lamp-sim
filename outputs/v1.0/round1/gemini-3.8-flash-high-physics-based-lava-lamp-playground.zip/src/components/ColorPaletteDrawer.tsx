import React from 'react';
import { COLOR_PRESETS, ColorPreset } from '../constants/presets';
import { X, Sparkles, Droplets, Flame, SunMedium } from 'lucide-react';

interface ColorPaletteDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  liquidColor: string;
  waxColor: string;
  brightness: number;
  onUpdateColors: (liquid: string, wax: string) => void;
  onUpdateBrightness: (b: number) => void;
}

export const ColorPaletteDrawer: React.FC<ColorPaletteDrawerProps> = ({
  isOpen,
  onClose,
  liquidColor,
  waxColor,
  brightness,
  onUpdateColors,
  onUpdateBrightness,
}) => {
  if (!isOpen) return null;

  const quickLiquidSwatches = [
    '#3b0764', '#0284c7', '#9a3412', '#0f766e', '#450a0a', '#1e1b4b', '#1e293b', '#831843', '#064e3b', '#18181b'
  ];

  const quickWaxSwatches = [
    '#f43f5e', '#84cc16', '#facc15', '#fb7185', '#ea580c', '#06b6d4', '#f1f5f9', '#fbcfe8', '#10b981', '#ec4899'
  ];

  return (
    <div className="absolute top-16 right-4 sm:right-6 w-96 max-w-[calc(100vw-2rem)] bg-zinc-950/85 backdrop-blur-xl border border-zinc-800/80 rounded-2xl p-5 shadow-2xl text-white z-40 animate-in fade-in slide-in-from-top-4 duration-200">
      <div className="flex items-center justify-between pb-3 border-b border-zinc-800/80">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-pink-500/20 text-pink-400">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-semibold text-sm">Two-Tone Color Lab</h3>
            <p className="text-xs text-zinc-400">Liquid emulsion & wax illumination</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-1.5 rounded-lg hover:bg-zinc-800/80 text-zinc-400 hover:text-white transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Live Preview Pill */}
      <div className="my-4 p-3 rounded-xl bg-zinc-900/60 border border-zinc-800/60 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div
            className="w-10 h-10 rounded-full border border-white/20 shadow-inner flex items-center justify-center relative overflow-hidden"
            style={{
              background: `radial-gradient(circle at 35% 35%, ${waxColor}, ${liquidColor})`,
              boxShadow: `0 0 16px ${waxColor}66`,
            }}
          >
            <div
              className="w-4 h-4 rounded-full blur-[1px]"
              style={{ background: waxColor }}
            />
          </div>
          <div>
            <div className="text-xs font-medium text-zinc-200">Current 2-Tone Mix</div>
            <div className="text-[11px] text-zinc-400 font-mono">
              Liq: {liquidColor} • Wax: {waxColor}
            </div>
          </div>
        </div>
        <div className="text-right">
          <span className="text-[11px] text-zinc-400 block">Brightness</span>
          <span className="text-xs font-semibold text-amber-400">
            {Math.round(brightness * 100)}%
          </span>
        </div>
      </div>

      {/* Brightness Dimmer Slider */}
      <div className="mb-5">
        <div className="flex items-center justify-between text-xs mb-1.5">
          <span className="text-zinc-300 flex items-center gap-1.5">
            <SunMedium className="w-3.5 h-3.5 text-amber-400" /> Bulb Brightness / Dimmer
          </span>
          <span className="font-mono text-zinc-400">{Math.round(brightness * 100)}%</span>
        </div>
        <input
          type="range"
          min="0.1"
          max="1.6"
          step="0.05"
          value={brightness}
          onChange={(e) => onUpdateBrightness(parseFloat(e.target.value))}
          className="w-full accent-amber-500 h-1.5 bg-zinc-800 rounded-lg cursor-pointer"
        />
      </div>

      {/* Curated Color Presets */}
      <div className="mb-4">
        <div className="text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-2">
          Curated Lava Lamp Themes
        </div>
        <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1 select-none">
          {COLOR_PRESETS.map((preset: ColorPreset) => {
            const isSelected =
              preset.liquidColor.toLowerCase() === liquidColor.toLowerCase() &&
              preset.waxColor.toLowerCase() === waxColor.toLowerCase();
            return (
              <button
                key={preset.id}
                onClick={() => onUpdateColors(preset.liquidColor, preset.waxColor)}
                className={`p-2 rounded-xl text-left border transition-all flex items-center gap-2.5 ${
                  isSelected
                    ? 'border-indigo-500 bg-indigo-500/10 ring-1 ring-indigo-500/50'
                    : 'border-zinc-800/80 hover:border-zinc-700 bg-zinc-900/40 hover:bg-zinc-900/80'
                }`}
              >
                {/* 2-Tone circle badge */}
                <div
                  className="w-7 h-7 rounded-full flex-shrink-0 flex items-center justify-center border border-white/20 shadow-sm"
                  style={{ backgroundColor: preset.liquidColor }}
                >
                  <div
                    className="w-3.5 h-3.5 rounded-full shadow-inner"
                    style={{ backgroundColor: preset.waxColor }}
                  />
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-medium text-zinc-200 truncate">{preset.name}</div>
                  <div className="text-[10px] text-zinc-400 truncate">{preset.category}</div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Custom 2-Tone Color Pickers */}
      <div className="space-y-3 pt-3 border-t border-zinc-800/80">
        <div className="text-xs font-semibold text-zinc-300 uppercase tracking-wider">
          Custom 2-Tone Palette
        </div>

        {/* Liquid Color */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <span className="flex items-center gap-1.5 text-zinc-300">
              <Droplets className="w-3.5 h-3.5 text-cyan-400" /> Liquid Medium Tint
            </span>
            <input
              type="color"
              value={liquidColor}
              onChange={(e) => onUpdateColors(e.target.value, waxColor)}
              className="w-6 h-6 rounded cursor-pointer bg-transparent border-0"
            />
          </div>
          <div className="flex items-center gap-1.5 flex-wrap">
            {quickLiquidSwatches.map((hex) => (
              <button
                key={hex}
                onClick={() => onUpdateColors(hex, waxColor)}
                className={`w-6 h-6 rounded-full border transition-transform ${
                  liquidColor.toLowerCase() === hex.toLowerCase()
                    ? 'scale-110 border-white ring-2 ring-cyan-500/50'
                    : 'border-white/20 hover:scale-105'
                }`}
                style={{ backgroundColor: hex }}
                title={`Liquid: ${hex}`}
              />
            ))}
          </div>
        </div>

        {/* Wax Color */}
        <div className="space-y-1.5 pt-2">
          <div className="flex items-center justify-between text-xs">
            <span className="flex items-center gap-1.5 text-zinc-300">
              <Flame className="w-3.5 h-3.5 text-rose-400" /> Molten Wax Globules
            </span>
            <input
              type="color"
              value={waxColor}
              onChange={(e) => onUpdateColors(liquidColor, e.target.value)}
              className="w-6 h-6 rounded cursor-pointer bg-transparent border-0"
            />
          </div>
          <div className="flex items-center gap-1.5 flex-wrap">
            {quickWaxSwatches.map((hex) => (
              <button
                key={hex}
                onClick={() => onUpdateColors(liquidColor, hex)}
                className={`w-6 h-6 rounded-full border transition-transform ${
                  waxColor.toLowerCase() === hex.toLowerCase()
                    ? 'scale-110 border-white ring-2 ring-rose-500/50'
                    : 'border-white/20 hover:scale-105'
                }`}
                style={{ backgroundColor: hex }}
                title={`Wax: ${hex}`}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
