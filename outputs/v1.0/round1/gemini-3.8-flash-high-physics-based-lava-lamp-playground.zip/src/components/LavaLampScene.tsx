import React, { useEffect, useRef, useCallback } from 'react';
import * as THREE from 'three';
import { lavaVertexShader, lavaFragmentShader } from '../shaders/lavaShader';
import { LavaSimulation, SimulationParams } from '../simulation/LavaSimulation';

export type LampFinish = 'silver' | 'black' | 'gold' | 'copper';

export interface SceneOptions {
  liquidColor: string;
  waxColor: string;
  brightness: number;
  powerOn: boolean;
  lampFinish: LampFinish;
  noiseAmount: number;
  autoRotate: boolean;
}

interface LavaLampSceneProps {
  simulation: LavaSimulation;
  simParams: SimulationParams;
  options: SceneOptions;
  onSelectBlob?: (blobId: number) => void;
  onStir?: () => void;
}

export const LavaLampScene: React.FC<LavaLampSceneProps> = ({
  simulation,
  simParams,
  options,
  onStir,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const materialRef = useRef<THREE.ShaderMaterial | null>(null);
  const pointLightRef = useRef<THREE.PointLight | null>(null);
  const baseGlowMeshRef = useRef<THREE.Mesh | null>(null);
  const coilMeshRef = useRef<THREE.Mesh | null>(null);
  const baseMeshRef = useRef<THREE.Mesh | null>(null);
  const capMeshRef = useRef<THREE.Mesh | null>(null);
  const lampGroupRef = useRef<THREE.Group | null>(null);

  // Camera Orbit state
  const orbitRef = useRef({
    isDragging: false,
    isInteracting: false,
    previousMousePosition: { x: 0, y: 0 },
    spherical: new THREE.Spherical(7.8, Math.PI / 2.05, 0),
    target: new THREE.Vector3(0, 0, 0),
    damping: 0.08,
  });

  // Material finish colors for lamp base & cap
  const getFinishMaterial = useCallback((finish: LampFinish) => {
    switch (finish) {
      case 'black':
        return new THREE.MeshStandardMaterial({
          color: 0x18181b,
          metalness: 0.85,
          roughness: 0.32,
        });
      case 'gold':
        return new THREE.MeshStandardMaterial({
          color: 0xd4af37,
          metalness: 0.92,
          roughness: 0.25,
        });
      case 'copper':
        return new THREE.MeshStandardMaterial({
          color: 0xb87333,
          metalness: 0.9,
          roughness: 0.28,
        });
      case 'silver':
      default:
        return new THREE.MeshStandardMaterial({
          color: 0xd1d5db,
          metalness: 0.92,
          roughness: 0.22,
        });
    }
  }, []);

  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    const width = container.clientWidth;
    const height = container.clientHeight;

    // 1. Scene & Renderer Setup
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0x0a0c10);
    scene.fog = new THREE.FogExp2(0x0a0c10, 0.05);

    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 50);
    cameraRef.current = camera;
    
    // Initial camera position from spherical coordinates
    const sph = orbitRef.current.spherical;
    camera.position.setFromSpherical(sph);
    camera.lookAt(orbitRef.current.target);

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
      alpha: false,
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // 2. Room Lighting & Backdrop
    const ambientLight = new THREE.AmbientLight(0x222630, 0.9);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xffffff, 1.2);
    keyLight.position.set(5, 8, 6);
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x4f46e5, 0.6);
    rimLight.position.set(-6, 4, -5);
    scene.add(rimLight);

    // Lamp's internal incandescent bulb light
    const bulbLight = new THREE.PointLight(0xffaa44, 2.5, 8.0, 1.2);
    bulbLight.position.set(0, -1.85, 0);
    scene.add(bulbLight);
    pointLightRef.current = bulbLight;

    // Floor / Table reflection plane
    const tableGeo = new THREE.CylinderGeometry(5.5, 5.5, 0.2, 64);
    const tableMat = new THREE.MeshStandardMaterial({
      color: 0x111317,
      roughness: 0.45,
      metalness: 0.4,
    });
    const table = new THREE.Mesh(tableGeo, tableMat);
    table.position.y = -3.2;
    scene.add(table);

    // Subtle table spotlight glow from base
    const tableGlowGeo = new THREE.RingGeometry(0.8, 3.2, 32);
    const tableGlowMat = new THREE.MeshBasicMaterial({
      color: new THREE.Color(options.waxColor),
      transparent: true,
      opacity: 0.18,
      side: THREE.DoubleSide,
    });
    const tableGlow = new THREE.Mesh(tableGlowGeo, tableGlowMat);
    tableGlow.rotation.x = -Math.PI / 2;
    tableGlow.position.y = -3.09;
    scene.add(tableGlow);

    // 3. Lamp Group
    const lampGroup = new THREE.Group();
    scene.add(lampGroup);
    lampGroupRef.current = lampGroup;

    // --- A. Base Pedestal (Matching reference photos!) ---
    // Classic flared conical metal base with stepped foot
    const baseMat = getFinishMaterial(options.lampFinish);
    
    // Main base cone
    const baseConeGeo = new THREE.CylinderGeometry(0.88, 1.38, 2.0, 48, 1, true);
    const baseCone = new THREE.Mesh(baseConeGeo, baseMat);
    baseCone.position.y = -2.1;
    lampGroup.add(baseCone);
    baseMeshRef.current = baseCone;

    // Base flared foot collar
    const baseFootGeo = new THREE.CylinderGeometry(1.38, 1.55, 0.25, 48);
    const baseFoot = new THREE.Mesh(baseFootGeo, baseMat);
    baseFoot.position.y = -3.05;
    lampGroup.add(baseFoot);

    // Base rim collar under glass
    const baseCollarGeo = new THREE.TorusGeometry(0.89, 0.05, 16, 48);
    const baseCollar = new THREE.Mesh(baseCollarGeo, baseMat);
    baseCollar.rotation.x = Math.PI / 2;
    baseCollar.position.y = -1.1;
    lampGroup.add(baseCollar);

    // Internal incandescent bulb housing / glowing dome
    const bulbDomeGeo = new THREE.SphereGeometry(0.42, 24, 24, 0, Math.PI * 2, 0, Math.PI * 0.5);
    const bulbDomeMat = new THREE.MeshBasicMaterial({
      color: 0xffe6a3,
      transparent: true,
      opacity: 0.9,
    });
    const bulbDome = new THREE.Mesh(bulbDomeGeo, bulbDomeMat);
    bulbDome.position.y = -1.55;
    lampGroup.add(bulbDome);
    baseGlowMeshRef.current = bulbDome;

    // Heating wire coil at bottom of glass (Key authentic lava lamp feature!)
    const coilPoints: THREE.Vector3[] = [];
    const coilTurns = 6;
    const coilRad = 0.65;
    for (let i = 0; i <= 140; i++) {
      const u = i / 140;
      const angle = u * Math.PI * 2 * coilTurns;
      const r = coilRad * (0.8 + 0.2 * Math.sin(u * Math.PI));
      const x = Math.cos(angle) * r;
      const z = Math.sin(angle) * r;
      const y = -1.65 + u * 0.22;
      coilPoints.push(new THREE.Vector3(x, y, z));
    }
    const catmull = new THREE.CatmullRomCurve3(coilPoints);
    const coilGeo = new THREE.TubeGeometry(catmull, 120, 0.022, 8, false);
    const coilMat = new THREE.MeshStandardMaterial({
      color: 0xd97706,
      metalness: 0.95,
      roughness: 0.2,
      emissive: 0x92400e,
      emissiveIntensity: 0.4,
    });
    const coilMesh = new THREE.Mesh(coilGeo, coilMat);
    lampGroup.add(coilMesh);
    coilMeshRef.current = coilMesh;

    // --- B. Glass Bottle Interior (Raymarched Fluid Volume) ---
    // We create a cylinder that envelopes the lamp bottle volume
    const volumeGeo = new THREE.CylinderGeometry(0.85, 0.85, simulation.lampHeight, 48, 1, true);
    
    // Prepare initial blob arrays for uniforms
    const blobVecs = Array.from({ length: 20 }, () => new THREE.Vector4(0, 0, 0, 0));
    const velVecs = Array.from({ length: 20 }, () => new THREE.Vector3(0, 0, 0));
    const deformVecs = Array.from({ length: 20 }, () => new THREE.Vector3(1, 1, 1));

    const lavaMaterial = new THREE.ShaderMaterial({
      vertexShader: lavaVertexShader,
      fragmentShader: lavaFragmentShader,
      uniforms: {
        uLiquidColor: { value: new THREE.Color(options.liquidColor) },
        uWaxColor: { value: new THREE.Color(options.waxColor) },
        uBrightness: { value: options.brightness },
        uTime: { value: 0 },
        uCameraPos: { value: camera.position },
        uLampRadius: { value: simulation.lampRadius },
        uLampHeight: { value: simulation.lampHeight },
        uBulbPower: { value: options.powerOn ? 1.0 : 0.0 },
        uViscosity: { value: simParams.viscosity },
        uBasePoolHeight: { value: simulation.basePoolHeight },
        uTopPoolHeight: { value: simulation.topPoolHeight },
        uNoiseIntensity: { value: options.noiseAmount },
        uBlobCount: { value: simulation.blobs.length },
        uBlobs: { value: blobVecs },
        uBlobVelocities: { value: velVecs },
        uBlobDeform: { value: deformVecs },
      },
      transparent: true,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    materialRef.current = lavaMaterial;

    const volumeMesh = new THREE.Mesh(volumeGeo, lavaMaterial);
    volumeMesh.position.y = 0;
    lampGroup.add(volumeMesh);

    // --- C. Outer Glass Vessel (Reflections & Specular Sheen) ---
    const glassGeo = new THREE.CylinderGeometry(0.87, 0.87, simulation.lampHeight, 48, 1, true);
    const glassMat = new THREE.MeshPhysicalMaterial({
      color: 0xffffff,
      transmission: 0.92,
      opacity: 1.0,
      transparent: true,
      roughness: 0.05,
      ior: 1.48, // Glass index of refraction
      reflectivity: 0.8,
      thickness: 0.2,
      specularColor: 0xffffff,
      specularIntensity: 1.0,
      side: THREE.FrontSide,
    });
    const glassMesh = new THREE.Mesh(glassGeo, glassMat);
    glassMesh.position.y = 0;
    lampGroup.add(glassMesh);

    // --- D. Top Metal Bullet Cap ---
    const capGeo = new THREE.ConeGeometry(0.88, 1.4, 48);
    const cap = new THREE.Mesh(capGeo, baseMat);
    cap.position.y = simulation.lampHeight * 0.5 + 0.7;
    lampGroup.add(cap);
    capMeshRef.current = cap;

    const capRingGeo = new THREE.TorusGeometry(0.87, 0.04, 16, 48);
    const capRing = new THREE.Mesh(capRingGeo, baseMat);
    capRing.rotation.x = Math.PI / 2;
    capRing.position.y = simulation.lampHeight * 0.5;
    lampGroup.add(capRing);

    // --- E. Electric Cord & In-line Switch Button on the Table (Matches reference images!) ---
    const cordPoints: THREE.Vector3[] = [];
    for (let t = 0; t <= 30; t++) {
      const u = t / 30;
      const cx = 1.35 + u * 1.8 + Math.sin(u * 5.0) * 0.15;
      const cz = 0.5 + u * 1.5 + Math.cos(u * 4.0) * 0.2;
      const cy = -3.05;
      cordPoints.push(new THREE.Vector3(cx, cy, cz));
    }
    const cordPath = new THREE.CatmullRomCurve3(cordPoints);
    const cordGeo = new THREE.TubeGeometry(cordPath, 40, 0.035, 8, false);
    const cordMat = new THREE.MeshStandardMaterial({
      color: 0x18181b,
      roughness: 0.7,
      metalness: 0.1,
    });
    const cordMesh = new THREE.Mesh(cordGeo, cordMat);
    scene.add(cordMesh);

    // In-line switch box
    const switchBoxGeo = new THREE.BoxGeometry(0.42, 0.14, 0.24);
    const switchBoxMat = new THREE.MeshStandardMaterial({
      color: 0x27272a,
      roughness: 0.5,
      metalness: 0.2,
    });
    const switchBox = new THREE.Mesh(switchBoxGeo, switchBoxMat);
    switchBox.position.set(2.4, -3.03, 1.4);
    switchBox.rotation.y = 0.5;
    scene.add(switchBox);

    // Switch rocker button
    const rockerGeo = new THREE.CylinderGeometry(0.08, 0.08, 0.06, 16);
    const rockerMat = new THREE.MeshStandardMaterial({
      color: options.powerOn ? 0xe11d48 : 0x52525b,
      roughness: 0.3,
    });
    const rocker = new THREE.Mesh(rockerGeo, rockerMat);
    rocker.position.set(2.4, -2.94, 1.4);
    scene.add(rocker);

    // 4. Mouse / Touch Controls & Interaction Handlers
    let lastTime = performance.now();
    let animFrameId: number;

    const handleResize = () => {
      if (!containerRef.current || !rendererRef.current || !cameraRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      cameraRef.current.aspect = w / h;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    // Mouse drag handlers
    const onMouseDown = (e: MouseEvent) => {
      orbitRef.current.isDragging = true;
      orbitRef.current.previousMousePosition = { x: e.clientX, y: e.clientY };

      // Check if clicked near lamp to stir
      const rect = container.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      // If clicking center area (the lamp), stir fluid
      if (Math.abs(x) < 0.45 && Math.abs(y) < 0.7) {
        orbitRef.current.isInteracting = true;
        simulation.stir(new THREE.Vector3((Math.random() - 0.5) * 0.3, (Math.random() - 0.5) * 0.2, (Math.random() - 0.5) * 0.3));
        if (onStir) onStir();
      }
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!orbitRef.current.isDragging) return;

      const deltaX = e.clientX - orbitRef.current.previousMousePosition.x;
      const deltaY = e.clientY - orbitRef.current.previousMousePosition.y;

      if (orbitRef.current.isInteracting) {
        // Dragging inside lamp: impart directional stir to wax
        simulation.stir(new THREE.Vector3(deltaX * 0.008, -deltaY * 0.008, 0));
      } else {
        // Orbit camera
        orbitRef.current.spherical.theta -= deltaX * 0.006;
        orbitRef.current.spherical.phi = THREE.MathUtils.clamp(
          orbitRef.current.spherical.phi + deltaY * 0.006,
          0.25,
          Math.PI / 2.02
        );
      }

      orbitRef.current.previousMousePosition = { x: e.clientX, y: e.clientY };
    };

    const onMouseUp = () => {
      orbitRef.current.isDragging = false;
      orbitRef.current.isInteracting = false;
    };

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      orbitRef.current.spherical.radius = THREE.MathUtils.clamp(
        orbitRef.current.spherical.radius + e.deltaY * 0.005,
        4.0,
        14.0
      );
    };

    // Touch support for mobile / tablet
    const onTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 1) {
        orbitRef.current.isDragging = true;
        orbitRef.current.previousMousePosition = {
          x: e.touches[0].clientX,
          y: e.touches[0].clientY,
        };
      }
    };

    const onTouchMove = (e: TouchEvent) => {
      if (e.touches.length === 1 && orbitRef.current.isDragging) {
        const deltaX = e.touches[0].clientX - orbitRef.current.previousMousePosition.x;
        const deltaY = e.touches[0].clientY - orbitRef.current.previousMousePosition.y;

        orbitRef.current.spherical.theta -= deltaX * 0.008;
        orbitRef.current.spherical.phi = THREE.MathUtils.clamp(
          orbitRef.current.spherical.phi + deltaY * 0.008,
          0.25,
          Math.PI / 2.02
        );

        orbitRef.current.previousMousePosition = {
          x: e.touches[0].clientX,
          y: e.touches[0].clientY,
        };
      }
    };

    const onTouchEnd = () => {
      orbitRef.current.isDragging = false;
    };

    const domElem = renderer.domElement;
    domElem.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    domElem.addEventListener('wheel', onWheel, { passive: false });
    domElem.addEventListener('touchstart', onTouchStart);
    window.addEventListener('touchmove', onTouchMove);
    window.addEventListener('touchend', onTouchEnd);

    // 5. Physics & Render Loop
    const animate = (currentTime: number) => {
      animFrameId = requestAnimationFrame(animate);

      const dt = Math.min((currentTime - lastTime) / 1000, 0.04);
      lastTime = currentTime;

      // Auto-rotation if enabled
      if (options.autoRotate && !orbitRef.current.isDragging) {
        orbitRef.current.spherical.theta += 0.25 * dt;
      }

      // Smooth camera position update
      camera.position.setFromSpherical(orbitRef.current.spherical);
      camera.lookAt(orbitRef.current.target);

      // Advance physics simulation
      simulation.step(dt);

      // Update shader uniforms
      if (materialRef.current) {
        const uniforms = materialRef.current.uniforms;
        uniforms.uTime.value = currentTime * 0.001;
        uniforms.uCameraPos.value.copy(camera.position);
        uniforms.uBasePoolHeight.value = simulation.basePoolHeight;
        uniforms.uTopPoolHeight.value = simulation.topPoolHeight;
        uniforms.uViscosity.value = simParams.viscosity;
        uniforms.uNoiseIntensity.value = options.noiseAmount;

        // Bulb power ramp (smooth on/off transition)
        const targetBulb = options.powerOn ? options.brightness : 0.0;
        uniforms.uBulbPower.value += (targetBulb - uniforms.uBulbPower.value) * 3.0 * dt;

        // Blobs arrays
        const blobs = simulation.blobs;
        const blobArr = uniforms.uBlobs.value as THREE.Vector4[];
        const velArr = uniforms.uBlobVelocities.value as THREE.Vector3[];
        const defArr = uniforms.uBlobDeform.value as THREE.Vector3[];

        uniforms.uBlobCount.value = Math.min(blobs.length, 20);

        for (let i = 0; i < 20; i++) {
          if (i < blobs.length && blobs[i].active) {
            const b = blobs[i];
            blobArr[i].set(b.position.x, b.position.y, b.position.z, b.radius);
            velArr[i].set(b.velocity.x, b.velocity.y, b.velocity.z);
            defArr[i].set(b.deform.x, b.deform.y, b.deform.z);
          } else {
            blobArr[i].set(0, -99, 0, 0); // inactive
            velArr[i].set(0, 0, 0);
            defArr[i].set(1, 1, 1);
          }
        }
      }

      // Update bulb light intensity & color
      if (pointLightRef.current) {
        const targetBulb = options.powerOn ? options.brightness * 2.8 : 0.05;
        pointLightRef.current.intensity += (targetBulb - pointLightRef.current.intensity) * 3.0 * dt;
        pointLightRef.current.color.set(options.waxColor);
      }

      // Table reflection glow
      if (tableGlowMat) {
        tableGlowMat.color.set(options.waxColor);
        tableGlowMat.opacity = (options.powerOn ? 0.22 : 0.02) * options.brightness;
      }

      // Base coil glow
      if (coilMeshRef.current) {
        const coilM = coilMeshRef.current.material as THREE.MeshStandardMaterial;
        const hotGlow = (simParams.temperature - 20) / 55;
        coilM.emissiveIntensity = options.powerOn ? 0.2 + hotGlow * 1.2 : 0.05;
      }

      renderer.render(scene, camera);
    };

    animFrameId = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(animFrameId);
      window.removeEventListener('resize', handleResize);
      domElem.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      domElem.removeEventListener('wheel', onWheel);
      domElem.removeEventListener('touchstart', onTouchStart);
      window.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('touchend', onTouchEnd);

      if (rendererRef.current && rendererRef.current.domElement) {
        rendererRef.current.dispose();
        if (container.contains(rendererRef.current.domElement)) {
          container.removeChild(rendererRef.current.domElement);
        }
      }
    };
  }, [getFinishMaterial]);

  // Synchronize color & finish updates without rebuilding scene
  useEffect(() => {
    if (materialRef.current) {
      materialRef.current.uniforms.uLiquidColor.value.set(options.liquidColor);
      materialRef.current.uniforms.uWaxColor.value.set(options.waxColor);
      materialRef.current.uniforms.uBrightness.value = options.brightness;
    }
    if (pointLightRef.current) {
      pointLightRef.current.color.set(options.waxColor);
    }
  }, [options.liquidColor, options.waxColor, options.brightness]);

  // Update base & cap material finish
  useEffect(() => {
    const newMat = getFinishMaterial(options.lampFinish);
    if (baseMeshRef.current) baseMeshRef.current.material = newMat;
    if (capMeshRef.current) capMeshRef.current.material = newMat;
  }, [options.lampFinish, getFinishMaterial]);

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full select-none overflow-hidden cursor-grab active:cursor-grabbing"
    />
  );
};
