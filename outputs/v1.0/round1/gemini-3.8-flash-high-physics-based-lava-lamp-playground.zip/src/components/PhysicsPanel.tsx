import React from 'react';
import { EMULSION_PRESETS, EmulsionPreset } from '../constants/presets';
import { SimulationParams, LavaSimulation } from '../simulation/LavaSimulation';
import { X, Thermometer, Gauge, Wind, Shapes, RotateCcw, Flame } from 'lucide-react';

interface PhysicsPanelProps {
  isOpen: boolean;
  onClose: () => void;
  simulation: LavaSimulation;
  simParams: SimulationParams;
  onUpdateParams: (newParams: Partial<SimulationParams>) => void;
  onCoalesce: () => void;
  onHeatUp: () => void;
}

export const PhysicsPanel: React.FC<PhysicsPanelProps> = ({
  isOpen,
  onClose,
  simulation,
  simParams,
  onUpdateParams,
  onCoalesce,
  onHeatUp,
}) => {
  if (!isOpen) return null;

  // Temperature status label
  const getTempStatus = (t: number) => {
    if (t < 30) return { label: 'Cold / Dormant', color: 'text-blue-400', bg: 'bg-blue-500/10' };
    if (t < 46) return { label: 'Warm (Sluggish)', color: 'text-amber-400', bg: 'bg-amber-500/10' };
    if (t <= 58) return { label: 'Ideal Convective Flow', color: 'text-emerald-400', bg: 'bg-emerald-500/10' };
    return { label: 'Overheating (Rapid Boiling)', color: 'text-red-400', bg: 'bg-red-500/10' };
  };

  const status = getTempStatus(simParams.temperature);

  return (
    <div className="absolute top-16 left-4 sm:left-6 w-96 max-w-[calc(100vw-2rem)] bg-zinc-950/85 backdrop-blur-xl border border-zinc-800/80 rounded-2xl p-5 shadow-2xl text-white z-40 animate-in fade-in slide-in-from-top-4 duration-200">
      <div className="flex items-center justify-between pb-3 border-b border-zinc-800/80">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-indigo-500/20 text-indigo-400">
            <Gauge className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-semibold text-sm">Physics & Emulsions Lab</h3>
            <p className="text-xs text-zinc-400">Thermal convection, density & viscosity</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-1.5 rounded-lg hover:bg-zinc-800/80 text-zinc-400 hover:text-white transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Emulsion Presets */}
      <div className="my-3">
        <label className="text-xs font-semibold text-zinc-300 uppercase tracking-wider block mb-1.5">
          Emulsion Presets
        </label>
        <div className="grid grid-cols-2 gap-1.5">
          {EMULSION_PRESETS.map((preset: EmulsionPreset) => {
            const isSelected =
              Math.abs(simParams.temperature - preset.temperature) < 1 &&
              Math.abs(simParams.viscosity - preset.viscosity) < 0.1;
            return (
              <button
                key={preset.id}
                onClick={() => {
                  onUpdateParams({
                    temperature: preset.temperature,
                    viscosity: preset.viscosity,
                    waxDensity: preset.waxDensity,
                    liquidDensity: preset.liquidDensity,
                    surfaceTension: preset.surfaceTension,
                    randomness: preset.randomness,
                    coalesceMode: false,
                  });
                }}
                className={`p-2 rounded-xl text-left border text-xs transition-all ${
                  isSelected
                    ? 'border-indigo-500 bg-indigo-500/15 text-indigo-300 font-medium'
                    : 'border-zinc-800 hover:border-zinc-700 bg-zinc-900/40 text-zinc-300 hover:bg-zinc-900/80'
                }`}
              >
                <div className="font-medium truncate">{preset.name}</div>
                <div className="text-[10px] text-zinc-400">
                  {preset.temperature}°C • μ={preset.viscosity}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Sliders */}
      <div className="space-y-4 pt-2 border-t border-zinc-800/80">
        {/* Heater Temperature */}
        <div>
          <div className="flex items-center justify-between text-xs mb-1">
            <span className="flex items-center gap-1.5 text-zinc-200">
              <Thermometer className="w-3.5 h-3.5 text-rose-400" /> Base Heater Temperature
            </span>
            <span className="font-mono text-xs font-semibold text-rose-300">
              {Math.round(simParams.temperature)}°C
            </span>
          </div>
          <div className="flex items-center gap-2">
            <input
              type="range"
              min="20"
              max="75"
              step="1"
              value={simParams.temperature}
              onChange={(e) =>
                onUpdateParams({ temperature: parseFloat(e.target.value), coalesceMode: false })
              }
              className="w-full accent-rose-500 h-1.5 bg-zinc-800 rounded-lg cursor-pointer"
            />
          </div>
          <div className={`mt-1 text-[11px] px-2 py-0.5 rounded-md inline-block font-medium ${status.color} ${status.bg}`}>
            {status.label}
          </div>
        </div>

        {/* Viscosity (governed by temperature & fluid properties) */}
        <div>
          <div className="flex items-center justify-between text-xs mb-1">
            <span className="flex items-center gap-1.5 text-zinc-200">
              <Wind className="w-3.5 h-3.5 text-cyan-400" /> Emulsion Viscosity (μ)
            </span>
            <span className="font-mono text-xs text-zinc-300">
              {simParams.viscosity.toFixed(2)}x
            </span>
          </div>
          <input
            type="range"
            min="0.2"
            max="2.5"
            step="0.05"
            value={simParams.viscosity}
            onChange={(e) => onUpdateParams({ viscosity: parseFloat(e.target.value) })}
            className="w-full accent-cyan-500 h-1.5 bg-zinc-800 rounded-lg cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-zinc-500 mt-0.5">
            <span>Thin / Fluid</span>
            <span>Balanced Syrupy</span>
            <span>Heavy Glacial</span>
          </div>
        </div>

        {/* Emulsion Densities */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <div className="flex justify-between text-[11px] mb-1">
              <span className="text-zinc-300">Wax Density (ρw)</span>
              <span className="font-mono text-zinc-400">{simParams.waxDensity.toFixed(3)}</span>
            </div>
            <input
              type="range"
              min="0.94"
              max="1.06"
              step="0.005"
              value={simParams.waxDensity}
              onChange={(e) => onUpdateParams({ waxDensity: parseFloat(e.target.value) })}
              className="w-full accent-amber-500 h-1.5 bg-zinc-800 rounded-lg cursor-pointer"
            />
          </div>
          <div>
            <div className="flex justify-between text-[11px] mb-1">
              <span className="text-zinc-300">Liquid Density (ρl)</span>
              <span className="font-mono text-zinc-400">{simParams.liquidDensity.toFixed(3)}</span>
            </div>
            <input
              type="range"
              min="0.95"
              max="1.05"
              step="0.005"
              value={simParams.liquidDensity}
              onChange={(e) => onUpdateParams({ liquidDensity: parseFloat(e.target.value) })}
              className="w-full accent-blue-500 h-1.5 bg-zinc-800 rounded-lg cursor-pointer"
            />
          </div>
        </div>

        {/* Randomness & Organic Non-Spherical Shape Perturbation */}
        <div>
          <div className="flex items-center justify-between text-xs mb-1">
            <span className="flex items-center gap-1.5 text-zinc-200">
              <Shapes className="w-3.5 h-3.5 text-purple-400" /> Blob Randomness & Wobble
            </span>
            <span className="font-mono text-xs text-purple-300">
              {Math.round(simParams.randomness * 100)}%
            </span>
          </div>
          <input
            type="range"
            min="0.2"
            max="1.6"
            step="0.05"
            value={simParams.randomness}
            onChange={(e) => onUpdateParams({ randomness: parseFloat(e.target.value) })}
            className="w-full accent-purple-500 h-1.5 bg-zinc-800 rounded-lg cursor-pointer"
          />
          <span className="text-[10px] text-zinc-400 block mt-0.5">
            Controls asymmetric elongation, teardrop tapering & 3D noise ripples
          </span>
        </div>
      </div>

      {/* Planar Top Wax Pool & Coalescence Action */}
      <div className="mt-4 pt-3 border-t border-zinc-800/80 space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs text-zinc-300 font-medium">Base Pool (Planar Top):</span>
          <span className="text-xs font-mono text-emerald-400">
            Height: {simulation.basePoolHeight.toFixed(2)} units
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={onCoalesce}
            className="px-3 py-2 rounded-xl bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 border border-blue-500/40 text-xs font-medium flex items-center justify-center gap-1.5 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Coalesce to Base
          </button>
          <button
            onClick={onHeatUp}
            className="px-3 py-2 rounded-xl bg-orange-500/20 hover:bg-orange-500/30 text-orange-300 border border-orange-500/40 text-xs font-medium flex items-center justify-center gap-1.5 transition-colors"
          >
            <Flame className="w-3.5 h-3.5" />
            Warm Up / Flow
          </button>
        </div>
      </div>
    </div>
  );
};
