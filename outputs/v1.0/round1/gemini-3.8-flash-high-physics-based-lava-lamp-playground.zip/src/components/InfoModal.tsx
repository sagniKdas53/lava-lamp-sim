import React from 'react';
import { X, BookOpen, Layers, Flame, Droplets, HelpCircle, Move } from 'lucide-react';

interface InfoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InfoModal: React.FC<InfoModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-zinc-950 border border-zinc-800 rounded-3xl max-w-xl w-full p-6 text-white shadow-2xl relative max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold">Lava Lamp Physics & Fluid Dynamics</h2>
              <p className="text-xs text-zinc-400">Emulsion densities, buoyancy, and non-spherical morphs</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl hover:bg-zinc-850 text-zinc-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Sections */}
        <div className="mt-5 space-y-4 text-xs text-zinc-300 leading-relaxed">
          {/* 1. Emulsion Densities & Archimedes Buoyancy */}
          <div className="p-3.5 rounded-2xl bg-zinc-900/60 border border-zinc-800/80">
            <div className="flex items-center gap-2 text-rose-400 font-semibold mb-1 text-sm">
              <Flame className="w-4 h-4" /> Thermal Buoyancy & Rayleigh-Bénard Convection
            </div>
            <p>
              In authentic lava lamps, two mutually insoluble emulsions are balanced at nearly identical densities (within 0.2%).
              At room temperature, the paraffin wax is denser than water (<span className="text-blue-300 font-mono">ρwax &gt; ρliquid</span>) and rests at the base.
              When heated by the base bulb, the wax expands thermally (<span className="text-rose-300 font-mono">Δρ = -β·ΔT</span>).
              As its density drops below the liquid (<span className="text-emerald-300 font-mono">ρwax &lt; ρliquid</span>), Archimedes buoyancy propels rising molten plumes!
            </p>
          </div>

          {/* 2. Planar Top Wax Pool */}
          <div className="p-3.5 rounded-2xl bg-zinc-900/60 border border-zinc-800/80">
            <div className="flex items-center gap-2 text-indigo-400 font-semibold mb-1 text-sm">
              <Layers className="w-4 h-4" /> Planar Top Base Reservoir
            </div>
            <p>
              When the wax cools or settles back down, gravity and container confinement cause the wax to coalesce into a single reservoir at the bottom.
              Because liquid wax conforms to hydrostatic equilibrium, this settled pool features a distinct <strong>planar (flat) top surface</strong> with a subtle liquid meniscus along the glass walls.
            </p>
          </div>

          {/* 3. Non-Spherical Organic Randomness & Viscosity */}
          <div className="p-3.5 rounded-2xl bg-zinc-900/60 border border-zinc-800/80">
            <div className="flex items-center gap-2 text-cyan-400 font-semibold mb-1 text-sm">
              <Droplets className="w-4 h-4" /> Organic Non-Spherical Shapes & Viscosity
            </div>
            <p>
              Real lava lamp globules are rarely simple spheres. Drag forces cause rising blobs to stretch into elongated teardrops, while sinking cooler blobs mushroom out.
              Surface tension oscillations and 3D fluid vortices induce rich undulating ripples, waist pinch-offs, and viscous capillary bridges when globules coalesce.
            </p>
          </div>

          {/* 4. Controls & Hotkeys */}
          <div className="p-3.5 rounded-2xl bg-zinc-900/60 border border-zinc-800/80">
            <div className="flex items-center gap-2 text-amber-400 font-semibold mb-2 text-sm">
              <HelpCircle className="w-4 h-4" /> Playground Interactions & Shortcuts
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="flex items-center gap-2">
                <kbd className="px-1.5 py-0.5 rounded bg-zinc-800 border border-zinc-700 text-zinc-300 font-mono">H</kbd>
                <span>Toggle UI (Zen Mode)</span>
              </div>
              <div className="flex items-center gap-2">
                <Move className="w-3.5 h-3.5 text-zinc-400" />
                <span>Orbit 360° / Pan Camera</span>
              </div>
              <div className="flex items-center gap-2">
                <kbd className="px-1.5 py-0.5 rounded bg-zinc-800 border border-zinc-700 text-zinc-300 font-mono">Scroll</kbd>
                <span>Zoom In / Out</span>
              </div>
              <div className="flex items-center gap-2">
                <kbd className="px-1.5 py-0.5 rounded bg-zinc-800 border border-zinc-700 text-zinc-300 font-mono">Click Lamp</kbd>
                <span>Stir / Agitate Fluid</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-5 pt-3 border-t border-zinc-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs transition-colors shadow-lg"
          >
            Got it, Let's Flow
          </button>
        </div>
      </div>
    </div>
  );
};
