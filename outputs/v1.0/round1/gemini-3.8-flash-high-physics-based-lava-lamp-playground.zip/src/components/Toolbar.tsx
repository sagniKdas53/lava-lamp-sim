import React from 'react';
import {
  Power,
  RotateCcw,
  Flame,
  Waves,
  SunMedium,
  Sliders,
  Ruler,
  Rotate3d,
  EyeOff,
  Eye,
} from 'lucide-react';
import { LampFinish } from './LavaLampScene';

interface ToolbarProps {
  powerOn: boolean;
  onTogglePower: () => void;
  onCoalesce: () => void;
  onHeatUp: () => void;
  onStir: () => void;
  brightness: number;
  onChangeBrightness: (b: number) => void;
  isColorOpen: boolean;
  onToggleColor: () => void;
  isPhysicsOpen: boolean;
  onTogglePhysics: () => void;
  showDimensions: boolean;
  onToggleDimensions: () => void;
  autoRotate: boolean;
  onToggleAutoRotate: () => void;
  lampFinish: LampFinish;
  onChangeFinish: (f: LampFinish) => void;
  isControlsHidden: boolean;
  onToggleHideControls: () => void;
  currentLiquidColor: string;
  currentWaxColor: string;
}

export const Toolbar: React.FC<ToolbarProps> = ({
  powerOn,
  onTogglePower,
  onCoalesce,
  onHeatUp,
  onStir,
  brightness,
  onChangeBrightness,
  isColorOpen,
  onToggleColor,
  isPhysicsOpen,
  onTogglePhysics,
  showDimensions,
  onToggleDimensions,
  autoRotate,
  onToggleAutoRotate,
  lampFinish,
  onChangeFinish,
  isControlsHidden,
  onToggleHideControls,
  currentLiquidColor,
  currentWaxColor,
}) => {
  if (isControlsHidden) {
    return (
      <div className="absolute bottom-6 right-6 z-50">
        <button
          onClick={onToggleHideControls}
          className="flex items-center gap-2 px-3.5 py-2 rounded-full bg-zinc-900/80 hover:bg-zinc-800 text-zinc-300 hover:text-white border border-zinc-700/80 backdrop-blur-md shadow-xl text-xs font-medium transition-all group"
          title="Show Controls (Press 'H')"
        >
          <Eye className="w-4 h-4 text-indigo-400 group-hover:scale-110 transition-transform" />
          <span>Show Controls</span>
          <kbd className="px-1.5 py-0.5 rounded bg-zinc-800 text-[10px] text-zinc-400 border border-zinc-700">H</kbd>
        </button>
      </div>
    );
  }

  return (
    <div className="absolute bottom-5 inset-x-0 mx-auto w-fit max-w-[calc(100vw-1.5rem)] z-30 select-none animate-in fade-in slide-in-from-bottom-4 duration-200">
      <div className="flex items-center gap-1.5 sm:gap-2 px-3 py-2 sm:px-4 sm:py-2.5 rounded-2xl bg-zinc-950/80 backdrop-blur-xl border border-zinc-800/80 shadow-2xl text-white">
        {/* 1. POWER BUTTON */}
        <button
          onClick={onTogglePower}
          className={`relative p-2.5 rounded-xl border transition-all ${
            powerOn
              ? 'bg-emerald-500/15 border-emerald-500/60 text-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.35)]'
              : 'bg-zinc-900/60 border-zinc-800 text-zinc-500 hover:text-zinc-300'
          }`}
          title={powerOn ? 'Power Off (Cool Down)' : 'Power On (Warm Up)'}
        >
          <Power className="w-4 h-4" />
          {powerOn && (
            <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          )}
        </button>

        <div className="h-6 w-px bg-zinc-800 hidden sm:block" />

        {/* 2. COALESCE TO PLANAR BASE */}
        <button
          onClick={onCoalesce}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-blue-500/10 hover:bg-blue-500/20 text-blue-300 border border-blue-500/30 text-xs font-medium transition-all"
          title="Cool down and coalesce all wax back into the flat-topped base pool"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span className="hidden md:inline">Coalesce</span>
        </button>

        {/* 3. HEAT UP / FLOW */}
        <button
          onClick={onHeatUp}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-medium transition-all"
          title="Heat base to initiate buoyant rising plumes"
        >
          <Flame className="w-3.5 h-3.5" />
          <span className="hidden md:inline">Heat Up</span>
        </button>

        {/* 4. STIR FLUID */}
        <button
          onClick={onStir}
          className="p-2 sm:px-3 sm:py-2 rounded-xl bg-zinc-900/60 hover:bg-zinc-800 text-cyan-300 border border-zinc-800 hover:border-zinc-700 text-xs font-medium transition-all flex items-center gap-1.5"
          title="Agitate fluid / stir molten globules"
        >
          <Waves className="w-4 h-4" />
          <span className="hidden lg:inline">Stir</span>
        </button>

        <div className="h-6 w-px bg-zinc-800" />

        {/* 5. BRIGHTNESS SLIDER */}
        <div className="flex items-center gap-2 px-2 py-1 rounded-xl bg-zinc-900/40 border border-zinc-800/60">
          <SunMedium className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
          <input
            type="range"
            min="0.1"
            max="1.5"
            step="0.05"
            value={brightness}
            onChange={(e) => onChangeBrightness(parseFloat(e.target.value))}
            className="w-16 sm:w-20 accent-amber-500 h-1.5 bg-zinc-800 rounded-lg cursor-pointer"
            title={`Brightness: ${Math.round(brightness * 100)}%`}
          />
        </div>

        {/* 6. COLOR LAB (2-TONE) */}
        <button
          onClick={onToggleColor}
          className={`flex items-center gap-1.5 px-2.5 py-2 rounded-xl border transition-all ${
            isColorOpen
              ? 'bg-pink-500/20 border-pink-500 text-pink-300'
              : 'bg-zinc-900/60 hover:bg-zinc-800 border-zinc-800 text-zinc-300'
          }`}
          title="Two-tone color palette & presets"
        >
          <div
            className="w-4 h-4 rounded-full flex items-center justify-center border border-white/20 shadow-sm"
            style={{ backgroundColor: currentLiquidColor }}
          >
            <div
              className="w-2 h-2 rounded-full"
              style={{ backgroundColor: currentWaxColor }}
            />
          </div>
          <span className="hidden sm:inline text-xs font-medium">Colors</span>
        </button>

        {/* 7. PHYSICS & EMULSIONS LAB */}
        <button
          onClick={onTogglePhysics}
          className={`flex items-center gap-1.5 px-2.5 py-2 rounded-xl border transition-all ${
            isPhysicsOpen
              ? 'bg-indigo-500/20 border-indigo-500 text-indigo-300'
              : 'bg-zinc-900/60 hover:bg-zinc-800 border-zinc-800 text-zinc-300'
          }`}
          title="Physics, viscosity & emulsion density controls"
        >
          <Sliders className="w-3.5 h-3.5 text-indigo-400" />
          <span className="hidden sm:inline text-xs font-medium">Physics</span>
        </button>

        {/* 8. LAMP FINISH TOGGLE */}
        <div className="hidden xl:flex items-center gap-1 px-1.5 py-1 rounded-xl bg-zinc-900/50 border border-zinc-800">
          {(['silver', 'black', 'gold'] as LampFinish[]).map((f) => (
            <button
              key={f}
              onClick={() => onChangeFinish(f)}
              className={`w-5 h-5 rounded-full border transition-all capitalize ${
                lampFinish === f
                  ? 'border-white scale-110 ring-1 ring-white/50'
                  : 'border-white/20 opacity-60 hover:opacity-100'
              }`}
              style={{
                backgroundColor:
                  f === 'black' ? '#18181b' : f === 'gold' ? '#d4af37' : '#d1d5db',
              }}
              title={`${f} metal finish`}
            />
          ))}
        </div>

        <div className="h-6 w-px bg-zinc-800 hidden sm:block" />

        {/* 9. DIMENSIONS & BLUEPRINT OVERLAY */}
        <button
          onClick={onToggleDimensions}
          className={`p-2 rounded-xl border transition-all ${
            showDimensions
              ? 'bg-white/15 border-white text-white'
              : 'bg-zinc-900/60 hover:bg-zinc-800 border-zinc-800 text-zinc-400 hover:text-zinc-200'
          }`}
          title="Toggle Dimension Markers (40 cm, 10.5 cm base)"
        >
          <Ruler className="w-4 h-4" />
        </button>

        {/* 10. AUTO-ROTATE */}
        <button
          onClick={onToggleAutoRotate}
          className={`p-2 rounded-xl border transition-all ${
            autoRotate
              ? 'bg-indigo-500/20 border-indigo-500/60 text-indigo-300'
              : 'bg-zinc-900/60 hover:bg-zinc-800 border-zinc-800 text-zinc-400 hover:text-zinc-200'
          }`}
          title={autoRotate ? 'Pause 360° Rotation' : 'Enable 360° Auto Orbit'}
        >
          <Rotate3d className="w-4 h-4" />
        </button>

        {/* 11. HIDE CONTROLS (ZEN MODE) */}
        <button
          onClick={onToggleHideControls}
          className="p-2 rounded-xl bg-zinc-900/60 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-white transition-all"
          title="Hide Controls (Press 'H' or Esc for Zen Mode)"
        >
          <EyeOff className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
