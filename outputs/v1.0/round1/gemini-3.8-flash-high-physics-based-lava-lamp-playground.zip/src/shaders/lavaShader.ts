// Shaders for the raymarched lava lamp interior volume

export const lavaVertexShader = `
varying vec3 vWorldPosition;
varying vec3 vLocalPosition;
varying vec3 vNormal;
varying vec2 vUv;

void main() {
  vUv = uv;
  vNormal = normalize(normalMatrix * normal);
  vLocalPosition = position;
  vec4 worldPosition = modelMatrix * vec4(position, 1.0);
  vWorldPosition = worldPosition.xyz;
  gl_Position = projectionMatrix * viewMatrix * worldPosition;
}
`;

export const lavaFragmentShader = `
precision highp float;

uniform vec3 uLiquidColor;
uniform vec3 uWaxColor;
uniform float uBrightness;
uniform float uTime;
uniform vec3 uCameraPos;
uniform float uLampRadius;
uniform float uLampHeight;
uniform float uBulbPower;
uniform float uViscosity;
uniform float uBasePoolHeight; // Height of the planar top base reservoir
uniform float uTopPoolHeight;  // Height of top wax if any
uniform float uNoiseIntensity; // Organic shape distortion

// Blob data: vec4(x, y, z, radius)
// We support up to 20 blobs
uniform int uBlobCount;
uniform vec4 uBlobs[20];
uniform vec3 uBlobVelocities[20]; // for directional stretching
uniform vec3 uBlobDeform[20];     // per-blob random stretch axes (sx, sy, sz)

varying vec3 vWorldPosition;
varying vec3 vLocalPosition;
varying vec3 vNormal;
varying vec2 vUv;

// Smooth minimum by Inigo Quilez
float smin(float a, float b, float k) {
  float h = clamp(0.5 + 0.5 * (b - a) / k, 0.0, 1.0);
  return mix(b, a, h) - k * h * (1.0 - h);
}

// 3D Simplex-like fast hash noise for organic blob wobbling
float hash3(vec3 p) {
  p = fract(p * 0.3183099 + 0.1);
  p *= 17.0;
  return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}

float smoothNoise(vec3 p) {
  vec3 i = floor(p);
  vec3 f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  
  return mix(
    mix(mix(hash3(i + vec3(0,0,0)), hash3(i + vec3(1,0,0)), f.x),
        mix(hash3(i + vec3(0,1,0)), hash3(i + vec3(1,1,0)), f.x), f.y),
    mix(mix(hash3(i + vec3(0,0,1)), hash3(i + vec3(1,0,1)), f.x),
        mix(hash3(i + vec3(0,1,1)), hash3(i + vec3(1,1,1)), f.x), f.y),
    f.z
  );
}

// Lamp glass profile radius as a function of height y in [-halfH, +halfH]
float getLampRadiusAt(float y) {
  // Bottle profile: slightly wider at bottom, tapered waist, gently rounded top
  float ny = y / (uLampHeight * 0.5); // -1.0 to +1.0
  // Classic hourglass/rocket taper
  float r = uLampRadius * (0.88 - 0.18 * ny - 0.12 * ny * ny + 0.08 * sin(ny * 2.0));
  return max(r, 0.4);
}

// Distance to the base wax reservoir with a planar top!
// The user explicitly requested:
// "the wax should start out and coalesce back into a single blob which due to the nature of the container and gravity should have a plan top"
float sdBasePool(vec3 p) {
  float bottomY = -uLampHeight * 0.5 + 0.05;
  float poolTopY = bottomY + uBasePoolHeight;
  
  if (uBasePoolHeight <= 0.01) return 100.0;
  
  float rad = getLampRadiusAt(p.y) - 0.06;
  float dCyl = length(p.xz) - rad;
  float dTop = p.y - poolTopY;
  float dBot = bottomY - p.y;
  
  // Cut pool with flat/planar top and rounded rim
  float d = max(dCyl, max(dTop, dBot));
  
  // Slight meniscus curve near the edge and subtle planar warmth ripple
  float rim = smoothstep(0.0, rad, length(p.xz));
  d -= 0.02 * (1.0 - rim);
  
  return d;
}

// Top cooling wax pool (when blobs reach top and cool down before dropping)
float sdTopPool(vec3 p) {
  if (uTopPoolHeight <= 0.01) return 100.0;
  float topY = uLampHeight * 0.5 - 0.05;
  float poolBotY = topY - uTopPoolHeight;
  
  float rad = getLampRadiusAt(p.y) - 0.06;
  float dCyl = length(p.xz) - rad;
  float dTop = p.y - topY;
  float dBot = poolBotY - p.y;
  return max(dCyl, max(dTop, dBot));
}

// Deformed blob SDF: includes vertical velocity stretching, wobble, and 3D noise
float sdBlob(vec3 p, vec4 blob, vec3 vel, vec3 deform, float index) {
  vec3 center = blob.xyz;
  float baseRadius = blob.w;
  if (baseRadius <= 0.001) return 100.0;

  vec3 q = p - center;
  
  // 1. Dynamic elongation along velocity (stretch rising / falling blobs into teardrops)
  float speed = length(vel);
  float stretch = clamp(speed * 0.7, 0.0, 0.65);
  
  // Deform vector incorporates per-blob asymmetric factors
  vec3 scale = vec3(1.0 - stretch * 0.35, 1.0 + stretch * 0.65, 1.0 - stretch * 0.35) * deform;
  q /= scale;
  
  // 2. Teardrop tapering along movement direction
  if (vel.y > 0.05) {
    // Rising: bottom is rounded, top is tapered
    q.x *= (1.0 + 0.25 * clamp(q.y / baseRadius, -0.8, 1.0));
    q.z *= (1.0 + 0.25 * clamp(q.y / baseRadius, -0.8, 1.0));
  } else if (vel.y < -0.05) {
    // Sinking: bottom is flattened/mushroomed, top is tapered
    q.x *= (1.0 - 0.2 * clamp(q.y / baseRadius, -1.0, 0.8));
    q.z *= (1.0 - 0.2 * clamp(q.y / baseRadius, -1.0, 0.8));
  }
  
  // 3. Organic non-spherical noise perturbation (user requested: not all round!)
  float freq = 2.4;
  vec3 noiseCoord = p * freq + vec3(uTime * 0.6 + index * 1.7, uTime * 0.4, index * 2.3);
  float noise = (smoothNoise(noiseCoord) - 0.5) * 2.0;
  
  // Surface wave harmonics for fluid oscillation
  float harmonic = sin(q.x * 3.5 + uTime * 1.5) * cos(q.y * 3.0 + uTime * 1.2) * sin(q.z * 3.5);
  
  float dist = length(q) - baseRadius;
  // Apply organic noise perturbation scaled by radius and noise intensity
  dist += (noise * 0.16 + harmonic * 0.08) * baseRadius * uNoiseIntensity;
  
  return dist * min(scale.x, min(scale.y, scale.z));
}

// Complete scene SDF
float map(vec3 p) {
  // Start with base pool (settled planar-topped wax reservoir)
  float d = sdBasePool(p);
  
  // Blend with top cooling wax pool if present
  float dTop = sdTopPool(p);
  d = smin(d, dTop, 0.15);
  
  // Viscosity determines blending smoothness (higher viscosity = thicker liquid bridges)
  float blendK = mix(0.18, 0.42, clamp(uViscosity, 0.0, 1.0));
  
  // Smoothly blend each globule
  for (int i = 0; i < 20; i++) {
    if (i >= uBlobCount) break;
    float db = sdBlob(p, uBlobs[i], uBlobVelocities[i], uBlobDeform[i], float(i));
    d = smin(d, db, blendK);
  }
  
  // Constrain within the bottle inner walls so wax never pokes outside
  float wallRadius = getLampRadiusAt(p.y) - 0.04;
  float dWalls = -(wallRadius - length(p.xz));
  d = max(d, dWalls);
  
  return d;
}

// Calculate normal via tetrahedron technique
vec3 calcNormal(vec3 p) {
  const float h = 0.003;
  const vec2 k = vec2(1.0, -1.0);
  return normalize(
    k.xyy * map(p + k.xyy * h) +
    k.yyx * map(p + k.yyx * h) +
    k.yxy * map(p + k.yxy * h) +
    k.xxx * map(p + k.xxx * h)
  );
}

void main() {
  // Ray calculation in local lamp space
  vec3 ro = vLocalPosition;
  vec3 rd = normalize(vLocalPosition - (inverse(modelMatrix) * vec4(uCameraPos, 1.0)).xyz);
  
  // Raymarch parameters
  const int MAX_STEPS = 54;
  const float MAX_DIST = 4.5;
  const float EPSILON = 0.003;
  
  float t = 0.0;
  float hitDist = -1.0;
  vec3 hitPos = vec3(0.0);
  
  // Raymarch loop
  for (int i = 0; i < MAX_STEPS; i++) {
    vec3 p = ro + rd * t;
    
    // Check if we exited the bottle boundaries
    if (abs(p.y) > uLampHeight * 0.52 || length(p.xz) > uLampRadius * 1.35) {
      break;
    }
    
    float d = map(p);
    if (d < EPSILON) {
      hitDist = t;
      hitPos = p;
      break;
    }
    
    t += max(d * 0.72, 0.012);
    if (t > MAX_DIST) break;
  }
  
  // Incandescent base bulb position in local space
  vec3 bulbPos = vec3(0.0, -uLampHeight * 0.5 - 0.05, 0.0);
  
  // Two-tone absorption & scattering colors
  vec3 liquidCol = uLiquidColor;
  vec3 waxCol = uWaxColor;
  
  // Base bulb light color (warm incandescent amber light + brightness)
  vec3 bulbColor = mix(vec3(1.0, 0.82, 0.55), waxCol, 0.28) * uBulbPower * uBrightness;
  
  if (hitDist > 0.0) {
    // --- RAY HIT WAX GLOBULE ---
    vec3 n = calcNormal(hitPos);
    vec3 v = -rd;
    
    // Light from incandescent base bulb
    vec3 toBulb = bulbPos - hitPos;
    float bulbDist = length(toBulb);
    vec3 lBulb = normalize(toBulb);
    
    // Subsurface / Translucent glow from bulb inside the wax
    // Light travels through wax from bottom: blobs closer to bottom glow brighter!
    float heightRel = (hitPos.y + uLampHeight * 0.5) / uLampHeight; // 0.0 at base to 1.0 at top
    float bottomGlow = exp(-heightRel * 3.2) * 1.8;
    
    // Backlight / transmission scattering through the translucent wax
    float transDot = max(0.0, dot(v, -lBulb));
    float translucency = pow(transDot, 2.5) * 1.4 / (1.0 + bulbDist * 0.4);
    
    // Diffuse from bulb & key ambient light
    float diffBulb = max(0.0, dot(n, -lBulb)) * 0.7;
    vec3 keyLightDir = normalize(vec3(0.6, 1.0, 0.8));
    float diffKey = max(0.0, dot(n, keyLightDir)) * 0.5;
    
    // Specular highlight on glossy molten wax
    vec3 hBulb = normalize(-lBulb + v);
    float specBulb = pow(max(0.0, dot(n, hBulb)), 32.0) * 0.9;
    vec3 hKey = normalize(keyLightDir + v);
    float specKey = pow(max(0.0, dot(n, hKey)), 24.0) * 0.4;
    
    // Fresnel rim on wax globules
    float fresnel = pow(1.0 - max(0.0, dot(n, v)), 3.0);
    
    // Internal light scattering inside wax (Lava lamp wax is semi-opaque with bright core)
    vec3 waxAmbient = waxCol * (0.28 + bottomGlow * 0.45);
    vec3 waxDirect = waxCol * (diffBulb * bulbColor + diffKey * vec3(0.9, 0.95, 1.0));
    vec3 waxTrans = mix(waxCol, vec3(1.0, 0.95, 0.8), 0.4) * translucency * bulbColor;
    vec3 waxSpec = vec3(1.0, 0.95, 0.9) * (specBulb + specKey);
    vec3 waxRim = mix(waxCol, liquidCol, 0.35) * fresnel * 0.6;
    
    vec3 finalWax = waxAmbient + waxDirect + waxTrans + waxSpec + waxRim;
    
    // Liquid absorption on the way from wax hit to front glass
    vec3 liquidAbsorption = exp(-hitDist * (1.0 - liquidCol) * 0.8);
    vec3 col = finalWax * liquidAbsorption;
    
    // Add liquid glow scatter between camera and wax
    float liquidScatter = hitDist * 0.12 * uBrightness;
    col += liquidCol * liquidScatter * (0.3 + bottomGlow * 0.5);
    
    gl_FragColor = vec4(col, 0.95);
  } else {
    // --- RAY DID NOT HIT WAX: LIQUID ONLY ---
    // Ray traversed through the liquid volume
    float rayLength = min(t, 2.2);
    
    // Distance from ray to bulb at the bottom
    float heightRel = (ro.y + uLampHeight * 0.5) / uLampHeight;
    float bulbScatter = exp(-heightRel * 2.8) / (1.0 + length(ro.xz) * 1.5);
    
    // Liquid color with depth tinting (Beer-Lambert law)
    vec3 liquidTint = liquidCol * 0.35;
    vec3 scatterLight = bulbColor * bulbScatter * 0.65;
    
    // Subtle gradient from warm bottom to cooler top
    vec3 ambientLiquid = mix(liquidCol * 0.25, liquidCol * 0.4, heightRel);
    
    // Caustic / glow variation
    float caustics = 0.05 * sin(ro.y * 12.0 + uTime * 1.8) * cos(ro.x * 10.0 + ro.z * 10.0);
    
    vec3 col = ambientLiquid + scatterLight + liquidTint * (rayLength * 0.3) + caustics;
    
    // Translucency alpha
    float alpha = clamp(0.22 + rayLength * 0.18 + bulbScatter * 0.25, 0.2, 0.85);
    gl_FragColor = vec4(col, alpha);
  }
}
`;
