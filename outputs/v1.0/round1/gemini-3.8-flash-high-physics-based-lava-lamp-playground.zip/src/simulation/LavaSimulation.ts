import * as THREE from 'three';

export interface BlobParticle {
  id: number;
  position: THREE.Vector3;
  velocity: THREE.Vector3;
  temperature: number; // 20°C to 75°C
  radius: number;
  baseRadius: number;
  active: boolean;
  deform: THREE.Vector3;
  deformTarget: THREE.Vector3;
  wobblePhase: number;
  wobbleSpeed: number;
  age: number;
}

export interface SimulationParams {
  temperature: number;      // Heater temperature in °C (20 to 75)
  viscosity: number;        // Viscosity factor (0.2 to 2.5)
  waxDensity: number;       // Base wax density relative to liquid (0.92 to 1.08)
  liquidDensity: number;    // Liquid density (0.95 to 1.05)
  thermalExpansion: number; // Volumetric expansion coeff
  gravity: number;          // Gravity strength
  surfaceTension: number;   // Surface tension (blob elasticity)
  randomness: number;       // Non-spherical organic shape perturbation
  coalesceMode: boolean;    // Force wax to coalesce into base pool
  turbulence: number;       // Fluid eddy currents
}

export class LavaSimulation {
  public blobs: BlobParticle[] = [];
  public maxBlobs = 14;
  public basePoolHeight = 0.52; // Initial planar top base pool height
  public targetPoolHeight = 0.52;
  public topPoolHeight = 0.0;
  public lampHeight = 3.6;
  public lampRadius = 0.95;
  
  // Total wax volume conservation
  private totalWaxVolume = 2.2;
  
  public params: SimulationParams = {
    temperature: 52,        // Warm operational temperature
    viscosity: 1.0,         // Balanced syrupy viscosity
    waxDensity: 0.992,      // Slightly denser than liquid when cold
    liquidDensity: 1.0,
    thermalExpansion: 0.0018,
    gravity: 9.8,
    surfaceTension: 1.2,
    randomness: 0.85,
    coalesceMode: false,
    turbulence: 0.3,
  };

  // External disturbance (e.g. user stirring or shaking)
  private disturbance = new THREE.Vector3();
  private time = 0;

  constructor() {
    this.initBlobs();
  }

  // Profile radius of container at height y
  public getContainerRadiusAt(y: number): number {
    const ny = y / (this.lampHeight * 0.5);
    const r = this.lampRadius * (0.88 - 0.18 * ny - 0.12 * ny * ny + 0.08 * Math.sin(ny * 2.0));
    return Math.max(r, 0.38);
  }

  private initBlobs() {
    this.blobs = [];
    const halfH = this.lampHeight * 0.5;
    const bottomY = -halfH + 0.1;

    // Start with 6 to 9 active blobs distributed along the lamp
    // and a settled base pool with a flat/planar top!
    const initialConfigs = [
      { y: bottomY + 0.6,  r: 0.28, temp: 54, velY: 0.12, dx: 0.08, dz: -0.05 },
      { y: bottomY + 1.2,  r: 0.34, temp: 50, velY: 0.08, dx: -0.1, dz: 0.08 },
      { y: bottomY + 1.9,  r: 0.32, temp: 42, velY: -0.04, dx: 0.12, dz: 0.1 },
      { y: bottomY + 2.5,  r: 0.36, temp: 34, velY: -0.09, dx: -0.06, dz: -0.08 },
      { y: bottomY + 0.85, r: 0.22, temp: 56, velY: 0.15, dx: -0.15, dz: -0.1 },
      { y: bottomY + 1.6,  r: 0.25, temp: 46, velY: 0.05, dx: 0.14, dz: -0.12 },
      { y: bottomY + 2.2,  r: 0.27, temp: 38, velY: -0.06, dx: -0.12, dz: 0.12 },
    ];

    for (let i = 0; i < this.maxBlobs; i++) {
      const cfg = initialConfigs[i];
      const active = i < initialConfigs.length;
      
      const pos = active && cfg
        ? new THREE.Vector3(cfg.dx, cfg.y, cfg.dz)
        : new THREE.Vector3(0, -halfH + 0.2, 0);

      const radius = active && cfg ? cfg.r : 0.24;

      this.blobs.push({
        id: i,
        position: pos,
        velocity: new THREE.Vector3(
          (Math.random() - 0.5) * 0.02,
          active && cfg ? cfg.velY : 0,
          (Math.random() - 0.5) * 0.02
        ),
        temperature: active && cfg ? cfg.temp : 22,
        radius: active ? radius : 0,
        baseRadius: radius,
        active: active,
        deform: new THREE.Vector3(
          0.85 + Math.random() * 0.3,
          0.9 + Math.random() * 0.4,
          0.85 + Math.random() * 0.3
        ),
        deformTarget: new THREE.Vector3(1, 1, 1),
        wobblePhase: Math.random() * Math.PI * 2,
        wobbleSpeed: 1.5 + Math.random() * 1.5,
        age: Math.random() * 50,
      });
    }

    this.recomputePoolHeight();
  }

  // Adjust base pool height depending on how many blobs are currently active / floating
  private recomputePoolHeight() {
    let floatingVolume = 0;
    for (const b of this.blobs) {
      if (b.active) {
        floatingVolume += (4 / 3) * Math.PI * Math.pow(b.radius, 3);
      }
    }

    // Pool volume = totalWaxVolume - floatingVolume
    const poolVolume = Math.max(0.12, this.totalWaxVolume - floatingVolume);
    // Base radius is roughly 0.8
    const avgBaseRad = 0.82;
    // Volume approx = pi * r^2 * h
    this.targetPoolHeight = Math.min(0.95, poolVolume / (Math.PI * avgBaseRad * avgBaseRad));
  }

  public step(dt: number) {
    // Clamp delta time for numerical stability
    const stepDt = Math.min(dt, 0.033);
    this.time += stepDt;

    const halfH = this.lampHeight * 0.5;
    const bottomY = -halfH;
    const topY = halfH;

    // Smoothly animate base pool height
    this.basePoolHeight += (this.targetPoolHeight - this.basePoolHeight) * 2.5 * stepDt;

    // Decay user disturbance
    this.disturbance.multiplyScalar(Math.max(0, 1.0 - 2.5 * stepDt));

    // Temperature distribution along vertical axis of lamp
    // Bottom is heated by bulb: T_bottom = params.temperature
    // Top is cooled by ambient air: T_top = 22°C
    const tBase = this.params.coalesceMode ? 20 : this.params.temperature;
    const tTop = 22.0;

    // Dynamic viscosity based on params & temperature
    // Higher temp -> lower viscosity
    const tempFactor = (tBase - 20) / 55; // 0 to 1
    const effViscosity = this.params.viscosity * (1.6 - tempFactor * 0.9);

    for (let i = 0; i < this.blobs.length; i++) {
      const b = this.blobs[i];
      if (!b.active) continue;

      b.age += stepDt;
      b.wobblePhase += b.wobbleSpeed * stepDt;

      // 1. THERMAL CONDUCTION & CONVECTION
      // Surrounding fluid ambient temperature at height y
      const heightNorm = (b.position.y - bottomY) / this.lampHeight; // 0.0 at bottom, 1.0 at top
      const ambientT = THREE.MathUtils.lerp(tBase, tTop, Math.pow(heightNorm, 0.85));

      // Heat transfer rate: depends on surface-to-volume ratio (smaller blobs heat/cool faster)
      const heatTransferRate = (0.75 / b.radius) * (0.8 + 0.4 / effViscosity);
      b.temperature += (ambientT - b.temperature) * heatTransferRate * stepDt;

      // Extra heating if touching the bottom heating coil / base pool
      const poolTopY = bottomY + this.basePoolHeight;
      if (b.position.y <= poolTopY + 0.15 && !this.params.coalesceMode) {
        b.temperature += (tBase - b.temperature) * 3.5 * stepDt;
      }

      // 2. DENSITY & BUOYANCY FORCE
      // Wax thermal expansion: density decreases as temperature rises!
      // Reference temperature = 42°C (neutral buoyancy point)
      const deltaT = b.temperature - 42.0;
      const currentWaxDensity = this.params.waxDensity * (1.0 - this.params.thermalExpansion * deltaT);
      
      // Net buoyancy acceleration: a_b = ((rho_liquid - rho_wax) / rho_wax) * g
      const densityDiff = this.params.liquidDensity - currentWaxDensity;
      let buoyancyAcc = (densityDiff / currentWaxDensity) * this.params.gravity * 0.42;

      if (this.params.coalesceMode) {
        // In coalesce mode, gravity forces everything back down to the planar pool
        buoyancyAcc = -0.55 * this.params.gravity;
      }

      // 3. FLUID CONVECTION UP/DOWN DRAFT
      // Warm liquid rises in the center, cool liquid falls along the glass walls
      const distFromCenter = Math.sqrt(b.position.x * b.position.x + b.position.z * b.position.z);
      const boundaryRadius = this.getContainerRadiusAt(b.position.y) - b.radius;
      const centerFactor = 1.0 - Math.min(1.0, distFromCenter / Math.max(0.1, boundaryRadius));
      const convectionCurrent = (centerFactor * 2.0 - 1.0) * (tempFactor * 0.18);

      // 4. STOKES VISCOUS DRAG & DAMPING
      // Terminal velocity is reached when buoyancy equals viscous drag
      const dragFactor = (3.2 * effViscosity) / (b.radius * 2.0);

      // Apply forces to velocity
      b.velocity.y += (buoyancyAcc + convectionCurrent) * stepDt;
      b.velocity.y -= b.velocity.y * dragFactor * stepDt;

      // Gentle horizontal wandering & eddy currents
      const eddyAngle = b.age * 0.8 + i * 2.1;
      const eddyMag = this.params.turbulence * 0.08 * (1.0 / effViscosity);
      b.velocity.x += Math.cos(eddyAngle) * eddyMag * stepDt;
      b.velocity.z += Math.sin(eddyAngle) * eddyMag * stepDt;

      // Damp horizontal motion
      b.velocity.x -= b.velocity.x * (dragFactor * 1.5) * stepDt;
      b.velocity.z -= b.velocity.z * (dragFactor * 1.5) * stepDt;

      // Apply external disturbance (stirring)
      b.velocity.addScaledVector(this.disturbance, stepDt * 2.0);

      // Move particle
      b.position.addScaledVector(b.velocity, stepDt);

      // 5. BOUNDARY CONSTRAINTS (Glass Bottle Walls)
      const currentRadius = this.getContainerRadiusAt(b.position.y) - b.radius * 0.7;
      const xzDist = Math.sqrt(b.position.x * b.position.x + b.position.z * b.position.z);
      if (xzDist > currentRadius && currentRadius > 0.05) {
        const nx = b.position.x / xzDist;
        const nz = b.position.z / xzDist;
        b.position.x = nx * currentRadius;
        b.position.z = nz * currentRadius;
        // Inward bounce with damping
        const dot = b.velocity.x * nx + b.velocity.z * nz;
        if (dot > 0) {
          b.velocity.x -= dot * nx * 1.4;
          b.velocity.z -= dot * nz * 1.4;
        }
      }

      // Top ceiling constraint
      const ceilingY = topY - b.radius * 0.8;
      if (b.position.y > ceilingY) {
        b.position.y = ceilingY;
        b.velocity.y *= -0.2;
        // Rapid top cooling
        b.temperature -= 12.0 * stepDt;
      }

      // 6. COALESCENCE INTO PLANAR BASE POOL
      // When a globule reaches the base reservoir, it coalesces smoothly!
      if (b.position.y < poolTopY + 0.08 && b.velocity.y < 0.05) {
        if (this.params.coalesceMode || b.temperature < 40) {
          // Coalesce back into the flat-topped base pool!
          // Softly absorb blob into pool height
          this.targetPoolHeight += Math.pow(b.radius, 3) * 0.6;
          b.active = false;
          b.position.y = bottomY;
          continue;
        } else {
          // Bounce or slide along pool surface
          b.position.y = poolTopY + 0.08;
          b.velocity.y = Math.max(0, -b.velocity.y * 0.3);
        }
      }

      // 7. NON-SPHERICAL ORGANIC DEFORMATION (Randomness & stretching)
      // Blobs are not round! They stretch into teardrops when moving,
      // wobble with surface tension oscillations, and have asymmetric axes!
      const speed = b.velocity.length();
      const stretchAmount = Math.min(speed * 0.9, 0.7);

      // Fluid oscillation mode
      const wobbleAmp = 0.15 * this.params.randomness * (1.2 / effViscosity);
      const wobbleX = 1.0 + Math.sin(b.wobblePhase) * wobbleAmp;
      const wobbleY = 1.0 + Math.sin(b.wobblePhase + Math.PI * 0.6) * wobbleAmp;
      const wobbleZ = 1.0 + Math.sin(b.wobblePhase + Math.PI * 1.2) * wobbleAmp;

      // Vertical stretch along movement direction
      const targetSy = (1.0 + stretchAmount * 1.2) * wobbleY;
      const targetSx = (1.0 / Math.sqrt(Math.max(0.2, targetSy))) * wobbleX;
      const targetSz = (1.0 / Math.sqrt(Math.max(0.2, targetSy))) * wobbleZ;

      b.deformTarget.set(targetSx, targetSy, targetSz);
      // Viscous relaxation towards equilibrium
      const relaxRate = (4.0 * this.params.surfaceTension) / effViscosity;
      b.deform.lerp(b.deformTarget, Math.min(1.0, relaxRate * stepDt));
    }

    // 8. INTER-BLOB INTERACTIONS & MERGING
    for (let i = 0; i < this.blobs.length; i++) {
      const b1 = this.blobs[i];
      if (!b1.active) continue;

      for (let j = i + 1; j < this.blobs.length; j++) {
        const b2 = this.blobs[j];
        if (!b2.active) continue;

        const diff = new THREE.Vector3().subVectors(b2.position, b1.position);
        const dist = diff.length();
        const minDist = (b1.radius + b2.radius) * 0.85;

        if (dist < minDist && dist > 0.001) {
          // Check for merging: similar temperature and low relative velocity
          const relVel = new THREE.Vector3().subVectors(b2.velocity, b1.velocity).length();
          const shouldMerge = (dist < minDist * 0.55 && relVel < 0.25) || (this.params.coalesceMode && dist < minDist * 0.8);

          if (shouldMerge && b1.radius < 0.45 && b2.radius < 0.45) {
            // Merge b2 into b1
            const totalVol = Math.pow(b1.radius, 3) + Math.pow(b2.radius, 3);
            b1.radius = Math.min(0.48, Math.cbrt(totalVol));
            b1.temperature = (b1.temperature * b1.radius + b2.temperature * b2.radius) / (b1.radius + b2.radius);
            b1.velocity.add(b2.velocity).multiplyScalar(0.5);
            b2.active = false;
          } else {
            // Soft fluid repulsion / deformation interaction
            const normal = diff.normalize();
            const overlap = minDist - dist;
            const force = overlap * 1.8;
            b1.position.addScaledVector(normal, -force * 0.5 * stepDt);
            b2.position.addScaledVector(normal, force * 0.5 * stepDt);

            // Mutual stretching along collision axis (capillary bridge effect)
            b1.deform.addScaledVector(normal, 0.05 * this.params.randomness);
            b2.deform.addScaledVector(normal, -0.05 * this.params.randomness);
          }
        }
      }
    }

    // 9. SPAWNING NEW GLOBULES FROM BASE POOL (Rayleigh-Taylor pinch-off)
    // When the base pool is hot enough, domes form, stretch upward, and pinch off into new blobs!
    if (!this.params.coalesceMode && tBase >= 46 && this.basePoolHeight > 0.25) {
      // Find an inactive blob to spawn
      const inactive = this.blobs.find(b => !b.active);
      const activeCount = this.blobs.filter(b => b.active).length;

      // Spawn rate depends on heater temperature
      const spawnInterval = Math.max(3.0, 14.0 - (tBase - 46) * 0.35);
      if (inactive && activeCount < 10 && Math.random() < (stepDt / spawnInterval)) {
        this.spawnBlobFromPool(inactive, bottomY);
      }
    }

    this.recomputePoolHeight();
  }

  // Spawns a new globule bulging out of the base reservoir
  private spawnBlobFromPool(b: BlobParticle, bottomY: number) {
    const poolTop = bottomY + this.basePoolHeight;
    const spawnRad = 0.22 + Math.random() * 0.14;
    const rContainer = this.getContainerRadiusAt(poolTop) * 0.55;
    const angle = Math.random() * Math.PI * 2;
    const offsetDist = Math.random() * rContainer;

    b.active = true;
    b.position.set(Math.cos(angle) * offsetDist, poolTop + 0.05, Math.sin(angle) * offsetDist);
    b.radius = spawnRad;
    b.baseRadius = spawnRad;
    b.temperature = this.params.temperature - 2.0; // very warm
    b.velocity.set((Math.random() - 0.5) * 0.04, 0.14 + Math.random() * 0.12, (Math.random() - 0.5) * 0.04);
    // Initial upward teardrop elongation
    b.deform.set(0.85, 1.45, 0.85);
    b.wobblePhase = Math.random() * Math.PI * 2;

    // Deduct volume from base pool
    this.targetPoolHeight = Math.max(0.18, this.targetPoolHeight - Math.pow(spawnRad, 3) * 0.5);
  }

  // User interaction: stirring or swirling the lava lamp
  public stir(force: THREE.Vector3) {
    this.disturbance.add(force);
    for (const b of this.blobs) {
      if (b.active) {
        b.velocity.addScaledVector(force, 0.6);
        // Add random wobble kick
        b.deform.x += (Math.random() - 0.5) * 0.4;
        b.deform.z += (Math.random() - 0.5) * 0.4;
      }
    }
  }

  // Force all wax to coalesce back into the single planar top base pool!
  public triggerCoalesce() {
    this.params.coalesceMode = true;
    for (const b of this.blobs) {
      if (b.active) {
        b.velocity.y = -0.35 - Math.random() * 0.2;
        b.temperature = 22; // cool down
      }
    }
  }

  // Warm up / resume normal buoyant flow
  public triggerHeatUp() {
    this.params.coalesceMode = false;
    this.params.temperature = Math.max(this.params.temperature, 52);
  }

  // Reset to full settled cold pool state
  public settleToColdPool() {
    this.params.coalesceMode = true;
    for (const b of this.blobs) {
      b.active = false;
    }
    this.basePoolHeight = 0.75;
    this.targetPoolHeight = 0.75;
  }
}
