import { useState, useRef, useEffect, useCallback } from 'react';
import { LavaSimulation, SimulationParams } from './simulation/LavaSimulation';
import { LavaLampScene, SceneOptions, LampFinish } from './components/LavaLampScene';
import { Toolbar } from './components/Toolbar';
import { ColorPaletteDrawer } from './components/ColorPaletteDrawer';
import { PhysicsPanel } from './components/PhysicsPanel';
import { DimensionOverlay } from './components/DimensionOverlay';
import { PhysicsHUD } from './components/PhysicsHUD';
import { InfoModal } from './components/InfoModal';
import { COLOR_PRESETS } from './constants/presets';
import { Info, Sparkles, Volume2, VolumeX } from 'lucide-react';

export function App() {
  // 1. Simulation Instance (single stable ref)
  const simulationRef = useRef<LavaSimulation | null>(null);
  if (!simulationRef.current) {
    simulationRef.current = new LavaSimulation();
  }
  const simulation = simulationRef.current;

  // 2. Physics & Simulation State
  const [simParams, setSimParams] = useState<SimulationParams>(() => ({
    ...simulation.params,
  }));

  // 3. Visual & Scene Options
  const [sceneOptions, setSceneOptions] = useState<SceneOptions>({
    liquidColor: COLOR_PRESETS[0].liquidColor, // #3b0764 Deep purple (Matches photo 1 & 4)
    waxColor: COLOR_PRESETS[0].waxColor,       // #f43f5e Hot pink / magenta
    brightness: 1.0,
    powerOn: true,
    lampFinish: 'black',                       // Classic flared black base
    noiseAmount: 0.85,
    autoRotate: false,
  });

  // 4. UI Visibility State
  const [isControlsHidden, setIsControlsHidden] = useState(false);
  const [isColorDrawerOpen, setIsColorDrawerOpen] = useState(false);
  const [isPhysicsDrawerOpen, setIsPhysicsDrawerOpen] = useState(false);
  const [showDimensions, setShowDimensions] = useState(false);
  const [isInfoModalOpen, setIsInfoModalOpen] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Audio ambient hum synthesizer (Web Audio API for subtle warm transformer hum / bubble pop)
  const audioCtxRef = useRef<AudioContext | null>(null);
  const humGainRef = useRef<GainNode | null>(null);

  // Toast auto-dismiss
  useEffect(() => {
    if (!toastMessage) return;
    const t = setTimeout(() => setToastMessage(null), 2400);
    return () => clearTimeout(t);
  }, [toastMessage]);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
  }, []);

  // Update simulation parameters
  const handleUpdateParams = useCallback((newParams: Partial<SimulationParams>) => {
    setSimParams((prev) => {
      const updated = { ...prev, ...newParams };
      if (simulationRef.current) {
        Object.assign(simulationRef.current.params, updated);
      }
      return updated;
    });
  }, []);

  // Power switch toggle
  const handleTogglePower = useCallback(() => {
    setSceneOptions((prev) => {
      const nextPower = !prev.powerOn;
      if (nextPower) {
        simulation.triggerHeatUp();
        handleUpdateParams({ temperature: 54, coalesceMode: false });
        showToast('Lamp ON: Base heating coil activated (54°C)');
      } else {
        simulation.triggerCoalesce();
        handleUpdateParams({ temperature: 20, coalesceMode: true });
        showToast('Lamp OFF: Cooling down, wax coalescing into base');
      }
      return { ...prev, powerOn: nextPower };
    });
  }, [simulation, handleUpdateParams, showToast]);

  // Coalesce action: all wax merges into the base reservoir with a planar top
  const handleCoalesce = useCallback(() => {
    simulation.triggerCoalesce();
    handleUpdateParams({ coalesceMode: true, temperature: 24 });
    showToast('Coalescing wax into planar base reservoir...');
  }, [simulation, handleUpdateParams, showToast]);

  // Heat Up / Resume Convection
  const handleHeatUp = useCallback(() => {
    simulation.triggerHeatUp();
    setSceneOptions((prev) => ({ ...prev, powerOn: true }));
    handleUpdateParams({ coalesceMode: false, temperature: 56 });
    showToast('Heating base coil: Convective plumes launching');
  }, [simulation, handleUpdateParams, showToast]);

  // Stir fluid / blobs
  const handleStir = useCallback(() => {
    simulation.stir({
      x: (Math.random() - 0.5) * 0.45,
      y: (Math.random() - 0.5) * 0.3,
      z: (Math.random() - 0.5) * 0.45,
    } as any);
    showToast('Agitated fluid: Turbulent shear & vortex induced');
  }, [simulation, showToast]);

  // Brightness change
  const handleChangeBrightness = useCallback((b: number) => {
    setSceneOptions((prev) => ({ ...prev, brightness: b }));
  }, []);

  // Color changes
  const handleUpdateColors = useCallback((liq: string, wax: string) => {
    setSceneOptions((prev) => ({
      ...prev,
      liquidColor: liq,
      waxColor: wax,
    }));
  }, []);

  // Finish change
  const handleChangeFinish = useCallback((f: LampFinish) => {
    setSceneOptions((prev) => ({ ...prev, lampFinish: f }));
    showToast(`Finish switched to ${f.toUpperCase()} metal`);
  }, [showToast]);

  // Keyboard shortcut listener ('H' to hide/show UI, Esc to close panels)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement) return;

      if (e.key === 'h' || e.key === 'H') {
        setIsControlsHidden((prev) => !prev);
        setIsColorDrawerOpen(false);
        setIsPhysicsDrawerOpen(false);
      } else if (e.key === 'Escape') {
        setIsColorDrawerOpen(false);
        setIsPhysicsDrawerOpen(false);
        setIsInfoModalOpen(false);
        if (isControlsHidden) setIsControlsHidden(false);
      } else if (e.key === ' ') {
        e.preventDefault();
        handleStir();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleStir, isControlsHidden]);

  // Web Audio ambient hum effect
  const toggleSound = () => {
    if (!soundEnabled) {
      try {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        const ctx = new AudioCtx();
        audioCtxRef.current = ctx;

        // Subtle 60Hz transformer mains hum
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const filter = ctx.createBiquadFilter();

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(60, ctx.currentTime);

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(140, ctx.currentTime);

        gain.gain.setValueAtTime(0.015, ctx.currentTime);
        humGainRef.current = gain;

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(ctx.destination);
        osc.start();

        setSoundEnabled(true);
        showToast('Ambient thermal hum enabled');
      } catch (err) {
        console.warn('Audio not allowed or supported', err);
      }
    } else {
      if (audioCtxRef.current) {
        audioCtxRef.current.close();
        audioCtxRef.current = null;
      }
      setSoundEnabled(false);
      showToast('Ambient audio muted');
    }
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-zinc-950 font-sans">
      {/* 3D Three.js Scene */}
      <LavaLampScene
        simulation={simulation}
        simParams={simParams}
        options={sceneOptions}
        onStir={() => showToast('Swirling fluid vortices...')}
      />

      {/* Blueprint Dimensions & Anatomical Callout Lines */}
      <DimensionOverlay
        visible={showDimensions && !isControlsHidden}
        powerOn={sceneOptions.powerOn}
        onTogglePower={handleTogglePower}
      />

      {/* Real-time Physics Telemetry Badge */}
      <PhysicsHUD
        simulation={simulation}
        simParams={simParams}
        visible={!isControlsHidden}
        powerOn={sceneOptions.powerOn}
      />

      {/* Top Header / Brand & Guide Button */}
      {!isControlsHidden && (
        <header className="absolute top-4 inset-x-0 mx-auto w-fit z-20 flex items-center gap-3 px-4 py-2 rounded-2xl bg-zinc-950/70 backdrop-blur-md border border-zinc-800/80 shadow-lg text-white select-none">
          <div className="flex items-center gap-2">
            <div
              className="w-3.5 h-3.5 rounded-full shadow-sm animate-pulse"
              style={{ backgroundColor: sceneOptions.waxColor }}
            />
            <h1 className="text-xs sm:text-sm font-bold tracking-wider uppercase bg-gradient-to-r from-zinc-100 to-zinc-400 bg-clip-text text-transparent">
              Lava Lamp 3D Physics
            </h1>
          </div>

          <div className="h-4 w-px bg-zinc-800" />

          {/* Sound Hum Toggle */}
          <button
            onClick={toggleSound}
            className={`p-1.5 rounded-lg border transition-colors ${
              soundEnabled
                ? 'bg-amber-500/20 border-amber-500/50 text-amber-300'
                : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
            }`}
            title={soundEnabled ? 'Mute Transformer Hum' : 'Enable 60Hz Transformer Hum'}
          >
            {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
          </button>

          {/* Guide Modal Trigger */}
          <button
            onClick={() => setIsInfoModalOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-indigo-500/15 hover:bg-indigo-500/25 border border-indigo-500/40 text-indigo-300 text-xs font-medium transition-colors"
            title="Fluid Physics & Science Guide"
          >
            <Info className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Science</span>
          </button>
        </header>
      )}

      {/* Interactive Toolbar */}
      <Toolbar
        powerOn={sceneOptions.powerOn}
        onTogglePower={handleTogglePower}
        onCoalesce={handleCoalesce}
        onHeatUp={handleHeatUp}
        onStir={handleStir}
        brightness={sceneOptions.brightness}
        onChangeBrightness={handleChangeBrightness}
        isColorOpen={isColorDrawerOpen}
        onToggleColor={() => {
          setIsColorDrawerOpen((v) => !v);
          setIsPhysicsDrawerOpen(false);
        }}
        isPhysicsOpen={isPhysicsDrawerOpen}
        onTogglePhysics={() => {
          setIsPhysicsDrawerOpen((v) => !v);
          setIsColorDrawerOpen(false);
        }}
        showDimensions={showDimensions}
        onToggleDimensions={() => setShowDimensions((v) => !v)}
        autoRotate={sceneOptions.autoRotate}
        onToggleAutoRotate={() =>
          setSceneOptions((prev) => ({ ...prev, autoRotate: !prev.autoRotate }))
        }
        lampFinish={sceneOptions.lampFinish}
        onChangeFinish={handleChangeFinish}
        isControlsHidden={isControlsHidden}
        onToggleHideControls={() => {
          setIsControlsHidden((v) => !v);
          setIsColorDrawerOpen(false);
          setIsPhysicsDrawerOpen(false);
        }}
        currentLiquidColor={sceneOptions.liquidColor}
        currentWaxColor={sceneOptions.waxColor}
      />

      {/* Two-Tone Color Palette Drawer */}
      <ColorPaletteDrawer
        isOpen={isColorDrawerOpen && !isControlsHidden}
        onClose={() => setIsColorDrawerOpen(false)}
        liquidColor={sceneOptions.liquidColor}
        waxColor={sceneOptions.waxColor}
        brightness={sceneOptions.brightness}
        onUpdateColors={handleUpdateColors}
        onUpdateBrightness={handleChangeBrightness}
      />

      {/* Physics & Emulsions Parameters Drawer */}
      <PhysicsPanel
        isOpen={isPhysicsDrawerOpen && !isControlsHidden}
        onClose={() => setIsPhysicsDrawerOpen(false)}
        simulation={simulation}
        simParams={simParams}
        onUpdateParams={handleUpdateParams}
        onCoalesce={handleCoalesce}
        onHeatUp={handleHeatUp}
      />

      {/* Educational Science & Principles Modal */}
      <InfoModal
        isOpen={isInfoModalOpen}
        onClose={() => setIsInfoModalOpen(false)}
      />

      {/* Transient Action Toast */}
      {toastMessage && (
        <div className="absolute top-16 inset-x-0 mx-auto w-fit z-50 pointer-events-none animate-in fade-in slide-in-from-top-2 duration-150">
          <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-zinc-900/90 border border-zinc-700/80 backdrop-blur-md shadow-2xl text-xs text-zinc-200">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>{toastMessage}</span>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
