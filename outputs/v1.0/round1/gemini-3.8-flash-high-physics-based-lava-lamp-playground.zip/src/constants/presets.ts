export interface ColorPreset {
  id: string;
  name: string;
  category: string;
  liquidColor: string;
  waxColor: string;
  description: string;
}

export const COLOR_PRESETS: ColorPreset[] = [
  {
    id: 'psychedelic-violet',
    name: 'Psychedelic Violet',
    category: 'Classic 90s',
    liquidColor: '#3b0764', // Deep purple
    waxColor: '#f43f5e',    // Radiant hot pink / magenta (Photos 1 & 4)
    description: 'Iconic 1990s retro aesthetic with deep purple liquid and electric magenta globules.',
  },
  {
    id: 'solar-sunset',
    name: 'Solar Sunset',
    category: 'Retro 70s',
    liquidColor: '#9a3412', // Amber tangerine
    waxColor: '#facc15',    // Molten golden yellow (Photo 2)
    description: 'Warm incandescent amber fluid with glowing sunburst wax lobes.',
  },
  {
    id: 'toxic-acid',
    name: 'Electric Lime',
    category: 'Cyberpunk',
    liquidColor: '#0284c7', // Cobalt blue
    waxColor: '#84cc16',    // Neon lime green (Photo 3)
    description: 'Vibrant cobalt blue emulsion with high-contrast chartreuse lime wax.',
  },
  {
    id: 'abyss-coral',
    name: 'Abyss & Coral',
    category: 'Aquatic',
    liquidColor: '#0f766e', // Deep sea teal
    waxColor: '#fb7185',    // Glowing coral pink
    description: 'Deep oceanic turquoise water holding bioluminescent coral globules.',
  },
  {
    id: 'volcano-magma',
    name: 'Volcanic Magma',
    category: 'Intense',
    liquidColor: '#450a0a', // Dark crimson
    waxColor: '#ea580c',    // Molten lava orange
    description: 'Dark ruby red base emulsion with scorching volcanic orange plumes.',
  },
  {
    id: 'cyber-neon',
    name: 'Midnight Cyber',
    category: 'Cyberpunk',
    liquidColor: '#1e1b4b', // Midnight indigo
    waxColor: '#06b6d4',    // Radiant cyan
    description: 'Moody synthwave dark indigo with high-luminance cyan plasma.',
  },
  {
    id: 'ghost-minimal',
    name: 'Smoky Opal',
    category: 'Minimalist',
    liquidColor: '#1e293b', // Smoked slate
    waxColor: '#f1f5f9',    // Opal pearl white
    description: 'Modern understated luxury with crystal smoked liquid and pure pearl wax.',
  },
  {
    id: 'cherry-sakura',
    name: 'Cherry Blossom',
    category: 'Pastel',
    liquidColor: '#831843', // Rose berry
    waxColor: '#fbcfe8',    // Sakura pink
    description: 'Gentle berry syrup with soft blushing pink floating clouds.',
  },
];

export interface EmulsionPreset {
  id: string;
  name: string;
  description: string;
  temperature: number;
  viscosity: number;
  waxDensity: number;
  liquidDensity: number;
  surfaceTension: number;
  randomness: number;
}

export const EMULSION_PRESETS: EmulsionPreset[] = [
  {
    id: 'balanced-flow',
    name: 'Balanced Flow (Standard)',
    description: 'Ideal thermal convection with smooth teardrop stretching and periodic coalescence.',
    temperature: 52,
    viscosity: 1.0,
    waxDensity: 0.992,
    liquidDensity: 1.0,
    surfaceTension: 1.2,
    randomness: 0.85,
  },
  {
    id: 'glacial-syrup',
    name: 'Heavy Viscous Syrup',
    description: 'Cold, thick emulsion. Huge slow-moving lobes that form thick liquid bridges.',
    temperature: 44,
    viscosity: 2.1,
    waxDensity: 1.005,
    liquidDensity: 1.0,
    surfaceTension: 1.8,
    randomness: 0.6,
  },
  {
    id: 'hyper-active',
    name: 'Hyperactive Hot Spring',
    description: 'High temperature, low viscosity. Rapidly rising smaller droplets with vigorous wobble.',
    temperature: 68,
    viscosity: 0.45,
    waxDensity: 0.975,
    liquidDensity: 1.0,
    surfaceTension: 0.8,
    randomness: 1.3,
  },
  {
    id: 'dense-heavy',
    name: 'Heavy Wax Sluggish',
    description: 'Wax is denser than usual; requires intense bottom heat to launch domes.',
    temperature: 56,
    viscosity: 1.4,
    waxDensity: 1.02,
    liquidDensity: 1.0,
    surfaceTension: 1.5,
    randomness: 0.9,
  },
  {
    id: 'zero-g-morph',
    name: 'Zero-G Morphic Bloom',
    description: 'Near-zero net buoyancy with high surface oscillation and organic warping.',
    temperature: 50,
    viscosity: 0.8,
    waxDensity: 1.000,
    liquidDensity: 1.0,
    surfaceTension: 0.6,
    randomness: 1.5,
  },
];
