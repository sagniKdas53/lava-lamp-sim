import { LampParams, LampShape } from '../lib/sim';
import { cn } from '../utils/cn';

export const LIQUID_SWATCHES = [
  '#ff6a00', '#7a2bd6', '#1f6fff', '#0e7490', '#c81e3c', '#0f7a3a', '#c0168f',
  '#0b2a6b', '#f59e0b', '#ff5fa2', '#4b1d8f', '#7fb6ff', '#2b2b33', '#f2e6ff',
];
export const WAX_SWATCHES = [
  '#fff2c2', '#ffffff', '#ff2d9b', '#d9ff3c', '#ffe14d', '#ff3b30', '#38f0ff',
  '#b36bff', '#ff8c1a', '#3dff8a', '#4d8bff', '#ffd1dc', '#1a1a1a', '#ff00aa',
];

export interface Preset {
  name: string;
  liquid: string;
  wax: string;
  shape: LampShape;
}
export const PRESETS: Preset[] = [
  { name: 'Classic', liquid: '#ff6a00', wax: '#fff2c2', shape: 'rocket' },
  { name: 'Violet Noir', liquid: '#7a2bd6', wax: '#ff2d9b', shape: 'tower' },
  { name: 'Lagoon', liquid: '#1f6fff', wax: '#d7ff3c', shape: 'rocket' },
  { name: 'Ember', liquid: '#c81e3c', wax: '#ffd166', shape: 'tower' },
  { name: 'Deep Sea', liquid: '#0b2a6b', wax: '#38f0ff', shape: 'rocket' },
  { name: 'Emerald', liquid: '#0f7a3a', wax: '#ffe14d', shape: 'tower' },
];

interface Props {
  lamps: LampParams[];
  selected: number;
  onSelect: (i: number) => void;
  onAdd: () => void;
  onRemove: () => void;
  onChange: (patch: Partial<LampParams>) => void;
  onStir: () => void;
  onRelease: () => void;
  onReset: () => void;
  onHide: () => void;
  info: { blobs: number; poolT: number; neutralT: number };
}

function Slider({
  label, value, min, max, step, unit = '', onChange, hint,
}: {
  label: string; value: number; min: number; max: number; step: number; unit?: string;
  onChange: (v: number) => void; hint?: string;
}) {
  return (
    <label className="block" title={hint}>
      <div className="flex justify-between text-[11px] text-white/60 mb-0.5">
        <span>{label}</span>
        <span className="tabular-nums text-white/80">
          {step < 0.01 ? value.toFixed(3) : step < 0.1 ? value.toFixed(2) : step < 1 ? value.toFixed(1) : Math.round(value)}
          {unit}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="w-full h-1.5 accent-amber-400 cursor-pointer"
      />
    </label>
  );
}

function Swatches({
  colors, value, onPick,
}: { colors: string[]; value: string; onPick: (c: string) => void }) {
  return (
    <div className="flex flex-wrap gap-1.5 items-center">
      {colors.map((c) => (
        <button
          key={c}
          onClick={() => onPick(c)}
          className={cn(
            'w-5 h-5 rounded-full border transition-transform hover:scale-110',
            value.toLowerCase() === c.toLowerCase()
              ? 'border-white ring-2 ring-white/50 scale-110'
              : 'border-white/20',
          )}
          style={{ background: c }}
          aria-label={c}
        />
      ))}
      <label className="relative w-5 h-5 rounded-full border border-dashed border-white/40 overflow-hidden cursor-pointer"
        title="Custom color"
        style={{ background: 'conic-gradient(red, yellow, lime, cyan, blue, magenta, red)' }}>
        <input
          type="color"
          value={value}
          onChange={(e) => onPick(e.target.value)}
          className="absolute inset-0 opacity-0 cursor-pointer"
        />
      </label>
    </div>
  );
}

function Section({ title, children, className }: { title: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={cn('min-w-[200px] flex-1', className)}>
      <div className="text-[10px] uppercase tracking-[0.18em] text-white/40 mb-2">{title}</div>
      <div className="space-y-2">{children}</div>
    </div>
  );
}

const btn = 'px-2.5 py-1.5 rounded-md text-xs font-medium transition-colors border';
const btnGhost = cn(btn, 'bg-white/5 hover:bg-white/10 border-white/10 text-white/80');
const btnActive = cn(btn, 'bg-amber-400/20 border-amber-300/50 text-amber-100');

export default function Controls(p: Props) {
  const L = p.lamps[p.selected];
  if (!L) return null;
  return (
    <div className="pointer-events-auto mx-auto max-w-[1280px] rounded-2xl border border-white/10 bg-[#0b0a12]/80 backdrop-blur-xl shadow-2xl shadow-black/50 text-white">
      {/* header row */}
      <div className="flex items-center gap-2 px-4 py-2 border-b border-white/10 flex-wrap">
        <div className="flex items-center gap-1">
          {p.lamps.map((lp, i) => (
            <button
              key={i}
              onClick={() => p.onSelect(i)}
              className={cn(i === p.selected ? btnActive : btnGhost, 'flex items-center gap-1.5')}
            >
              <span className="w-2.5 h-2.5 rounded-full" style={{ background: lp.waxColor, boxShadow: `0 0 6px ${lp.liquidColor}` }} />
              Lamp {i + 1}
            </button>
          ))}
          {p.lamps.length < 3 && (
            <button onClick={p.onAdd} className={btnGhost} title="Add a lamp">+ Add</button>
          )}
          {p.lamps.length > 1 && (
            <button onClick={p.onRemove} className={cn(btnGhost, 'text-red-200/80')} title="Remove selected lamp">Remove</button>
          )}
        </div>

        <div className="w-px h-5 bg-white/10 mx-1 hidden sm:block" />

        <div className="flex items-center gap-1">
          <button onClick={p.onRelease} className={btnGhost} title="Pop a globule out of the pool">▲ Release</button>
          <button onClick={p.onStir} className={btnGhost} title="Shake things up">〰 Stir</button>
          <button onClick={p.onReset} className={btnGhost} title="Melt everything back into one pool">↺ Reset</button>
        </div>

        <div className="w-px h-5 bg-white/10 mx-1 hidden sm:block" />

        <div className="flex items-center gap-1">
          {(['rocket', 'tower'] as LampShape[]).map((s) => (
            <button key={s} onClick={() => p.onChange({ shape: s })} className={L.shape === s ? btnActive : btnGhost}>
              {s === 'rocket' ? '🚀 Rocket' : '🏛 Tower'}
            </button>
          ))}
        </div>

        <div className="ml-auto flex items-center gap-3 text-[11px] text-white/50 tabular-nums">
          <span title="Globules in flight">● {p.info.blobs}</span>
          <span title="Pool temperature / neutral buoyancy temperature">
            pool {p.info.poolT.toFixed(0)}° / float {p.info.neutralT.toFixed(0)}°
          </span>
          <button onClick={p.onHide} className={btnGhost} title="Hide controls (H)">Hide ▾</button>
        </div>
      </div>

      {/* body */}
      <div className="flex flex-wrap gap-x-6 gap-y-4 px-4 py-3 max-h-[42vh] overflow-y-auto">
        <Section title="Heat & flow">
          <Slider label="Heater" value={L.heat} min={0} max={100} step={1} unit="%" onChange={(v) => p.onChange({ heat: v })} hint="Bulb power — drives wax temperature" />
          <Slider label="Viscosity" value={L.viscosity} min={0.2} max={5} step={0.05} onChange={(v) => p.onChange({ viscosity: v })} hint="Thicker liquid = slower, stringier globules" />
          <Slider label="Speed" value={L.speed} min={0.25} max={3} step={0.05} unit="×" onChange={(v) => p.onChange({ speed: v })} />
        </Section>

        <Section title="Emulsion densities">
          <Slider label="Wax density" value={L.waxDensity} min={0.98} max={1.08} step={0.001} onChange={(v) => p.onChange({ waxDensity: v })} hint="Density of wax at 20°C (relative)" />
          <Slider label="Liquid density" value={L.liquidDensity} min={0.95} max={1.05} step={0.001} onChange={(v) => p.onChange({ liquidDensity: v })} hint="Density of the carrier liquid at 20°C" />
          <Slider label="Thermal expansion" value={L.expansion} min={0.3} max={3} step={0.05} unit="‰/°" onChange={(v) => p.onChange({ expansion: v })} hint="How much wax expands when heated" />
        </Section>

        <Section title="Shape & blending">
          <Slider label="Chaos" value={L.chaos} min={0} max={1} step={0.01} onChange={(v) => p.onChange({ chaos: v })} hint="Turbulence, wobble and random splitting" />
          <Slider label="Blend softness" value={L.softness} min={0} max={1} step={0.01} onChange={(v) => p.onChange({ softness: v })} hint="How gooily globules merge" />
          <Slider label="Brightness" value={L.brightness} min={0} max={2} step={0.01} onChange={(v) => p.onChange({ brightness: v })} />
        </Section>

        <Section title="Colors" className="min-w-[260px]">
          <div>
            <div className="text-[11px] text-white/60 mb-1 flex items-center gap-2">
              <span className="w-3 h-3 rounded-sm" style={{ background: L.liquidColor }} /> Liquid
            </div>
            <Swatches colors={LIQUID_SWATCHES} value={L.liquidColor} onPick={(c) => p.onChange({ liquidColor: c })} />
          </div>
          <div>
            <div className="text-[11px] text-white/60 mb-1 flex items-center gap-2">
              <span className="w-3 h-3 rounded-sm" style={{ background: L.waxColor }} /> Wax
            </div>
            <Swatches colors={WAX_SWATCHES} value={L.waxColor} onPick={(c) => p.onChange({ waxColor: c })} />
          </div>
          <div>
            <div className="text-[11px] text-white/60 mb-1">Presets</div>
            <div className="flex flex-wrap gap-1.5">
              {PRESETS.map((pr) => (
                <button
                  key={pr.name}
                  onClick={() => p.onChange({ liquidColor: pr.liquid, waxColor: pr.wax, shape: pr.shape })}
                  className="flex items-center gap-1.5 px-2 py-1 rounded-md border border-white/10 bg-white/5 hover:bg-white/10 text-[11px]"
                >
                  <span className="w-3 h-3 rounded-full" style={{ background: `linear-gradient(135deg, ${pr.wax} 50%, ${pr.liquid} 50%)` }} />
                  {pr.name}
                </button>
              ))}
            </div>
          </div>
        </Section>
      </div>
    </div>
  );
}
