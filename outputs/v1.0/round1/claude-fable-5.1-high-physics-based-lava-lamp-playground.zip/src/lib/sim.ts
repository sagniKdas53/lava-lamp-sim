// Lava lamp physics simulation (CPU side). All units are "vessel units":
// the glass vessel spans y = 0 (bottom, heater) to y = 1 (top).

export const MAX_BLOBS = 14;

export type LampShape = 'rocket' | 'tower';

export interface LampParams {
  heat: number; // 0..100 heater power
  viscosity: number; // 0.2..5 liquid viscosity (relative)
  waxDensity: number; // relative density of wax at 20°C
  liquidDensity: number; // relative density of liquid at 20°C
  expansion: number; // thermal expansion of wax (x 0.001 / °C)
  chaos: number; // 0..1 randomness / turbulence
  softness: number; // 0..1 blend softness between globules
  brightness: number; // 0..2 bulb brightness
  speed: number; // 0.25..3 time scale
  liquidColor: string;
  waxColor: string;
  shape: LampShape;
}

export const DEFAULT_PARAMS: LampParams = {
  heat: 72,
  viscosity: 1,
  waxDensity: 1.02,
  liquidDensity: 1.0,
  expansion: 1,
  chaos: 0.5,
  softness: 0.5,
  brightness: 1,
  speed: 1,
  liquidColor: '#ff6a00',
  waxColor: '#fff2c2',
  shape: 'rocket',
};

export interface Profile {
  rB: number; // radius at bottom
  rT: number; // radius at top
  waist: number; // sin-shaped pinch in the middle
}

export function profileFor(shape: LampShape): Profile {
  return shape === 'rocket' ? { rB: 0.165, rT: 0.1, waist: 0 } : { rB: 0.15, rT: 0.14, waist: 0.03 };
}

export function vesselR(y: number, p: Profile): number {
  const t = Math.min(1, Math.max(0, y));
  return p.rB + (p.rT - p.rB) * t - p.waist * Math.sin(Math.PI * t);
}

export interface Blob {
  id: number;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  r: number;
  vol: number;
  targetVol: number; // > vol while the globule is still budding from the pool
  absorbing: boolean; // sinking back into the pool
  T: number;
  aspect: number; // base vertical aspect (random, makes non-spherical blobs)
  stretch: number; // current vertical stretch
  tail: number; // signed teardrop tail (+ = tail below)
  amp: number; // surface wobble amplitude
  phase: number;
  age: number;
  wx: number; // wander phase
}

const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const radiusFromVol = (v: number) => Math.cbrt((3 * v) / (4 * Math.PI));
const volFromRadius = (r: number) => (4 / 3) * Math.PI * r * r * r;

let nextId = 1;

export class LampSim {
  params: LampParams;
  prof: Profile;
  blobs: Blob[] = [];
  poolVol = 0;
  poolH = 0;
  poolT = 20;
  totalVol = 0;
  warm = 0;
  time = 0;
  neutralT = 40;
  private releaseTimer = 1;
  private cum: Float32Array = new Float32Array(0);
  private readonly N = 160;

  constructor(params: LampParams) {
    this.params = { ...params };
    this.prof = profileFor(params.shape);
    this.buildTable();
    this.reset();
  }

  setParams(p: LampParams) {
    const shapeChanged = p.shape !== this.params.shape;
    this.params = { ...p };
    if (shapeChanged) {
      this.prof = profileFor(p.shape);
      this.buildTable();
      this.reset();
    }
  }

  private buildTable() {
    const N = this.N;
    this.cum = new Float32Array(N + 1);
    let acc = 0;
    for (let i = 1; i <= N; i++) {
      const y0 = (i - 1) / N;
      const y1 = i / N;
      const r0 = vesselR(y0, this.prof);
      const r1 = vesselR(y1, this.prof);
      acc += (Math.PI * (r0 * r0 + r1 * r1) * 0.5) / N;
      this.cum[i] = acc;
    }
    this.totalVol = this.volumeAt(0.17);
  }

  volumeAt(h: number): number {
    const f = clamp(h, 0, 1) * this.N;
    const i = Math.floor(f);
    if (i >= this.N) return this.cum[this.N];
    return this.cum[i] + (this.cum[i + 1] - this.cum[i]) * (f - i);
  }

  heightFromVol(v: number): number {
    if (v <= 0) return 0;
    const c = this.cum;
    let lo = 0;
    let hi = this.N;
    while (hi - lo > 1) {
      const mid = (lo + hi) >> 1;
      if (c[mid] < v) lo = mid;
      else hi = mid;
    }
    const span = c[hi] - c[lo];
    const t = span > 0 ? (v - c[lo]) / span : 0;
    return (lo + t) / this.N;
  }

  reset() {
    this.blobs = [];
    this.poolVol = this.totalVol;
    this.poolH = this.heightFromVol(this.poolVol);
    this.poolT = 38;
    this.warm = 0.45;
    this.time = 0;
    this.releaseTimer = 0.8;
  }

  /** Stir: kick every blob and perturb shapes. */
  stir() {
    for (const b of this.blobs) {
      b.vx += (Math.random() - 0.5) * 0.5;
      b.vz += (Math.random() - 0.5) * 0.5;
      b.vy += (Math.random() - 0.5) * 0.35;
      b.phase += Math.random() * 3;
      b.amp = Math.min(0.16, b.amp + 0.04);
    }
    // break a few big ones
    const big = this.blobs.filter((b) => b.r > 0.06);
    for (const b of big) if (Math.random() < 0.5) this.split(b);
  }

  /** Force-release a globule from the pool immediately. */
  release(hot = true): boolean {
    if (this.blobs.length >= MAX_BLOBS) return false;
    const P = this.params;
    const frac = 0.06 + Math.random() * 0.24 * (0.5 + Math.random());
    const minPool = this.totalVol * 0.07;
    const vol = Math.min(this.totalVol * frac, this.poolVol - minPool);
    if (vol < this.totalVol * 0.03) return false;
    const r = radiusFromVol(vol);
    const ang = Math.random() * Math.PI * 2;
    const rad = Math.random() * Math.max(0, vesselR(this.poolH, this.prof) - r) * 0.75;
    const startVol = vol * 0.12;
    this.poolVol -= startVol;
    this.poolH = this.heightFromVol(this.poolVol);
    const b: Blob = {
      id: nextId++,
      x: Math.cos(ang) * rad,
      z: Math.sin(ang) * rad,
      y: this.poolH - radiusFromVol(startVol) * 0.2,
      vx: 0,
      vy: 0.01,
      vz: 0,
      r: radiusFromVol(startVol),
      vol: startVol,
      targetVol: vol,
      absorbing: false,
      T: hot ? this.poolT + (Math.random() - 0.5) * 6 : this.poolT - 15,
      aspect: 0.82 + Math.random() * 0.36,
      stretch: 1,
      tail: 0,
      amp: (0.025 + Math.random() * 0.09) * (0.35 + P.chaos),
      phase: Math.random() * Math.PI * 2,
      age: 0,
      wx: Math.random() * Math.PI * 2,
    };
    this.blobs.push(b);
    this.poolT -= 1.5;
    return true;
  }

  /** Poke the wax at a local point (ray-cast from a click). */
  poke(px: number, py: number, pz: number) {
    for (const b of this.blobs) {
      const dx = b.x - px;
      const dy = b.y - py;
      const dz = b.z - pz;
      const d = Math.hypot(dx, dy, dz) + 1e-4;
      const s = 0.35 * Math.exp(-d / 0.18);
      b.vx += (dx / d) * s;
      b.vy += (dy / d) * s;
      b.vz += (dz / d) * s;
      b.phase += s * 4;
    }
    // Pool poke: pop a blob out if close to the surface
    if (py < this.poolH + 0.08) this.release(true);
  }

  private split(b: Blob) {
    if (this.blobs.length >= MAX_BLOBS || b.vol < this.totalVol * 0.05) return;
    const f = 0.35 + Math.random() * 0.2;
    const v1 = b.vol * f;
    const v2 = b.vol - v1;
    const dir = b.vy >= 0 ? 1 : -1;
    const r0 = b.r;
    const c: Blob = {
      ...b,
      id: nextId++,
      vol: v2,
      targetVol: v2,
      r: radiusFromVol(v2),
      y: b.y - dir * r0 * 0.55,
      vy: b.vy * 0.8,
      T: b.T - 2,
      aspect: 0.85 + Math.random() * 0.3,
      amp: b.amp * (0.8 + Math.random() * 0.5),
      phase: Math.random() * Math.PI * 2,
      wx: Math.random() * Math.PI * 2,
    };
    b.vol = v1;
    b.targetVol = v1;
    b.r = radiusFromVol(v1);
    b.y += dir * r0 * 0.4;
    b.vx += (Math.random() - 0.5) * 0.05;
    b.vz += (Math.random() - 0.5) * 0.05;
    this.blobs.push(c);
  }

  step(dtIn: number) {
    const P = this.params;
    const dt = dtIn;
    this.time += dt;

    const Th = 20 + P.heat * 1.15; // heater temperature
    const warmTarget = P.heat > 1 ? 1 : 0;
    this.warm += (warmTarget - this.warm) * Math.min(1, dt * 0.12);
    const beta = Math.max(0.0001, P.expansion * 0.001);
    const rhoW = (T: number) => P.waxDensity * (1 - beta * (T - 20));
    const rhoL = (T: number) => P.liquidDensity * (1 - 0.3 * beta * (T - 20));
    const warmAmt = this.warm * (Th - 20);
    const Tl = (y: number) => 20 + warmAmt * (0.56 - 0.5 * clamp(y, 0, 1));

    // Neutral temperature where wax density equals liquid density
    const denom = beta * (P.waxDensity - 0.3 * P.liquidDensity);
    const Tn = 20 + (P.waxDensity - P.liquidDensity) / (Math.abs(denom) < 1e-6 ? 1e-6 : denom);
    this.neutralT = Tn;

    // Pool temperature: heated by the bulb, cooled by liquid
    const Tl0 = Tl(0);
    this.poolT += (0.09 * (Th - this.poolT) - 0.05 * (this.poolT - Tl0)) * dt;

    // Release new globules when the pool is superheated
    const superheat = this.poolT - Tn;
    if (superheat > 4 && this.blobs.length < MAX_BLOBS && this.poolVol > this.totalVol * 0.1) {
      this.releaseTimer -= dt * (0.5 + superheat / 25);
      if (this.releaseTimer <= 0) {
        this.release(true);
        this.releaseTimer = (1.0 + Math.random() * 2.6) * (1.25 - P.chaos * 0.6);
      }
    }

    const g = 12;
    const dragC = 0.02 * P.viscosity;
    const chaos = P.chaos;
    const t = this.time;

    for (let i = this.blobs.length - 1; i >= 0; i--) {
      const b = this.blobs[i];
      b.age += dt;

      // Budding from the pool: grow smoothly, pulling volume from the pool
      if (b.vol < b.targetVol) {
        const dv = Math.min(b.targetVol - b.vol, (b.targetVol * dt) / 1.4);
        const take = Math.min(dv, this.poolVol - this.totalVol * 0.05);
        if (take > 0) {
          b.vol += take;
          this.poolVol -= take;
          b.r = radiusFromVol(b.vol);
        } else b.targetVol = b.vol;
        if (b.y - b.r > this.poolH + 0.03) b.targetVol = b.vol;
      }

      // Absorbing back into the pool
      if (b.absorbing) {
        const dv = Math.min(b.vol, this.totalVol * 0.3 * dt);
        const mixVol = this.poolVol + dv;
        this.poolT = (this.poolT * this.poolVol + b.T * dv) / Math.max(1e-9, mixVol);
        this.poolVol = mixVol;
        b.vol -= dv;
        if (b.vol < this.totalVol * 0.004) {
          this.blobs.splice(i, 1);
          continue;
        }
        b.r = radiusFromVol(b.vol);
        b.vx *= 1 - Math.min(1, dt * 4);
        b.vz *= 1 - Math.min(1, dt * 4);
        const ty = this.poolH - b.r * 0.35;
        b.y += (ty - b.y) * Math.min(1, dt * 3);
        b.vy = 0;
        b.stretch += (b.aspect * 0.85 - b.stretch) * Math.min(1, dt * 2);
        b.tail *= 1 - Math.min(1, dt * 3);
        continue;
      }

      // Thermal exchange
      const Tenv = Tl(b.y);
      const hc = 0.11 * (0.06 / b.r);
      b.T += (Tenv - b.T) * hc * dt;
      if (b.y < this.poolH + b.r * 0.9) b.T += (this.poolT - b.T) * 0.12 * dt;

      // Buoyancy
      const rw = rhoW(b.T);
      const rl = rhoL(Tenv);
      let ay = (g * (rl - rw)) / Math.max(0.5, rw);

      // Lateral wander (smooth, deterministic per blob) + convection
      let ax = 0.22 * chaos * (Math.sin(t * 0.6 + b.wx) + 0.5 * Math.sin(t * 1.37 + 2.1 * b.wx));
      let az = 0.22 * chaos * (Math.cos(t * 0.53 + 1.3 * b.wx) + 0.5 * Math.cos(t * 1.21 + 0.7 * b.wx));
      ay += 0.08 * chaos * Math.sin(t * 0.9 + 3.0 * b.wx);
      const rr = Math.hypot(b.x, b.z) + 1e-6;
      const conv = -0.1 * clamp(b.vy * 10, -1, 1);
      ax += (conv * b.x) / rr;
      az += (conv * b.z) / rr;

      // Semi-implicit integration with Stokes-like drag (unconditionally stable)
      const k = dragC / (b.r * b.r);
      const inv = 1 / (1 + k * dt);
      b.vx = (b.vx + ax * dt) * inv;
      b.vy = (b.vy + ay * dt) * inv;
      b.vz = (b.vz + az * dt) * inv;
      const sp = Math.hypot(b.vx, b.vy, b.vz);
      if (sp > 0.45) {
        const s = 0.45 / sp;
        b.vx *= s;
        b.vy *= s;
        b.vz *= s;
      }
      b.x += b.vx * dt;
      b.y += b.vy * dt;
      b.z += b.vz * dt;

      // Walls
      const Rw = Math.max(0.01, vesselR(b.y, this.prof) - b.r * 0.8);
      const rr2 = Math.hypot(b.x, b.z);
      if (rr2 > Rw) {
        const f = Rw / rr2;
        b.x *= f;
        b.z *= f;
        const vr = (b.vx * b.x + b.vz * b.z) / Rw;
        if (vr > 0) {
          b.vx -= (vr * b.x) / Rw;
          b.vz -= (vr * b.z) / Rw;
        }
      }
      const yTop = 0.985 - b.r * 0.72;
      if (b.y > yTop) {
        b.y = yTop;
        if (b.vy > 0) b.vy *= -0.05;
      }
      const yBot = Math.max(b.r * 0.45, this.poolH - b.r * 0.5);
      if (b.y < yBot) {
        b.y = yBot;
        if (b.vy < 0) b.vy = 0;
      }

      // Shape: stretch along motion (more with viscous liquid), teardrop tail
      const visc = clamp(P.viscosity, 0.5, 2.2);
      const atTop = b.y >= yTop - 0.002;
      const targetStretch = atTop
        ? b.aspect * 0.8
        : b.aspect * (1 + clamp(Math.abs(b.vy) * 6, 0, 0.75) * visc);
      b.stretch += (targetStretch - b.stretch) * Math.min(1, dt * 1.6);
      const targetTail = clamp(b.vy * 14, -1, 1) * (0.5 + 0.5 * chaos);
      b.tail += (targetTail - b.tail) * Math.min(1, dt * 1.6);

      // Occasionally split large stretched globules
      if (
        chaos > 0.05 &&
        b.r > 0.062 &&
        Math.abs(b.vy) > 0.035 &&
        b.age > 2 &&
        this.blobs.length < MAX_BLOBS &&
        Math.random() < 0.09 * chaos * dt
      ) {
        this.split(b);
      }

      // Sink back into the pool when cool
      if (
        b.vol >= b.targetVol &&
        b.y - b.r * 0.4 < this.poolH + 0.01 &&
        b.vy <= 0.006 &&
        b.T < Tn + 3 &&
        b.age > 1.5
      ) {
        b.absorbing = true;
        b.targetVol = b.vol;
      }
    }

    // Pair interactions: coalescence (attract then merge) or soft repulsion
    const bl = this.blobs;
    for (let i = 0; i < bl.length; i++) {
      const a = bl[i];
      for (let j = bl.length - 1; j > i; j--) {
        const c = bl[j];
        const dx = c.x - a.x;
        const dy = c.y - a.y;
        const dz = c.z - a.z;
        const dist = Math.hypot(dx, dy, dz) + 1e-6;
        const sum = a.r + c.r;
        if (dist > sum * 0.92) continue;
        const nx = dx / dist;
        const ny = dy / dist;
        const nz = dz / dist;
        const canMerge = Math.abs(a.T - c.T) < 9 && !a.absorbing && !c.absorbing;
        const wa = c.vol / (a.vol + c.vol);
        const wc = a.vol / (a.vol + c.vol);
        if (canMerge) {
          if (dist < sum * 0.32 || (dist < sum * 0.5 && Math.random() < 1.2 * dt)) {
            // merge c into a
            const v = a.vol + c.vol;
            a.x = (a.x * a.vol + c.x * c.vol) / v;
            a.y = (a.y * a.vol + c.y * c.vol) / v;
            a.z = (a.z * a.vol + c.z * c.vol) / v;
            a.vx = (a.vx * a.vol + c.vx * c.vol) / v;
            a.vy = (a.vy * a.vol + c.vy * c.vol) / v;
            a.vz = (a.vz * a.vol + c.vz * c.vol) / v;
            a.T = (a.T * a.vol + c.T * c.vol) / v;
            a.vol = v;
            a.targetVol = Math.max(a.targetVol, v);
            if (a.targetVol < v) a.targetVol = v;
            a.r = radiusFromVol(v);
            a.amp = Math.max(a.amp, c.amp) * 1.1;
            a.stretch = Math.max(a.stretch, 1.15);
            bl.splice(j, 1);
            continue;
          }
          // surface-tension like attraction
          const pull = 0.6 * dt;
          a.vx += nx * pull * wa;
          a.vy += ny * pull * wa;
          a.vz += nz * pull * wa;
          c.vx -= nx * pull * wc;
          c.vy -= ny * pull * wc;
          c.vz -= nz * pull * wc;
        } else {
          const overlap = sum * 0.92 - dist;
          const push = overlap * 10 * dt;
          a.vx -= nx * push * wa;
          a.vy -= ny * push * wa * 0.3;
          a.vz -= nz * push * wa;
          c.vx += nx * push * wc;
          c.vy += ny * push * wc * 0.3;
          c.vz += nz * push * wc;
        }
      }
    }

    this.poolH = this.heightFromVol(this.poolVol);
  }

  /** Total wax volume consistency check (for debugging/UI). */
  waxVolume(): number {
    return this.poolVol + this.blobs.reduce((s, b) => s + b.vol, 0);
  }
}

export { radiusFromVol, volFromRadius };
