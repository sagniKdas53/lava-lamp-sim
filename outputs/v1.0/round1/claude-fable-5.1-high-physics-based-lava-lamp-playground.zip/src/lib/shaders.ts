import { MAX_BLOBS } from './sim';

export const lavaVertex = /* glsl */ `
varying vec3 vPos;
void main() {
  vPos = position;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`;

export const lavaFragment = /* glsl */ `
precision highp float;
#define MAXB ${MAX_BLOBS}
#define PI 3.14159265

uniform vec4 uBlobs[MAXB];   // xyz center, w radius
uniform vec4 uBlobP[MAXB];   // x stretch, y tail, z wobble amp, w phase
uniform int uCount;
uniform float uPoolH;
uniform float uTime;
uniform vec3 uCam;
uniform vec3 uLiquid;
uniform vec3 uWax;
uniform float uBright;
uniform float uSmooth;
uniform vec3 uProfile;       // rBottom, rTop, waist
uniform vec3 uBoxHalf;
uniform int uSteps;

varying vec3 vPos;

float vesselR(float y) {
  return mix(uProfile.x, uProfile.y, y) - uProfile.z * sin(PI * y);
}

float sdVessel(vec3 p) {
  float y = clamp(p.y, 0.0, 1.0);
  float dr = length(p.xz) - vesselR(y);
  float dy = max(0.03 - p.y, p.y - 0.985);
  return max(dr, dy);
}

float smin(float a, float b, float k) {
  float h = max(k - abs(a - b), 0.0) / k;
  return min(a, b) - h * h * k * 0.25;
}

float sdBlob(vec3 p, vec4 b, vec4 s) {
  vec3 q = p - b.xyz;
  float r = b.w;
  // teardrop: elongate the trailing half
  float tailSide = clamp(-q.y * sign(s.y) / r, 0.0, 1.0);
  float ys = s.x * (1.0 + 0.6 * abs(s.y) * tailSide);
  q.y /= ys;
  float d = (length(q) - r) * min(1.0, ys);
  if (d < r * 1.2) {
    float f = 2.3 / r;
    float w = sin(q.x * f + s.w + uTime * 0.7)
            * sin(q.y * f + s.w * 1.7 - uTime * 0.45)
            * sin(q.z * f + s.w * 2.3 + uTime * 0.6);
    d += s.z * r * w;
  }
  return d;
}

float sdWax(vec3 p) {
  float k = uSmooth;
  // the pool: flat-topped slab at the bottom with a faint ripple
  float d = p.y - uPoolH + 0.0025 * sin(p.x * 38.0 + uTime * 1.1) * sin(p.z * 35.0 - uTime * 0.8);
  for (int i = 0; i < MAXB; i++) {
    if (i >= uCount) break;
    d = smin(d, sdBlob(p, uBlobs[i], uBlobP[i]), k);
  }
  return d;
}

float map(vec3 p) {
  return max(sdWax(p), sdVessel(p) + 0.004);
}

vec3 calcNormal(vec3 p) {
  const vec2 e = vec2(0.0012, -0.0012);
  return normalize(
    e.xyy * map(p + e.xyy) +
    e.yyx * map(p + e.yyx) +
    e.yxy * map(p + e.yxy) +
    e.xxx * map(p + e.xxx));
}

float boxExit(vec3 ro, vec3 rd) {
  vec3 c = vec3(0.0, 0.5, 0.0);
  vec3 m = 1.0 / rd;
  vec3 n = m * (ro - c);
  vec3 k = abs(m) * uBoxHalf;
  vec3 t2 = -n + k;
  return min(min(t2.x, t2.y), t2.z);
}

void main() {
  vec3 ro = vPos;
  vec3 rd = normalize(vPos - uCam);
  float tMax = boxExit(ro, rd) + 0.001;

  float t = 0.0;
  float tEntry = 0.0;
  bool entered = false;
  bool hit = false;
  vec3 p = ro;

  for (int i = 0; i < 128; i++) {
    if (i >= uSteps || t > tMax) break;
    p = ro + rd * t;
    float dv = sdVessel(p);
    if (!entered) {
      if (dv < 0.002) { entered = true; tEntry = t; }
      else { t += max(dv, 0.003); continue; }
    } else if (dv > 0.012) {
      break;
    }
    float d = max(sdWax(p), dv + 0.004);
    if (d < 0.0007) { hit = true; break; }
    t += d * 0.72;
  }

  if (!entered) discard;

  vec3 pe = ro + rd * tEntry;
  float ye = clamp(pe.y, 0.0, 1.0);
  float B = uBright;

  // glass surface normal of the lathe r(y)
  float dR = (uProfile.y - uProfile.x) - uProfile.z * PI * cos(PI * ye);
  vec3 gn = normalize(vec3(pe.x, -dR * length(pe.xz), pe.z));
  vec3 keyDir = normalize(vec3(-0.55, 0.75, 0.65));
  vec3 fillDir = normalize(vec3(0.7, 0.3, 0.4));
  float gspec = pow(max(dot(gn, normalize(keyDir - rd)), 0.0), 120.0) * 0.7
              + pow(max(dot(gn, normalize(fillDir - rd)), 0.0), 60.0) * 0.12;
  float fres = pow(1.0 - max(dot(gn, -rd), 0.0), 3.0);

  // chord length through the vessel at the entry height
  float R = vesselR(ye);
  vec2 o = pe.xz;
  vec2 dxz = rd.xz;
  float a = max(dot(dxz, dxz), 1e-5);
  float bq = dot(o, dxz);
  float cq = dot(o, o) - R * R;
  float disc = max(bq * bq - a * cq, 0.0);
  float chord = (-bq + sqrt(disc)) / a;

  vec3 bulbPos = vec3(0.0, -0.05, 0.0);
  vec3 col;

  if (hit) {
    vec3 n = calcNormal(p);
    float glow = B * (0.22 + 1.05 * exp(-2.2 * p.y));
    vec3 L = normalize(bulbPos - p);
    float wrap = clamp((dot(n, L) + 0.75) / 1.75, 0.0, 1.0);
    float keyd = clamp(dot(n, keyDir) * 0.5 + 0.5, 0.0, 1.0);
    float rim = pow(1.0 - max(dot(n, -rd), 0.0), 2.6);
    // translucency: light from the bulb shining through towards the viewer
    float through = pow(max(dot(rd, -L), 0.0), 3.0) * 0.6;
    float spec = pow(max(dot(n, normalize(keyDir - rd)), 0.0), 48.0) * 0.4
               + pow(max(dot(n, normalize(fillDir - rd)), 0.0), 24.0) * 0.1;
    vec3 waxLit = uWax * (0.1 + 0.9 * wrap * glow + 0.22 * keyd + through * glow)
                + uWax * rim * (0.25 + 0.55 * glow)
                + vec3(spec) * (0.5 + 0.5 * B);
    // liquid between glass and the wax tints the globule
    float travel = t - tEntry;
    float att = exp(-travel * 3.2);
    vec3 liquidBack = uLiquid * glow * 0.55;
    col = mix(liquidBack, waxLit, att);
  } else {
    float glow = B * (0.2 + 1.0 * exp(-2.7 * ye));
    float dens = 1.0 - exp(-chord * 4.0);
    col = uLiquid * glow * (0.5 + 0.65 * dens);
    vec3 mid = pe + rd * chord * 0.5;
    float hot = B * 0.55 * exp(-length(mid - bulbPos) * 8.0);
    col += mix(uLiquid, vec3(1.0), 0.6) * hot;
    // light scattering haze above the pool
    col += uLiquid * 0.08 * B * exp(-abs(ye - uPoolH) * 12.0);
  }

  col += uLiquid * fres * 0.22 * B + vec3(gspec);

  gl_FragColor = vec4(col, 1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}
`;
